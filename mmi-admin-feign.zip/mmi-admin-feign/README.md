# mmi-admin-fegin

## Requirement 
* openjdk:11
* spring-boot 2.6.2


## Introduction 
* mmi-admin-fegin provide Fegin interface to access mmi-admin Restful interface