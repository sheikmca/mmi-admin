package sg.ncs.kp.northbound.pojo.common;

import java.io.Serializable;
import java.util.List;
import lombok.Generated;

public class PageResult<T> implements Serializable {
    private static final long serialVersionUID = -275582248840137389L;
    private Long totalNum;
 //   private Integer pageNo; // Existing field
    private Integer pageIndex;
    private Integer pageSize;
    private Boolean status;
    private List<T> data;
    private Integer totalPages;
    private String code;
    private String msg;
    private Integer httpStatus;

    // --- NEW ALIAS METHODS FOR SAFE pageIndex INTRODUCTION ---

    @Generated
    public Integer getPageIndex() {
        return this.pageIndex; // Maps pageIndex to the existing pageNo value
    }

    @Generated
    public void setPageIndex(final Integer pageIndex) {
        this.pageIndex = pageIndex; // Updates pageNo when pageIndex is set
    }

    // --- EXISTING DECOMPILED METHODS ---

    @Generated
    public static <T> PageResultBuilder<T> builder() {
        return new PageResultBuilder<T>();
    }

    @Generated
    public Long getTotalNum() { return this.totalNum; }
/*
    @Generated
    public Integer getPageNo() { return this.pageIndex; }*/

    @Generated
    public Integer getPageSize() { return this.pageSize; }

    @Generated
    public Boolean getStatus() { return this.status; }

    @Generated
    public List<T> getData() { return this.data; }

    @Generated
    public Integer getTotalPages() { return this.totalPages; }

    @Generated
    public String getCode() { return this.code; }

    @Generated
    public String getMsg() { return this.msg; }

    @Generated
    public Integer getHttpStatus() { return this.httpStatus; }

    @Generated
    public void setTotalNum(final Long totalNum) { this.totalNum = totalNum; }

   /* @Generated
    public void setPageNo(final Integer pageNo) { this.pageIndex = pageNo; }*/

    @Generated
    public void setPageSize(final Integer pageSize) { this.pageSize = pageSize; }

    @Generated
    public void setStatus(final Boolean status) { this.status = status; }

    @Generated
    public void setData(final List<T> data) { this.data = data; }

    @Generated
    public void setTotalPages(final Integer totalPages) { this.totalPages = totalPages; }

    @Generated
    public void setCode(final String code) { this.code = code; }

    @Generated
    public void setMsg(final String msg) { this.msg = msg; }

    @Generated
    public void setHttpStatus(final Integer httpStatus) { this.httpStatus = httpStatus; }

    // (Equals, HashCode, and ToString omitted for brevity, but remain unchanged)

    @Generated
    public PageResult() {}

    @Generated
    public PageResult(final Long totalNum, final Integer pageIndex, final Integer pageSize, final Boolean status, final List<T> data, final Integer totalPages, final String code, final String msg, final Integer httpStatus) {
        this.totalNum = totalNum;
        this.pageIndex = pageIndex;
        this.pageSize = pageSize;
        this.status = status;
        this.data = data;
        this.totalPages = totalPages;
        this.code = code;
        this.msg = msg;
        this.httpStatus = httpStatus;
    }

    @Generated
    public static class PageResultBuilder<T> {
        private Long totalNum;
     //   private Integer pageNo;
        private  Integer pageIndex;
        private Integer pageSize;
        private Boolean status;
        private List<T> data;
        private Integer totalPages;
        private String code;
        private String msg;
        private Integer httpStatus;

        @Generated
        PageResultBuilder() {}

        // --- NEW BUILDER ALIAS ---
        @Generated
        public PageResultBuilder<T> pageIndex(final Integer pageIndex) {
            this.pageIndex = pageIndex;
            return this;
        }

        @Generated
        public PageResultBuilder<T> totalNum(final Long totalNum) { this.totalNum = totalNum; return this; }

        /*@Generated
        public PageResultBuilder<T> pageNo(final Integer pageNo) { this.pageIndex = pageNo; return this; }*/

        @Generated
        public PageResultBuilder<T> pageSize(final Integer pageSize) { this.pageSize = pageSize; return this; }

        @Generated
        public PageResultBuilder<T> status(final Boolean status) { this.status = status; return this; }

        @Generated
        public PageResultBuilder<T> data(final List<T> data) { this.data = data; return this; }

        @Generated
        public PageResultBuilder<T> totalPages(final Integer totalPages) { this.totalPages = totalPages; return this; }

        @Generated
        public PageResultBuilder<T> code(final String code) { this.code = code; return this; }

        @Generated
        public PageResultBuilder<T> msg(final String msg) { this.msg = msg; return this; }

        @Generated
        public PageResultBuilder<T> httpStatus(final Integer httpStatus) { this.httpStatus = httpStatus; return this; }

        @Generated
        public PageResult<T> build() {
            return new PageResult<T>(this.totalNum, this.pageIndex, this.pageSize, this.status, this.data, this.totalPages, this.code, this.msg, this.httpStatus);
        }
    }
}