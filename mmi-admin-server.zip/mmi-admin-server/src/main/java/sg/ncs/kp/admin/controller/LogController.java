package sg.ncs.kp.admin.controller;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.metadata.Head;
import com.alibaba.excel.metadata.data.WriteCellData;
import com.alibaba.excel.support.ExcelTypeEnum;
import com.alibaba.excel.write.metadata.holder.WriteSheetHolder;
import com.alibaba.excel.write.metadata.style.WriteCellStyle;
import com.alibaba.excel.write.metadata.style.WriteFont;
import com.alibaba.excel.write.style.HorizontalCellStyleStrategy;
import com.alibaba.excel.write.style.column.AbstractColumnWidthStyleStrategy;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import sg.ncs.kp.admin.dto.*;
import sg.ncs.kp.admin.po.OperateLog;
import sg.ncs.kp.admin.service.LogService;
import sg.ncs.kp.common.core.response.PageResult;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.common.i18n.util.MessageUtils;
import sg.ncs.kp.uaa.client.dto.OperateLogDTO;
import sg.ncs.kp.uaa.server.po.LoginLog;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;

/**
 * @auther 
 * @date 2022/9/8
 * @description
 */
@RestController
@RequestMapping("/log")
public class LogController {

    @Autowired
    private LogService logService;

    @Autowired
    private MessageUtils messageUtils;

    private static final AbstractColumnWidthStyleStrategy STYLE_STRATEGY = new AbstractColumnWidthStyleStrategy() {
        @Override
        protected void setColumnWidth(WriteSheetHolder writeSheetHolder, List<WriteCellData<?>> cellDataList, Cell cell, Head head, Integer relativeRowIndex, Boolean isHead) {
            Sheet sheet = writeSheetHolder.getSheet();
            sheet.setColumnWidth(cell.getColumnIndex(), 16 * 256);
        }
    };

    @PostMapping("/login-log-list")
    @PreAuthorize("hasAuthority('auditLogs')")
    public PageResult<LoginLog> loginList(@RequestBody LoginLogQueryDTO queryDTO) {
        Page<LoginLog> page = logService.loginRecords(queryDTO);
        return messageUtils.pageResult((int) page.getCurrent(), (int) page.getSize(),
                page.getTotal(), BeanUtil.copyToList(page.getRecords(), LoginLog.class));
    }

    @PostMapping("/operate-log-list")
    @PreAuthorize("hasAuthority('auditLogs')")
    public PageResult<OperateLog> operateList(@RequestBody OperateLogQueryDTO queryDTO) {
        Page<OperateLog> page = logService.operateRecords(queryDTO);
        return messageUtils.pageResult((int) page.getCurrent(), (int) page.getSize(),
                page.getTotal(), BeanUtil.copyToList(page.getRecords(), OperateLog.class));
    }

    @PostMapping("/login-log-export/{type}")
    @PreAuthorize("hasAuthority('auditLogs')")
    public void exportLoginLog(@PathVariable String type, @RequestBody LoginLogQueryDTO queryDTO, HttpServletResponse response)
            throws IOException {
        List<LoginLogDTO> data = logService.getExportLoginLogData(queryDTO);
        if ("csv".equals(type)) {
            this.exportCSV(response, data, null);
        } else if ("xls".equals(type)) {
            this.exportXls(response, data, null);
        }
    }

    @PostMapping("/operate-log-export/{type}")
    @PreAuthorize("hasAuthority('auditLogs')")
    public void exportOperateLog(@PathVariable String type, @RequestBody OperateLogQueryDTO queryDTO, HttpServletResponse response)
            throws IOException {
        List<OperateLogExportDTO> data = logService.getExportOperateLogData(queryDTO);
        if ("csv".equals(type)) {
            this.exportCSV(response, null, data);
        } else if ("xls".equals(type)) {
            this.exportXls(response, null, data);
        }
    }

    private void exportCSV(HttpServletResponse response, List<LoginLogDTO> loginData, List<OperateLogExportDTO> operateData) throws IOException {
        response.setContentType("text/csv");
        response.setCharacterEncoding("utf-8");
        if (ObjectUtil.isNotEmpty(loginData) || loginData != null) {
            String fileName = "User_Access_" + DateUtil.format(DateUtil.date(), DatePattern.PURE_DATETIME_FORMAT) + ".csv";
            String outFileName = URLEncoder.encode(fileName, "UTF-8").replaceAll("\\+", "%20");
            response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + outFileName);
            EasyExcel.write(response.getOutputStream(), LoginLogDTO.class).excelType(ExcelTypeEnum.CSV).sheet("sheet1").doWrite(loginData);
        } else if (ObjectUtil.isNotEmpty(operateData) || operateData != null) {
            String fileName = "User_Activities_" + DateUtil.format(DateUtil.date(), DatePattern.PURE_DATETIME_FORMAT) + ".csv";
            String outFileName = URLEncoder.encode(fileName, "UTF-8").replaceAll("\\+", "%20");
            response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + outFileName);
            EasyExcel.write(response.getOutputStream(), OperateLogExportDTO.class).excelType(ExcelTypeEnum.CSV).sheet("sheet1").doWrite(operateData);
        }
    }

    private void exportXls(HttpServletResponse response, List<LoginLogDTO> loginData, List<OperateLogExportDTO> operateData) throws IOException {
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setCharacterEncoding("utf-8");
        if (ObjectUtil.isNotEmpty(loginData)) {
            String fileName = "User_Access_" + DateUtil.format(DateUtil.date(), DatePattern.PURE_DATETIME_FORMAT) + ".xlsx";
            String outFileName = URLEncoder.encode(fileName, "UTF-8").replaceAll("\\+", "%20");
            response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + outFileName);
            EasyExcel.write(response.getOutputStream(), LoginLogDTO.class)
                    .registerWriteHandler(getHorizontalCellStyleStrategy())
                    .registerWriteHandler(STYLE_STRATEGY)
                    .sheet("sheet1")
                    .doWrite(loginData);
        } else if (ObjectUtil.isNotEmpty(operateData)) {
            String fileName = "User_Activities_" + DateUtil.format(DateUtil.date(), DatePattern.PURE_DATETIME_FORMAT) + ".xlsx";
            String outFileName = URLEncoder.encode(fileName, "UTF-8").replaceAll("\\+", "%20");
            response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + outFileName);
            EasyExcel.write(response.getOutputStream(), OperateLogExportDTO.class)
                    .registerWriteHandler(getHorizontalCellStyleStrategy())
                    .registerWriteHandler(STYLE_STRATEGY)
                    .sheet("sheet1")
                    .doWrite(operateData);
        }
    }

    public HorizontalCellStyleStrategy getHorizontalCellStyleStrategy() {
        WriteCellStyle headWriteCellStyle = new WriteCellStyle();
        // white background color
        headWriteCellStyle.setFillForegroundColor(IndexedColors.WHITE.index);
        headWriteCellStyle.setHorizontalAlignment(HorizontalAlignment.LEFT);
        headWriteCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);

        // border
        headWriteCellStyle.setBorderBottom(BorderStyle.THIN);
        headWriteCellStyle.setBorderLeft(BorderStyle.THIN);
        headWriteCellStyle.setBorderRight(BorderStyle.THIN);
        headWriteCellStyle.setBorderTop(BorderStyle.THIN);
        // line wrap
        headWriteCellStyle.setWrapped(true);
        WriteFont headWriteFont = new WriteFont();
        headWriteFont.setBold(true);
        headWriteFont.setFontName("Calibri");
        headWriteFont.setFontHeightInPoints((short) 12);
        headWriteCellStyle.setWriteFont(headWriteFont);
        WriteCellStyle contentWriteCellStyle = new WriteCellStyle();
        return new HorizontalCellStyleStrategy(headWriteCellStyle, contentWriteCellStyle);
    }

    @PostMapping("/add-operate-log")
    public Result<Void> addOperateLog(@RequestBody OperateLogDTO queryDTO) {
        logService.addOprateLog(queryDTO);
        return messageUtils.addSucceed(null);
    }
}
