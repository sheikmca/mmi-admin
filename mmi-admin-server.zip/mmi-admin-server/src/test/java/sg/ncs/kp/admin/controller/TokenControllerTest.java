package sg.ncs.kp.admin.controller;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import sg.ncs.kp.admin.BaseTest;
import sg.ncs.kp.admin.dto.Login2FADTO;
import sg.ncs.kp.admin.service.Control2FAService;
import sg.ncs.kp.admin.service.KpUserOnlineService;
import sg.ncs.kp.admin.service.KpUserService;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.common.i18n.util.MessageUtils;
import sg.ncs.kp.uaa.client.session.UserSession;
import sg.ncs.kp.uaa.client.util.SessionUtil;
import sg.ncs.kp.uaa.common.dto.RefreshTokenDTO;
import sg.ncs.kp.uaa.server.po.User;
import sg.ncs.kp.uaa.server.service.LoginService;
import sg.ncs.kp.uaa.server.service.UserRelUserGroupMappingMapperService;
import sg.ncs.kp.uaa.server.service.UserService;
import sg.ncs.kp.vms.feign.StreamFeign;
import sg.ncs.kp.vms.feign.TakeoverControlFeign;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

/**
 * description: TODO
 *
 * @date 2022/8/26 17:23
 */
public class TokenControllerTest extends BaseTest {

    @Mock
    private LoginService loginService;

    @Mock
    private MessageUtils messageUtils;

    @InjectMocks
    private TokenController tokenController;
    
    @Mock
    private UserService userService;
    
    @Mock 
    private KpUserOnlineService kpUserOnlineService;

    @Mock
    private KpUserService kpUserService;

    @Mock
    private Control2FAService control2FAService;

    @Mock
    private StreamFeign streamFeign;

    @Mock
    private TakeoverControlFeign takeoverControlFeign;

    @Mock
    private UserRelUserGroupMappingMapperService userRelUserGroupMappingMapperService;

    @Test
    void loginTest() {
        try (MockedStatic<SessionUtil> mockedStatic = Mockito.mockStatic(SessionUtil.class)) {
            mockedStatic.when(SessionUtil::getUserId).thenReturn("id");
            Mockito.when(userService.getUser(Mockito.any())).thenReturn(new User());
            Mockito.when(userService.getUser(any())).thenReturn(new User());
            OAuth2AccessToken oAuth2AccessToken = new DefaultOAuth2AccessToken("test");
            Result<OAuth2AccessToken> result = new Result<>();
            result.setData(oAuth2AccessToken);
            Mockito.when(loginService.login(Mockito.any())).thenReturn(result);
            Mockito.when(kpUserService.checkUserIsNeed2fa(Mockito.any())).thenReturn(false);
            //Mockito.when(messageUtils.succeed(Mockito.any())).thenReturn(new Result<>());
            Mockito.when(loginService.login(any())).thenReturn(result);
            Mockito.when(kpUserService.checkUserIsNeed2fa(any())).thenReturn(false);
            //Mockito.when(messageUtils.succeed(any())).thenReturn(new Result<>());
            Login2FADTO login2FADTO = new Login2FADTO();
            login2FADTO.setUserName("userName");
            Assertions.assertDoesNotThrow(() -> tokenController.login(login2FADTO));
        }
    }

    @Test
    void logoutTest() {
        //doNothing().when(streamFeign).endLiveByUserId(any());
        try (MockedStatic<SessionUtil> mockedStatic = Mockito.mockStatic(SessionUtil.class)) {
            mockedStatic.when(SessionUtil::getUserId).thenReturn("id");
            Assertions.assertDoesNotThrow(() -> tokenController.logout());
        }
    }

    @Test
    void refreshTest() {
        try (MockedStatic<SessionUtil> mockedStatic = Mockito.mockStatic(SessionUtil.class)) {
            OAuth2AccessToken oAuth2AccessToken = new DefaultOAuth2AccessToken("test");
            mockedStatic.when(SessionUtil::getUserId).thenReturn("id");
            Mockito.when(loginService.refresh(any())).thenReturn(oAuth2AccessToken);
            Result<OAuth2AccessToken> result = new Result<>();
            result.setData(oAuth2AccessToken);
            Mockito.when(messageUtils.succeed(any(OAuth2AccessToken.class))).thenReturn(result);
            Assertions.assertDoesNotThrow(() -> tokenController.refresh(new RefreshTokenDTO()));
        }
    }

    @Test
    void getMyselfTest() {
        Mockito.when(userRelUserGroupMappingMapperService.getFullPathByUserId(anyString())).thenReturn("");
        try (MockedStatic<SessionUtil> mockedStatic = Mockito.mockStatic(SessionUtil.class)) {
            UserSession userSession = new UserSession();
            userSession.setId("userId");
            mockedStatic.when(SessionUtil::getUserSession).thenReturn(userSession);
            Assertions.assertDoesNotThrow(() -> tokenController.getMyself());
        }
    }

}
