# mmi-admin-server

## Requirement 
* openjdk:11
* spring-boot 2.6.2


## Introduction 
1. mmi-admin-server is a server provide management features of User, role, UserGroup and so on. 

## Configuration
1. I18n 
```
kp:
  uaa:
    resourceserver:
      authorizationPaths: /token/login,/inner/user/ids
      permitAllPaths: /error
  i18n:
    basename: i18n/uaaServer,i18n/admin
    defaultLocale:
      lang: en
      country: US
    supportLocales:
      - lang: zh
        country: CN
      - lang: en
        country: US
```
2. mybatis
```
mybatis-plus:
  configuration:
    map-underscore-to-camel-case: true
    auto-mapping-behavior: full
    log-impl: org.apache.ibatis.logging.stdout.StdOutImpl
  mapper-locations: classpath*:mapper/*.xml
mybatis:
  mapper:
    dialect: mysql
    location: sg.ncs.kp.uaa.server.mapper,sg.ncs.kp.admin.mapper

```
3. spring, datasource, redis
```
spring:
  application:
    name: mmi-admin
    version: @version@
    code: 01
  datasource:
    url: jdbc:mysql://${DB_IP:172.31.2.239}:${DB_PORT:3307}/${DB_NAME:mmi-uaa}?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=GMT%2b8&allowMultiQueries=true
    username: ${DB_USERNAME:root}
    password: ${DB_PASSWORD:qAcP@ssw0rd4Mys@L}
    driver-class-name: com.mysql.cj.jdbc.Driver
    autoReconnect: true
  redis:
    timeout: 6000
    sentinel:
      master: ${REDIS_MASTER_NAME:redis-master}
      nodes: ${REDIS_SENTINEL_NODES:172.31.2.207:26379}
    database: 0
    password: ${REDIS_PASSWORD:redispass}
``` 
4. eureka
```
eureka:
  instance:
    hostname: ${EUREKA_HOST:127.0.0.1}
    prefer-ip-address: true
  client:
    registerWithEureka: true
    fetchRegistry: true
    service-url:
      defaultZone: http://${eureka.instance.hostname}:${EUREKA_PORT:26500}/eureka/
```
5. oss
```
oss:
  type: local
  path: ${OSS_PATH:D://}
```

## Introduce permission related table and api 
### Database
1. Table:kp_permission
2. Field:
    1.id Primary key  
    2.type Permission type 1,module 2,menu 3,page 4,button  
    3.name Permission name  
    4.authority_key Permission identifier, used for program interface permission control (unique)
    5.sort Sort, ascending order default 999 
    6.status Status 1: enabled 0: disabled
    7.level Permission level, used to control which level of users can see this permission 1. superAdmin 2. admin 3. user
    8.parent_id The parent permission id to which this permission belongs
    9.uri Front-end page redirect path

### Interface
1. [/user/menus](https://gitlab.kaisquare.com/kaipro/kp-admin/-/blob/main/api/0.2.0/openapi.yaml#/User%20Api/get_user_menus)  
   The permission information returned by this interface does not contain data for the button (type=4). Because of i18n, the menu names for display are not maintained in the database, but are dynamically obtained by the front end based on authority_key and the configuration of i18n.
2. [/user/getMyself](https://gitlab.kaisquare.com/kaipro/kp-admin/-/blob/main/api/0.2.0/openapi.yaml#/User%20Api/get_user_getMyself)  
   This interface is used to obtain information about the current user, including basic information, role information, and permission information. All authority_keys that the user has (including buttons) can be retrieved from the permissions attribute returned.  
```json
{
  "permissions": [
    "identifiedPersonByAttributesList",
    "poiInterRegionalAnalysisList",
    "alarm",
    "poiTrack",
    "satelliteImageAnalytic",
    "humanAnalysis",
    "face",
    "frequentlyAccessRegionAnalysisEdit",
    "channelGroup",
    "......"
  ]
}
```