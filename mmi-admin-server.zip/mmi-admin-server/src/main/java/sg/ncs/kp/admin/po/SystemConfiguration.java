package sg.ncs.kp.admin.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import sg.ncs.kp.common.mybaits.base.po.BasePO;
import sg.ncs.kp.uaa.common.dto.BaseDTO;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @since 2022-09-08
 */
@Getter
@Setter
@ToString
@TableName("kp_system_configuration")
public class SystemConfiguration implements Serializable{

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.ASSIGN_ID)
    private Long id;
    @NotBlank
    private String value;
    @NotNull
    @Min(1)
    @Max(2)
    private Integer type;
}
