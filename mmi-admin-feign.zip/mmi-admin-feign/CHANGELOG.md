# ChangeLog

------
## 0.1.4
### Enhancement
- Add tenant detail/check password feign interface

## 0.1.3
### Features
- Provide get agency config feign api 

## 0.1.2
**Features**
- RecipientGroupFeign
- KpAdminFeign
- UserFeign
