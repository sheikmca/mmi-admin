package sg.ncs.kp.admin.quartz;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import sg.ncs.kp.admin.controller.TokenController;
import sg.ncs.kp.admin.pojo.AdminConstants;
import sg.ncs.kp.admin.pojo.WSMsgTypEnum;
import sg.ncs.kp.admin.service.KpUserOnlineService;
import sg.ncs.kp.admin.util.NotificationUtil;
import sg.ncs.kp.notification.pojo.NotificationConstants;
import sg.ncs.kp.uaa.client.config.UaaTokenServices;
import sg.ncs.kp.vms.feign.StreamFeign;
import sg.ncs.kp.vms.feign.TakeoverControlFeign;

import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

/**
 * @date 2022/10/18
 * @Description Remove session expired user
 */
@Slf4j
@Component
public class KpUserOnlineScheduled {

    @Autowired
    private RedisTemplate<String, String> sessionRedisTemplate;

    @Autowired
    private UaaTokenServices uaaTokenServices;
    @Autowired
    private KpUserOnlineService kpUserOnlineService;

    @Autowired
    private TokenController tokenController;

    @Autowired
    private NotificationUtil notificationUtil;

    @Autowired
    private TakeoverControlFeign takeoverControlFeign;

    @Autowired
    private StreamFeign streamFeign;

    @Value("${cron.heartbeat}")
    private Integer heartbeat;

    /**
     * Perform the check every 5 minutes
     * Check whether the current system online user has expired in Redis
     * If it expires, you are considered logged out
     */
    @Scheduled(cron = "0 */1 * * * ?")
    public void checkOnline() {
        Map<Object, Object> onlineUserMap = sessionRedisTemplate.opsForHash().entries(AdminConstants.USER_ONLINE_REDIS_KEY);
        if (CollectionUtils.isEmpty(onlineUserMap)) {
            return;
        }
        Set<String> userIds = new HashSet<>();
        for (Entry<Object, Object> userOnlineEntry : onlineUserMap.entrySet()) {
            OAuth2AccessToken oAuth2Authentication = uaaTokenServices.readAccessToken((String) userOnlineEntry.getValue());
            String userId = (String) userOnlineEntry.getKey();
            userIds.add(userId);
            if (Objects.isNull(oAuth2Authentication) || oAuth2Authentication.isExpired()) {
                log.warn("User[{}] accessToken expired.", userId);
                kpUserOnlineService.userOffline(userId, WSMsgTypEnum.EXPIRED_OFFLINE);
            }
            String lastTime = sessionRedisTemplate.opsForValue().get(AdminConstants.USER_HEARTBEAT_KEY + userId);
            if (StringUtils.isNotBlank(lastTime)) {
                if (System.currentTimeMillis() > Long.parseLong(lastTime) + heartbeat) {
                    kickOut(userId);
                    log.warn("User[{}] logout, last heartbeat time is [{}]", userId, lastTime);
                    userIds.remove(userId);
                }
            }else {
                sessionRedisTemplate.opsForValue().set(AdminConstants.USER_HEARTBEAT_KEY + userId,
                        String.valueOf(System.currentTimeMillis()), 1, TimeUnit.HOURS);
            }
        }
        if(CollectionUtils.isEmpty(userIds)){
            return;
        }
        JSONObject payload = new JSONObject();
        payload.put("type","heartbeat");
        notificationUtil.sendQueueMsgToWebSocketExchange(payload, NotificationConstants.HEARTBEAT_QUEUE, userIds);
        log.info("Send heartbeat, userIds: {}", JSON.toJSONString(userIds));
    }

    private void kickOut(String userId){
        try {
            streamFeign.endLiveByUserId(userId);
            streamFeign.endLiveByUserId(userId);
            kpUserOnlineService.forceLogout(userId);
            sessionRedisTemplate.delete(AdminConstants.USER_HEARTBEAT_KEY + userId);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
