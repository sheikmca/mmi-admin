package sg.ncs.kp.admin.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import sg.ncs.kp.admin.dto.*;
import sg.ncs.kp.admin.po.OperateLog;
import sg.ncs.kp.uaa.client.dto.OperateLogDTO;
import sg.ncs.kp.uaa.server.po.LoginLog;

import java.util.List;

/**
 * @auther 
 * @date 2022/9/8
 * @description
 */
public interface LogService {
    /**
     * login record
     * @param queryDTO
     * @return
     */
    Page<LoginLog> loginRecords(LoginLogQueryDTO queryDTO);

    /**
     * get export login log record
     * @param queryDTO
     * @return
     */
    List<LoginLogDTO> getExportLoginLogData(LoginLogQueryDTO queryDTO);

    /**
     * operate record
     * @param queryDTO
     * @return
     */
    Page<OperateLog> operateRecords(OperateLogQueryDTO queryDTO);

    /**
     * get export operate log record
     * @param queryDTO
     * @return
     */
    List<OperateLogExportDTO> getExportOperateLogData(OperateLogQueryDTO queryDTO);

    void addOprateLog(OperateLogDTO operateLogDTO);
}
