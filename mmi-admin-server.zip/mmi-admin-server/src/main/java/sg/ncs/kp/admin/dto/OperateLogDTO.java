package sg.ncs.kp.admin.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @since 2023-11-21
 */
@Getter
@Setter
@ToString
public class OperateLogDTO {

    private Integer id;
    private String userId;
    private String tenantId;
    @ExcelProperty(value = "User ID",index = 0)
    private Integer userIdNum;
    @ExcelProperty(value = "User Name",index = 1)
    private String userName;
    private String module;
    private String requestData;
    private String responseData;
    @ExcelProperty(value = "Date",index = 5)
    @DateTimeFormat("dd/MM/yyyy HH:mm:ss")
    private Date logTime;
    @ExcelProperty(value = "Operation Type",index = 4)
    private String operateType;
    @ExcelProperty(value = "IP",index = 3)
    private String ip;
    private String phone;
    private String email;
    @ExcelProperty(value = "User Group Name",index = 2)
    private String userGroupName;
}
