package sg.ncs.kp.northbound.service.impl;

import cn.hutool.core.util.ObjectUtil;
import feign.FeignException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import sg.ncs.kp.alarm.feign.QueryFeign;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.common.exception.pojo.ClientServiceException;
import sg.ncs.kp.northbound.pojo.common.VmsUpstreamException;
import sg.ncs.kp.northbound.service.VaAnnotateAlertNBService;
import sg.ncs.kp.vap.pojo.sdk.dto.query.AlertMetadataDTO;

@Slf4j
@Service
@RequiredArgsConstructor
public class VaAnnotateAlertNBServiceImpl implements VaAnnotateAlertNBService {

    private final QueryFeign queryFeign;

    @Override
    public Result<Void> updateAlarm(@Valid AlertMetadataDTO dto) {

        // -------------------------
        // BASIC VALIDATION
        // -------------------------
        if (dto == null) {
            throw VmsUpstreamException.badRequest(
                    "invalid-alert-id",
                    "'id' is required and must be a non-empty string."
            );
        }
        String alarmId = dto.getId();
        if (ObjectUtil.isEmpty(alarmId)) {
            log.error("NB → updateAlarm failed: Alarm ID must not be null. DTO={}", dto);
            throw VmsUpstreamException.badRequest(
                    "invalid-alert-id",
                    "'id' is required and must be a non-empty string."
            );
        }


        // Validate isFalsePositive explicitly (spec-driven)
        if (dto.getIsFalsePositive() == null) {
            throw VmsUpstreamException.badRequest(
                    "invalid-false-positive",
                    "'isFalsePositive' is required and must be either 'true' or 'false'."
            );
        }


        log.info("NB → Forwarding updateAlarm request to VAP. AlarmId={}, DTO={}", alarmId, dto);

        try {
            // -------------------------
            // FEIGN CALL
            // -------------------------
            Result<Void> result = queryFeign.updateAlarm(alarmId, dto);
            if (result == null) {
                throw VmsUpstreamException.upstreamError(
                        "vap-null-response",
                        "Null response from VAP updateAlarm"
                );
            }

            if (Boolean.FALSE.equals(result.getStatus())) { String code = result.getCode();
                String msg  = result.getMsg();

                log.warn("VAP → updateAlarm business error. code={}, msg={}", code, msg);

                switch (code) {

                    // -------- 400 --------
                    case "invalid-alert-id":
                    case "invalid-false-positive":
                        throw VmsUpstreamException.badRequest(code, msg);

                        // -------- 404 --------
                    case "alert-not-found":
                        throw VmsUpstreamException.notFound(code, msg);

                        // -------- FALLBACK --------
                    default:
                        throw VmsUpstreamException.upstreamError(
                                code != null ? code : "vap-error",
                                msg != null ? msg : "VAP update alarm failed"
                        );
                }
            }

            // -------------------------
            // SUCCESS
            // -------------------------
            return result;
        }// -------------------------
        // HTTP-LEVEL FAILURES
        // -------------------------
        catch (FeignException.BadRequest ex) {

            String body = ex.contentUTF8();
            log.warn("VAP → 400 BadRequest. body={}", body);

            if (body != null && body.contains("invalid-false-positive")) {
                throw VmsUpstreamException.badRequest(
                        "invalid-false-positive",
                        "'isFalsePositive' is required and must be either 'true' or 'false'."
                );
            }

            throw VmsUpstreamException.badRequest(
                    "invalid-alert-id",
                    "'id' is required and must be a non-empty string."
            );
        }

        catch (FeignException.NotFound ex) {
            throw VmsUpstreamException.notFound(
                    "alert-not-found",
                    "Can not find the alert"
            );
        }

        catch (FeignException.Unauthorized ex) {
            throw VmsUpstreamException.unauthorized(
                    "unauthorized",
                    "Unauthorized request"
            );
        }

        catch (FeignException.Forbidden ex) {
            throw VmsUpstreamException.forbidden(
                    "forbidden",
                    "Access denied"
            );
        }

        catch (FeignException ex) {
            log.error("VAP unreachable during updateAlarm", ex);
            throw VmsUpstreamException.upstreamError(
                    "vap-unreachable",
                    "VAP service unavailable"
            );
        }

        catch (Exception ex) {
            log.error("NB → Unexpected error while calling VAP updateAlarm", ex);
            throw VmsUpstreamException.upstreamError(
                    "internal-error",
                    "Failed to update alarm in VAP"
            );
        }
    }

}
