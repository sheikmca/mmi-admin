package sg.ncs.kp.northbound.feign;

import sg.ncs.kp.northbound.pojo.channel.ChannelListRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name="mmi-vms", path="/inner/vms/channel")
public interface ChannelFeign {

    @PostMapping("/list")
    Object findChannels(@RequestBody ChannelListRequest req);
}
