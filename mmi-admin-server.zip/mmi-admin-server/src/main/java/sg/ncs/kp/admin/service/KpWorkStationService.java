package sg.ncs.kp.admin.service;

import sg.ncs.kp.admin.dto.WorkStationUserDTO;

import java.util.List;

public interface KpWorkStationService {

    List<WorkStationUserDTO> getAll();

}
