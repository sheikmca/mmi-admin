package sg.ncs.kp.northbound.service;

import sg.ncs.kp.northbound.pojo.channel.ChannelListRequest;

public interface ChannelService {
    Object getChannelList(ChannelListRequest req);
}
