package sg.ncs.kp.admin.service;

import org.springframework.web.bind.annotation.RequestParam;
import sg.ncs.kp.admin.dto.WorkspaceDTO;
import sg.ncs.kp.common.core.response.PageResult;
import sg.ncs.kp.uaa.common.dto.UserRoleBasicDTO;

import java.util.List;

/**
 * @className WorkspaceService
 * @version 1.0.0
 * @date 2023-07-25
 */
public interface WorkspaceService {

    /**
     * sava workspace
     * @param workspaceDTO id=null is add |id!=null modify
     */
    WorkspaceDTO saveOrUpdateWorkspace(WorkspaceDTO workspaceDTO);

    WorkspaceDTO updateWorkspace(WorkspaceDTO workspaceDTO);

    WorkspaceDTO copyWorkspace(Long id);

    WorkspaceDTO resetWorkspace(Long id);

    void assignWorkspace(Long id, List<Long> roleIds);

    void deleteWorkspace(Long id);

    void setDefaultNormal(Long id);

    PageResult<WorkspaceDTO> list(String name, String userId, String setType, Integer pageNo, Integer pageSize);

    WorkspaceDTO view();

    WorkspaceDTO getDefaultInfoByNormalId(Long normalId);

    WorkspaceDTO get(String id);

    void deleteCurrentWs(String userId);

    void addUserWs(Long roleId,List<UserRoleBasicDTO> userRoleBasicDTOS);


}
