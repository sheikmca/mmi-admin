package sg.ncs.kp.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import sg.ncs.kp.admin.po.OperateLog;

/**
 * <p>
 *  Mapper
 * </p>
 *
 * @since 2022-09-08
 */
public interface OperateLogMapper extends BaseMapper<OperateLog> {

}
