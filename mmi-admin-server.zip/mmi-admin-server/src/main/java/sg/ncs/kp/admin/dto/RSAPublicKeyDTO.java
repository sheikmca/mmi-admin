package sg.ncs.kp.admin.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * @className RSAPublicKeyDTO
 * @version 1.0.0
 * @date 2023-11-24
 */
@Getter
@Setter
public class RSAPublicKeyDTO {
    @JsonProperty("public_key")
    private String publicKey;
}
