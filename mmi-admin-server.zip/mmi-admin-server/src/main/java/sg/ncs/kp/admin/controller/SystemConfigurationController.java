package sg.ncs.kp.admin.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import sg.ncs.kp.admin.mapper.SystemConfigurationMapper;
import sg.ncs.kp.admin.po.SystemConfiguration;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.common.i18n.util.MessageUtils;

import javax.validation.Valid;

@RestController
@RequestMapping("/system/configuration")
public class SystemConfigurationController {

    @Autowired
    private SystemConfigurationMapper systemConfigurationMapper;

    @Autowired
    private MessageUtils messageUtils;

    @GetMapping("/{type}")
    @PreAuthorize("hasAnyAuthority('systemConfiguration','dashboard')")
    public Result<SystemConfiguration> get(@PathVariable("type") Integer type){
        SystemConfiguration configuration = systemConfigurationMapper.selectOne(
                Wrappers.<SystemConfiguration>lambdaQuery().eq(SystemConfiguration::getType, type));
        return messageUtils.succeed(configuration);
    }

    @PostMapping
    @PreAuthorize("hasAuthority('systemConfiguration')")
    public Result<Object> addOrUpdate(@Valid @RequestBody SystemConfiguration systemConfiguration){
        SystemConfiguration configuration = systemConfigurationMapper.selectOne(Wrappers.<SystemConfiguration>lambdaQuery()
                .eq(SystemConfiguration::getType, systemConfiguration.getType()));
        if(configuration == null){
            systemConfigurationMapper.insert(systemConfiguration);
        }else {
            configuration.setValue(systemConfiguration.getValue());
            systemConfigurationMapper.updateById(configuration);
        }
        return messageUtils.addSucceed(null);
    }
}
