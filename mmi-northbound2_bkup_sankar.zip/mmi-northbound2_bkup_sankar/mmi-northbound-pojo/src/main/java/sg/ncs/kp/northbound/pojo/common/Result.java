package sg.ncs.kp.northbound.pojo.common;

import lombok.Data;

/**
 * Standardized API response wrapper for Northbound services.
 *
 * @param <T> the type of the response payload
 */
@Data
public class Result<T> {

    private boolean status;      // true = success, false = failure
    private String code;         // business code, e.g. "0", "ERR001"
    private String msg;          // message describing success or error
    private T data;              // response payload
    private Integer httpStatus;  // HTTP status to be returned upstream

    // Private constructor (enforces static factory usage)
    private Result() {}

    /**
     * Creates a success response with default HTTP 200.
     */
    public static <T> Result<T> ok(T data) {
        Result<T> r = new Result<>();
        r.status = true;
        r.code = "0";
        r.msg = "success";
        r.data = data;
        r.httpStatus = 200;
        return r;
    }

    /**
     * Creates a success response with a custom HTTP status.
     */
    public static <T> Result<T> ok(T data, int httpStatus) {
        Result<T> r = new Result<>();
        r.status = true;
        r.code = "0";
        r.msg = "success";
        r.data = data;
        r.httpStatus = httpStatus;
        return r;
    }

    /**
     * Creates a failure response.
     */
    public static <T> Result<T> fail(String code, String msg, int httpStatus) {
        Result<T> r = new Result<>();
        r.status = false;
        r.code = code;
        r.msg = msg;
        r.data = null;
        r.httpStatus = httpStatus;   // FIXED: previously ignored the httpStatus parameter
        return r;
    }

    public static <T> Result<T> fail(String code, String msg) {
        Result<T> r = new Result<>();
        r.status = false;
        r.code = code;
        r.msg = msg;
        r.data = null;
        return r;
    }
    public static <T> Result<T> fail(String code, String msg, Object... params) {
        Result<T> r = new Result<>();
        r.status = false;
        r.code = code;
        r.msg = formatMessage(msg, params);
        return r;
    }

    private static String formatMessage(String msg, Object[] params) {
        if (msg == null || params == null || params.length == 0) {
            return msg;
        }

        try {
            // Replace {} placeholders (SLF4J-style)
            for (Object param : params) {
                msg = msg.replaceFirst("\\{\\}", String.valueOf(param));
            }
            return msg;
        } catch (Exception e) {
            return msg; // fallback – never break response
        }
    }
}
