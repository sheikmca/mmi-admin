package sg.ncs.kp.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import sg.ncs.kp.admin.po.RoleAreaMapping;

/**
 * @date 2022/8/23
 */
public interface RoleAreaMappingMapper extends BaseMapper<RoleAreaMapping> {
}
