package sg.ncs.kp.northbound.service.impl;

import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import sg.ncs.kp.alarm.feign.QueryFeign;
import sg.ncs.kp.common.core.response.PageResult;
import sg.ncs.kp.common.exception.pojo.ClientServiceException;
import sg.ncs.kp.northbound.pojo.common.VmsUpstreamException;
import sg.ncs.kp.northbound.service.VaSearchEventNBService;
import sg.ncs.kp.vap.pojo.sdk.dto.analytics.EventOrAlertDTO;
import sg.ncs.kp.vap.pojo.sdk.dto.query.AggregateResultQuery;

@Slf4j
@Service
@RequiredArgsConstructor
public class VaSearchEventNBServiceImpl implements VaSearchEventNBService {

    private final QueryFeign queryFeign;

    @Override
    public PageResult<EventOrAlertDTO> searchEventHistory(AggregateResultQuery dto) {

        // -------------------------
        // BASIC VALIDATION
        // -------------------------
        if (dto == null) {
            log.warn("NB → searchEventHistory called with NULL DTO");
            throw VmsUpstreamException.badRequest(
                    "invalid-request",
                    "AggregateResultQuery cannot be null"
            );
        }

        log.info("NB → Calling VAP event search API with DTO: {}", dto);

        try {
            // -------------------------
            // FEIGN CALL
            // -------------------------
            return queryFeign.searchEventHistory(dto);

        } // -------------------------
        // HTTP 400 MAPPING
        // -------------------------
        catch (FeignException.BadRequest ex) {

            String body = ex.contentUTF8();
            log.warn("VAP → Bad request. body={}", body);

            if (body.contains("invalid-page-index")) {
                throw VmsUpstreamException.badRequest(
                        "invalid-page-index",
                        "'page.index' is invalid"
                );
            }

            if (body.contains("invalid-page-size")) {
                throw VmsUpstreamException.badRequest(
                        "invalid-page-size",
                        "'page.size' is invalid"
                );
            }

            if (body.contains("invalid-page")) {
                throw VmsUpstreamException.badRequest(
                        "invalid-page",
                        "'page' is invalid"
                );
            }

            if (body.contains("invalid-filters")) {
                throw VmsUpstreamException.badRequest(
                        "invalid-filters",
                        "'filters' is invalid"
                );
            }

            if (body.contains("invalid-sort-of-index")) {
                Integer index = extractIndex(body);
                throw VmsUpstreamException.badRequest(
                        "invalid-sort-of-index",
                        "Invalid sort element at index {}.",
                        index
                );
            }

            if (body.contains("invalid-sort")) {
                throw VmsUpstreamException.badRequest(
                        "invalid-sort",
                        "'sorts' is invalid"
                );
            }

            // fallback
            throw VmsUpstreamException.badRequest(
                    "invalid-request",
                    "Invalid request parameters"
            );
        }

        // -------------------------
        // AUTH FAILURES
        // -------------------------
        catch (FeignException.Unauthorized ex) {
            throw VmsUpstreamException.unauthorized(
                    "unauthorized",
                    "Unauthorized request"
            );

        } catch (FeignException.Forbidden ex) {
            throw VmsUpstreamException.forbidden(
                    "forbidden",
                    "Access denied"
            );

        }
        // -------------------------
        // UPSTREAM FAILURE
        // -------------------------
        catch (FeignException ex) {
            log.error("VAP unreachable while searching event history", ex);
            throw VmsUpstreamException.upstreamError(
                    "vap-unreachable",
                    "VAP service unreachable"
            );

        } catch (Exception ex) {
            log.error("NB → Unexpected error searching event history", ex);
            throw VmsUpstreamException.upstreamError(
                    "internal-error",
                    "Failed to fetch event history from VAP"
            );
        }
    }
    private Integer extractIndex(String body) {
        try {
            return Integer.parseInt(body.replaceAll("\\D+", ""));
        } catch (Exception e) {
            return null;
        }
    }
}
