package sg.ncs.kp.admin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import sg.ncs.kp.admin.po.RoleWorkspaceMapping;

import java.util.List;

/**
 * @version 1.0.0
 * @className RoleWorkspaceService
 * @date 2023-08-29
 */
public interface RoleWorkspaceService extends IService<RoleWorkspaceMapping> {
    List<RoleWorkspaceMapping> getAllByWorkspaceId(Long workspaceId);

    List<RoleWorkspaceMapping> getAllByRoleIds(List<Integer> roleIds);

    Boolean existWorkspaceByRoleId(Long roleId);

    void deleteBatch(Long workspaceId, List<Long> roleIds);

    void deleteBatchByRoleIds(List<Long> roleIds);

    void deleteBatchByWsIds(List<Long> workspaceIds);

    void deleteBatchNotWorkspaceId(List<Integer> roleIds, Integer workspaceId);

    void deleteBatch(Long workspaceId);

    void deleteOne(String userId);

    RoleWorkspaceMapping getByUserId(String userId);

    RoleWorkspaceMapping getDefaultWsByRoleId(Long roleId);
}
