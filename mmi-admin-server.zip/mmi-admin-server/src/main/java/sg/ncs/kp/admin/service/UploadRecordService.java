package sg.ncs.kp.admin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import sg.ncs.kp.admin.po.UploadRecord;

/**
 * <p>
 * upload record info table service
 * </p>
 *
 * @since 2022-08-21
 */
public interface UploadRecordService extends IService<UploadRecord> {

}
