package sg.ncs.kp.admin.service.impl;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.text.CharPool;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import sg.ncs.kp.admin.dto.WorkspaceDTO;
import sg.ncs.kp.admin.enums.AdminMsgEnum;
import sg.ncs.kp.admin.enums.FrontSizeTypeEnum;
import sg.ncs.kp.admin.enums.SetTypeEnum;
import sg.ncs.kp.admin.enums.ThemeTypeEnum;
import sg.ncs.kp.admin.mapper.WorkspaceMapper;
import sg.ncs.kp.admin.po.*;
import sg.ncs.kp.admin.service.RoleWorkspaceService;
import sg.ncs.kp.admin.service.WorkspaceService;
import sg.ncs.kp.common.core.response.PageResult;
import sg.ncs.kp.common.exception.pojo.ServiceException;
import sg.ncs.kp.common.i18n.util.MessageUtils;
import sg.ncs.kp.uaa.client.session.UserSession;
import sg.ncs.kp.uaa.client.util.SessionUtil;
import sg.ncs.kp.uaa.common.dto.UserRoleBasicDTO;
import sg.ncs.kp.uaa.common.enums.StatusEnum;
import sg.ncs.kp.uaa.server.po.Role;
import sg.ncs.kp.uaa.server.po.User;
import sg.ncs.kp.uaa.server.service.RoleService;
import sg.ncs.kp.uaa.server.service.UserService;
import sg.ncs.kp.vms.feign.ChannelFeign;

import java.util.*;
import java.util.stream.Collectors;
/**
 * @className WorkspaceServiceImpl
 * @version 1.0.0
 * @date 2023-07-25
 */

@Slf4j
@Service
public class WorkspaceServiceImpl implements WorkspaceService {

    @Autowired
    private WorkspaceMapper workspaceMapper;
    @Autowired
    private RoleWorkspaceService roleWorkspaceService;
    @Autowired
    private RoleService roleService;
    @Autowired
    private UserService userService;

    @Autowired
    private MessageUtils messageUtils;

    @Autowired
    private ChannelFeign channelFeign;

    public void setSystemRoleId(Long systemRoleId) {
        this.systemRoleId = systemRoleId;
    }

    @Value("${admin.systemRoleId}")
    private Long systemRoleId;

    @Override
    public WorkspaceDTO saveOrUpdateWorkspace(WorkspaceDTO workspaceDTO) {
        UserSession userSession = SessionUtil.getUserSession();
        WorkspaceDTO result;
        Long roleId = null;
        Long workspaceId;
        List<Long> bindingRoleIds = workspaceDTO.getRoleIds();
        if(ObjectUtil.isEmpty(bindingRoleIds)){
            bindingRoleIds = new ArrayList<>();
        }
        if(ObjectUtil.isNotEmpty(SessionUtil.getRoles())){
            List<Long> roleIds = new ArrayList<>(SessionUtil.getRoles());
            roleId = roleIds.get(0);
        }
        //name duplicate
        Integer count = repeatNameCheck(userSession.getTenantId(), workspaceDTO.getName(), workspaceDTO.getBindingId(),workspaceDTO.getId());
        if (count > 0) {
            throw new ServiceException(AdminMsgEnum.WORKSPACE_NAME_REPEAT);
        }
        Workspace workspace = null;
        if(ObjectUtil.isNotEmpty(workspaceDTO.getId())) {
            workspace = workspaceMapper.selectById(workspaceDTO.getId());
        }
        workspace = setWorkspace(workspaceDTO, workspace, userSession.getTenantId(), userSession.getId());
        if (ObjectUtil.isEmpty(workspace.getId())) {
            workspaceMapper.insert(workspace);
            workspaceId = workspace.getId();
            result = getWorkspaceDTO(workspace);
        } else {
            if(workspace.getSetType().equals(SetTypeEnum.DEFAULT.getKey())){
                workspace.setBindingId(null);
            }
            workspaceMapper.updateById(workspace);
            workspaceId = workspace.getId();
            result = getWorkspaceDTO(workspace);
        }
        //bind role
        if(ObjectUtil.isNotEmpty(bindingRoleIds) && bindingRoleIds.size() > 0){
            assignWorkspace(workspaceId,bindingRoleIds);
        }
        bindingRoleIds.remove(roleId);
        result.setRoleIds(bindingRoleIds);
        return result;
    }

    @Override
    public WorkspaceDTO updateWorkspace(WorkspaceDTO workspaceDTO) {
        UserSession userSession = SessionUtil.getUserSession();
        WorkspaceDTO result;
        //name duplicate
        Integer count = repeatNameCheck(userSession.getTenantId(), workspaceDTO.getName(), workspaceDTO.getBindingId(),workspaceDTO.getId());
        if (count > 0) {
            throw new ServiceException(AdminMsgEnum.WORKSPACE_NAME_REPEAT);
        }
        Workspace workspace = workspaceMapper.selectById(workspaceDTO.getId());
        workspace = setWorkspace(workspaceDTO, workspace, userSession.getTenantId(), userSession.getId());
        if(workspace.getSetType().equals(SetTypeEnum.DEFAULT.getKey())){
            workspace.setBindingId(null);
        }
        workspaceMapper.updateById(workspace);
        result = getWorkspaceDTO(workspace);
        Long roleId = null;
        List<Long> bindingRoleIds = workspaceDTO.getRoleIds();
        if(ObjectUtil.isEmpty(bindingRoleIds)){
            bindingRoleIds = new ArrayList<>();
        }
        result.setRoleIds(bindingRoleIds);
        return result;
    }

    @Override
    public WorkspaceDTO copyWorkspace(Long id) {
        WorkspaceDTO result = new WorkspaceDTO();
        UserSession userSession = SessionUtil.getUserSession();
        Workspace workspace = workspaceMapper.selectById(id);
        if(ObjectUtil.isNotEmpty(workspace)) {
            Workspace copyWorkspace = new Workspace();
            BeanUtil.copyProperties(workspace,copyWorkspace);
            copyWorkspace.setId(null);
            copyWorkspace.setSetType(SetTypeEnum.DEFAULT.getKey());
            copyWorkspace.setCreatedId(userSession.getId());
            copyWorkspace.setLastUpdatedId(userSession.getId());
            copyWorkspace.setCreatedDate(DateUtil.date());
            copyWorkspace.setLastUpdatedDate(DateUtil.date());
            copyWorkspace.setName(getCopyName(id, workspace.getName()));
            copyWorkspace.setAdminDefaultNormal(null);
            workspaceMapper.insert(copyWorkspace);
            result = getWorkspaceDTO(copyWorkspace);
        }
        return result;
    }

    private String getCopyName(Long copyId, String bindName){
        Long count = workspaceMapper.selectCount(Wrappers
                .<Workspace>lambdaQuery()
                .eq(Workspace::getBindingId, copyId)
                .eq(Workspace::getTenantId, SessionUtil.getTenantId()));
        if(count == 0){
            return bindName+" copy"+(count+1);
        }else{
            Long index = count+1;
            String name = bindName+" copy"+index;
            while(workspaceMapper.selectCount(Wrappers
                    .<Workspace>lambdaQuery()
                    .eq(Workspace::getName, name)
                    .eq(Workspace::getTenantId, SessionUtil.getTenantId())) != 0){
                index++;
                name = bindName+" copy"+index;
            }
            return name;
        }
    }

    private String getInitUserWsName(String bindName,String userName){
       return bindName+"_"+userName;
    }

    @Override
    public WorkspaceDTO resetWorkspace(Long id) {
        WorkspaceDTO result = new WorkspaceDTO();
        UserSession userSession = SessionUtil.getUserSession();
        Workspace workspace = workspaceMapper.selectById(id);
        if(ObjectUtil.isNotEmpty(workspace)) {
            if(workspace.getSetType().equals(1)){
                throw new ServiceException(AdminMsgEnum.WORKSPACE_RESET_TYPE_ERROR);
            }
            Workspace defaultWorkspace = workspaceMapper.selectById(workspace.getBindingId());
            if(ObjectUtil.isEmpty(defaultWorkspace)){
                throw new ServiceException(AdminMsgEnum.WORKSPACE_DEFAULT_ALREADY_DEL);
            }
            workspace.setFrontSize(defaultWorkspace.getFrontSize());
            workspace.setDashboardSetting(defaultWorkspace.getDashboardSetting());
            workspace.setFrontStyle(defaultWorkspace.getFrontStyle());
            workspace.setEoSetting(defaultWorkspace.getEoSetting());
            workspace.setRoiColor(defaultWorkspace.getRoiColor());
            workspace.setMaskAreaColor(defaultWorkspace.getMaskAreaColor());
            workspace.setTrackNum(defaultWorkspace.getTrackNum());
            workspace.setTheme(defaultWorkspace.getTheme());
            workspace.setNfoaSetting(defaultWorkspace.getNfoaSetting());
            workspace.setLastUpdatedId(userSession.getId());
            workspace.setLastUpdatedDate(DateUtil.date());
            workspaceMapper.updateById(workspace);
            result = getWorkspaceDTO(workspace);
        }
        return result;
    }

    @Override
    public PageResult<WorkspaceDTO> list(String name, String userId, String setType, Integer pageNo, Integer pageSize){
        Long roleId = systemRoleId;
        Integer setTypeInt = null;
        if(ObjectUtil.isNotEmpty(setType)) {
            setTypeInt = SetTypeEnum.getKeyByValue(setType);
        }
        IPage<Workspace> workspaces = null;
        Page<Workspace> page = new Page<>(pageNo,pageSize);
        if(systemRoleId.equals(roleId)){
            workspaces = workspaceMapper.listAll(page,name, setTypeInt, SessionUtil.getTenantId());
        }else {
            workspaces = workspaceMapper.list(page,name, roleId, setTypeInt, SessionUtil.getTenantId());
        }
        List<WorkspaceDTO> results = new ArrayList<>();
        if(ObjectUtil.isNotEmpty(workspaces.getRecords())){
            for(Workspace workspace:workspaces.getRecords()){
                WorkspaceDTO workspaceDTO = this.getWorkspaceDTO(workspace);
                RoleWorkspaceMapping mapping = this.getMappingByWorkspaceId(workspaceDTO.getId());
                if(ObjectUtil.isNotEmpty(mapping)){
                    workspaceDTO.setRoleId(mapping.getRoleId());
                    workspaceDTO.setRoleName(this.getBindRoleName(mapping.getRoleId()));
                    workspaceDTO.setUserId(mapping.getUserId());
                    workspaceDTO.setUserName(this.getBindUserName(mapping.getUserId()));
                }
                results.add(workspaceDTO);
            }
        }
        return messageUtils.pageResult(pageNo, pageSize, workspaces.getTotal(), results);
    }

    private List<Workspace> getNormalWorkspacesByDefaultId(Long defaultId, UserSession userSession){
        return workspaceMapper.selectList(Wrappers.<Workspace>lambdaQuery()
                .eq(Workspace::getSetType,SetTypeEnum.NORMAL.getKey())
                .eq(Workspace::getBindingId,defaultId)
                .eq(Workspace::getTenantId,userSession.getTenantId()));
    }
    @Override
    public WorkspaceDTO view(){
        WorkspaceDTO workspaceDTO = null;
        UserSession userSession = SessionUtil.getUserSession();
        String userId = userSession.getId();
        Workspace workspace = workspaceMapper.selectCurrentWsByUserId(userId);
        if(ObjectUtil.isNotEmpty(workspace)){
            workspaceDTO = this.getWorkspaceDTO(workspace);
            RoleWorkspaceMapping mapping = this.getMappingByWorkspaceId(workspaceDTO.getId());
            if(ObjectUtil.isNotEmpty(mapping)){
                workspaceDTO.setRoleId(mapping.getRoleId());
                workspaceDTO.setRoleName(this.getBindRoleName(mapping.getRoleId()));
                workspaceDTO.setUserId(mapping.getUserId());
                workspaceDTO.setUserName(this.getBindUserName(mapping.getUserId()));
            }
            if(ObjectUtil.isNotEmpty(workspaceDTO.getDashboardSetting()) && ObjectUtil.isNotEmpty(workspaceDTO.getDashboardSetting().get("previewChanneList"))){
                JSONObject setting = workspaceDTO.getDashboardSetting();
                JSONArray previewChannelList = setting.getJSONArray("previewChanneList");
                List<JSONObject> newPreviewChannelList = new ArrayList<>();
                Set<String> channelIds = channelFeign.findAllChannelIds(userSession.getRoleId());
                for(Object channelObject:previewChannelList){
                    if (channelObject instanceof JSONObject) {
                        JSONObject channel = (JSONObject) channelObject;
                        String channelId = channel.getString("channelId");
                        Boolean isPermission = false;
                        if(channelIds.contains(channelId)){
                            isPermission = true;
                        }
                        channel.put("isPermission",isPermission);
                        newPreviewChannelList.add(channel);
                    }
                }
                setting.put("previewChanneList",newPreviewChannelList);
                workspaceDTO.setDashboardSetting(setting);
            }
        }
        return workspaceDTO;
    }
    @Override
    public WorkspaceDTO getDefaultInfoByNormalId(Long normalId){
        WorkspaceDTO workspaceDTO = null;

        Workspace normalWorkspace = workspaceMapper.selectById(normalId);
        if(ObjectUtil.isEmpty(normalWorkspace) || ObjectUtil.isEmpty(normalWorkspace.getBindingId())){
            return workspaceDTO;
        }
        Workspace defaultWorkspace = workspaceMapper.selectById(normalWorkspace.getBindingId());
        if(ObjectUtil.isNotEmpty(defaultWorkspace)){
            workspaceDTO = this.getWorkspaceDTO(defaultWorkspace);
            RoleWorkspaceMapping mapping = this.getMappingByWorkspaceId(workspaceDTO.getId());
            if(ObjectUtil.isNotEmpty(mapping)){
                workspaceDTO.setRoleId(mapping.getRoleId());
                workspaceDTO.setRoleName(this.getBindRoleName(mapping.getRoleId()));
                workspaceDTO.setUserId(mapping.getUserId());
                workspaceDTO.setUserName(this.getBindUserName(mapping.getUserId()));
            }
        }
        return workspaceDTO;
    }

    private String getBindRoleName(Long roleId) {
        if(ObjectUtil.isEmpty(roleId)){
            return null;
        }
        Role role = roleService.getById(roleId);
        if (ObjectUtil.isNotEmpty(role)) {
            return role.getName();
        }
        return null;
    }

    private String getBindUserName(String userId){
        if(ObjectUtil.isEmpty(userId)){
            return null;
        }
       User user = userService.getById(userId);
       if(ObjectUtil.isEmpty(user)){
           return null;
       }else{
           return user.getUserName();
       }
    }

    @Override
    public void assignWorkspace(Long id, List<Long> roleIds){
        Workspace workspace = workspaceMapper.selectById(id);
        if(ObjectUtil.isEmpty(workspace)){
            return ;
        }
        UserSession userSession = SessionUtil.getUserSession();
        // 1.delete previous current workspace
        // 1) get all previous current workspace
        List<Workspace> preCurrentWs = this.getNormalWorkspacesByDefaultId(workspace.getId(),userSession);
        List<Long> preWsIds = new ArrayList<>();
        if(ObjectUtil.isNotEmpty(preCurrentWs)){
            preWsIds.addAll(preCurrentWs.stream().map(Workspace::getId).collect(Collectors.toList()));
            // 2) delete previous current workspace
            workspaceMapper.deleteBatchIds(preWsIds);
        }
        // 2.delete previous workspace mapping
        preWsIds.add(id);
        roleWorkspaceService.deleteBatchByWsIds(preWsIds);
        // 3. get user infos by roleIds
        List<UserRoleBasicDTO> roleUsers = userService.getUsersByRoleIds(roleIds);
        if(ObjectUtil.isNotEmpty(roleUsers)) {
            Set<String> userIds = roleUsers.stream().map(UserRoleBasicDTO::getUserId).collect(Collectors.toSet());
            // 4.delete previous role user current workspace
            this.workspaceMapper.delCurrentWsByUserIds(userIds);
        }
        // 5.delete previous role and workspace mapping
        roleWorkspaceService.deleteBatchByRoleIds(roleIds);
        // 6. add default workspace mapping
        this.batchAddDefaultMappings(roleIds,id);
        if(ObjectUtil.isNotEmpty(roleUsers)) {
            //7 .batch add current workspace and mapping
            this.batchAddCurrentWsAndMapping(roleUsers, workspace, userSession);
        }

    }

    private void batchAddCurrentWsAndMapping(List<UserRoleBasicDTO> userRoleBasicDTOS, Workspace defaultWorkspace,UserSession userSession){
        List<RoleWorkspaceMapping> roleWorkspaceMappings = new ArrayList<>();
        for(UserRoleBasicDTO userRole:userRoleBasicDTOS){
            Workspace copyWorkspace = new Workspace();
            BeanUtil.copyProperties(defaultWorkspace,copyWorkspace);
            copyWorkspace.setId(null);
            copyWorkspace.setSetType(SetTypeEnum.NORMAL.getKey());
            copyWorkspace.setCreatedId(userSession.getId());
            copyWorkspace.setLastUpdatedId(userSession.getId());
            copyWorkspace.setCreatedDate(DateUtil.date());
            copyWorkspace.setLastUpdatedDate(DateUtil.date());
            copyWorkspace.setName(this.getInitUserWsName(defaultWorkspace.getName(),userRole.getUserName()));
            copyWorkspace.setAdminDefaultNormal(null);
            copyWorkspace.setBindingId(defaultWorkspace.getId());
            workspaceMapper.insert(copyWorkspace);
            roleWorkspaceMappings.add(this.setMapping(userRole.getRoleId(),userRole.getUserId(),copyWorkspace.getId()));
        }
        roleWorkspaceService.saveBatch(roleWorkspaceMappings);
    }

    private RoleWorkspaceMapping setMapping(Long roleId,String userId,Long workspaceId){
        RoleWorkspaceMapping roleWorkspaceMapping = new RoleWorkspaceMapping();
        roleWorkspaceMapping.setWorkspaceId(workspaceId);
        roleWorkspaceMapping.setRoleId(roleId);
        roleWorkspaceMapping.setUserId(userId);
        return roleWorkspaceMapping;
    }

    @Override
    public void deleteWorkspace(Long id){
        Workspace workspace = workspaceMapper.selectById(id);
        if(ObjectUtil.isNotEmpty(workspace)) {
            if(workspace.getSetType().equals(SetTypeEnum.DEFAULT.getKey())) {
                UserSession userSession = SessionUtil.getUserSession();
                if(ObjectUtil.isNotEmpty(this.getNormalWorkspacesByDefaultId(id,userSession))) {
                    throw new ServiceException(AdminMsgEnum.WORKSPACE_DEFAULT_HAVE_NORMAL_NOT_DEL);
                }
            }
            workspaceMapper.deleteById(id);
            roleWorkspaceService.deleteBatch(id);
        }
    }

    @Override
    public void deleteCurrentWs(String userId){
        RoleWorkspaceMapping roleWorkspaceMapping = roleWorkspaceService.getByUserId(userId);
        if(ObjectUtil.isEmpty(roleWorkspaceMapping)){
            return ;
        }
        workspaceMapper.deleteById(roleWorkspaceMapping.getWorkspaceId());
        roleWorkspaceService.deleteOne(roleWorkspaceMapping.getUserId());
    }

    @Override
    public void addUserWs(Long roleId,List<UserRoleBasicDTO>  userRoles) {
        if(ObjectUtil.isEmpty(userRoles)){
            return ;
        }
        Workspace defaultWs = workspaceMapper.selectDefaultWsByRoleId(roleId);
        for(UserRoleBasicDTO userRoleBasicDTO: userRoles) {
            if (ObjectUtil.isEmpty(defaultWs)) {
                return;
            }
            userRoleBasicDTO.setRoleId(roleId);
        }
        this.batchAddCurrentWsAndMapping(userRoles,defaultWs,SessionUtil.getUserSession());
    }


    @Override
    public void setDefaultNormal(Long id){
       Workspace workspace = workspaceMapper.selectById(id);
       if(ObjectUtil.isEmpty(workspace)){
           return ;
       }
        String userId = SessionUtil.getUserId();
        workspaceMapper.resetDefaultNormal(userId + CharPool.COMMA);
       String defaultNormal = workspace.getAdminDefaultNormal();
       if(ObjectUtil.isNotEmpty(defaultNormal)) {
           defaultNormal += userId + CharPool.COMMA;
       }else{
           defaultNormal = userId + CharPool.COMMA;
       }
        workspace.setAdminDefaultNormal(defaultNormal);
       workspaceMapper.updateById(workspace);
    }

    @Override
    public WorkspaceDTO get(String id) {
        Workspace defaultWorkspace = workspaceMapper.selectById(id);
        WorkspaceDTO workspaceDTO = new WorkspaceDTO();
        if(ObjectUtil.isNotEmpty(defaultWorkspace)){
            workspaceDTO = this.getWorkspaceDTO(defaultWorkspace);
            RoleWorkspaceMapping mapping = this.getMappingByWorkspaceId(workspaceDTO.getId());
            if(ObjectUtil.isNotEmpty(mapping)){
                workspaceDTO.setRoleId(mapping.getRoleId());
                workspaceDTO.setRoleName(this.getBindRoleName(mapping.getRoleId()));
                workspaceDTO.setUserId(mapping.getUserId());
                workspaceDTO.setUserName(this.getBindUserName(mapping.getUserId()));
            }
        }
        return workspaceDTO;
    }

    private RoleWorkspaceMapping getMappingByWorkspaceId(Long id){
        List<RoleWorkspaceMapping> mappings =  roleWorkspaceService.getAllByWorkspaceId(id);
        if(ObjectUtil.isNotEmpty(mappings)) {
           return mappings.get(0);
        }
        return null;
    }

    private void deleteAllByRoleIds(List<Long> roleIds){
        if(ObjectUtil.isNotEmpty(roleIds)) {
            roleWorkspaceService.deleteBatchByRoleIds(roleIds);
        }
    }

    private void batchAddDefaultMappings(List<Long> addRoles, Long id){
        List<RoleWorkspaceMapping> addMappings = new ArrayList<>();
        if(ObjectUtil.isNotEmpty(addRoles)){
            for(Long roleId:addRoles) {
                RoleWorkspaceMapping mapping = new RoleWorkspaceMapping();
                mapping.setWorkspaceId(id);
                mapping.setRoleId(roleId);
                addMappings.add(mapping);
            }
            roleWorkspaceService.saveBatch(addMappings);
        }
    }
    private void batchCopyMappings(List<Long> addRoles, Long id){
        List<RoleWorkspaceMapping> addMappings = new ArrayList<>();
        if(ObjectUtil.isNotEmpty(addRoles)){
            for(Long roleId:addRoles) {
                RoleWorkspaceMapping mapping = new RoleWorkspaceMapping();
                mapping.setWorkspaceId(id);
                mapping.setRoleId(roleId);
                addMappings.add(mapping);
            }
            roleWorkspaceService.saveBatch(addMappings);
        }
    }

    private void batchRemoveMappings(List<Long> removeRoles, Long id){
        if(ObjectUtil.isNotEmpty(removeRoles)){
            roleWorkspaceService.deleteBatch(id,removeRoles);
        }
    }

    private Workspace selectByNameAndUserId(String name, String userId, String tenantId){
        return workspaceMapper.selectOne(Wrappers.<Workspace>lambdaQuery()
                .eq(Workspace::getName,name)
                .eq(Workspace::getCreatedId,userId)
                .eq(Workspace::getTenantId,tenantId));
    }

    private Workspace setWorkspace(WorkspaceDTO workspaceDTO, Workspace workspace, String tenantId, String userId){
        if (ObjectUtil.isEmpty(workspace)) {
            workspace = new Workspace();
            workspace.setTenantId(tenantId);
            workspace.setCreatedId(userId);
            workspace.setCreatedDate(DateUtil.date());
        }
        workspace.setName(workspaceDTO.getName());
        Integer frontSize = null;
        if(ObjectUtil.isNotEmpty(workspaceDTO.getFrontSize())){
            frontSize = FrontSizeTypeEnum.getKeyByValue(workspaceDTO.getFrontSize());
        }
        workspace.setFrontSize(frontSize);
        Integer theme = null;
        if(ObjectUtil.isNotEmpty(workspaceDTO.getTheme())) {
            theme = ThemeTypeEnum.getKeyByValue(workspaceDTO.getTheme());
        }
        workspace.setTheme(theme);
        Integer setType = null;
        if(ObjectUtil.isNotEmpty(workspaceDTO.getSetType())) {
            setType = SetTypeEnum.getKeyByValue(workspaceDTO.getSetType());
            if(ObjectUtil.isNotEmpty(workspace.getSetType()) && workspace.getSetType().equals(SetTypeEnum.DEFAULT.getKey()) && setType.equals(SetTypeEnum.NORMAL.getKey())){
                throw new ServiceException(AdminMsgEnum.WORKSPACE_NORMAL_NOT_DEFAULT);
            }
        }
        workspace.setSetType(setType);
        workspace.setTrackNum(workspaceDTO.getTrackNum());
        workspace.setRoiColor(workspaceDTO.getRoiColor());
        workspace.setMaskAreaColor(workspaceDTO.getMaskAreaColor());
        workspace.setBindingId(workspaceDTO.getBindingId());
        workspace.setFrontStyle(workspaceDTO.getFrontStyle());
        String eoSetting = null;
        if(ObjectUtil.isNotEmpty(workspaceDTO.getEoSetting())) {
            eoSetting = workspaceDTO.getEoSetting().toJSONString();
        }
        workspace.setEoSetting(eoSetting);
        String nfoaSetting = null;
        if(ObjectUtil.isNotEmpty(workspaceDTO.getNfoaSetting())) {
            nfoaSetting = workspaceDTO.getNfoaSetting().toJSONString();
        }
        workspace.setNfoaSetting(nfoaSetting);
        String dashboardSetting = null;
        if(ObjectUtil.isNotEmpty(workspaceDTO.getDashboardSetting())) {
            dashboardSetting = workspaceDTO.getDashboardSetting().toJSONString();
        }
        workspace.setDashboardSetting(dashboardSetting);
        workspace.setLastUpdatedId(userId);
        workspace.setLastUpdatedDate(DateUtil.date());
        return workspace;
    }

    private WorkspaceDTO getWorkspaceDTO(Workspace workspace) {
        if(ObjectUtil.isNotEmpty(workspace)) {
            WorkspaceDTO workspaceDTO = new WorkspaceDTO();
            workspaceDTO.setId(workspace.getId());
            workspaceDTO.setName(workspace.getName());
            String frontSize = null;
            if(ObjectUtil.isNotEmpty(workspace.getFrontSize())){
                frontSize = FrontSizeTypeEnum.getValueByKey(workspace.getFrontSize());
            }
            workspaceDTO.setFrontSize(frontSize);
            workspaceDTO.setFrontStyle(workspace.getFrontStyle());
            workspaceDTO.setBindingId(workspace.getBindingId());
            String setType = null;
            if(ObjectUtil.isNotEmpty(workspace.getSetType())){
                setType = SetTypeEnum.getValueByKey(workspace.getSetType());
            }
            workspaceDTO.setSetType(setType);
            String theme = null;
            if(ObjectUtil.isNotEmpty(workspace.getTheme())){
                theme = ThemeTypeEnum.getValueByKey(workspace.getTheme());
            }
            workspaceDTO.setTheme(theme);
            workspaceDTO.setTrackNum(workspace.getTrackNum());
            workspaceDTO.setRoiColor(workspace.getRoiColor());
            workspaceDTO.setMaskAreaColor(workspace.getMaskAreaColor());
            JSONObject eoSetting = new JSONObject();
            if(ObjectUtil.isNotEmpty(workspace.getEoSetting())){
                eoSetting = JSON.parseObject(workspace.getEoSetting());
            }
            workspaceDTO.setEoSetting(eoSetting);
            JSONObject nfoaSetting = new JSONObject();
            if(ObjectUtil.isNotEmpty(workspace.getNfoaSetting())){
                nfoaSetting = JSON.parseObject(workspace.getNfoaSetting());
            }
            workspaceDTO.setNfoaSetting(nfoaSetting);
            JSONObject dashboardSetting = new JSONObject();
            if(ObjectUtil.isNotEmpty(workspace.getDashboardSetting())){
                dashboardSetting = JSON.parseObject(workspace.getDashboardSetting());
            }
            workspaceDTO.setDashboardSetting(dashboardSetting);
            workspaceDTO.setLastUpdatedDate(workspace.getLastUpdatedDate());
            workspaceDTO.setCreatedDate(workspace.getCreatedDate());
            workspaceDTO.setDefaultNormal(workspace.getAdminDefaultNormal());
            return workspaceDTO;
        }
        return null;
    }

    /**
     * check repeat name in role
     * @param name     name
     * @param bindingId normal binding default id
     * @param workspaceId need ignore workspace id
     * @return
     */
    private Integer repeatNameCheck(String tenantId,String name, Long bindingId, Long workspaceId) {
        if (StringUtils.isBlank(name)) {
            throw new ServiceException(AdminMsgEnum.WORKSPACE_NOT_EXIST);
        }
        return workspaceMapper.selectCountByRoleId(name,tenantId,bindingId,workspaceId);
    }
}
