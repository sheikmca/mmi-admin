package sg.ncs.kp.admin.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class JvmInfo {
    /**
     * Total memory occupied by the current JVM (M)
     */
    private double total;

    /**
     * Maximum free memory for JVM (M)
     */
    private double max;

    /**
     * JVM Free Memory (M)
     */
    private double free;

    /**
     * JDK version
     */
    private String version;

    /**
     * JDK home path
     */
    private String home;
}
