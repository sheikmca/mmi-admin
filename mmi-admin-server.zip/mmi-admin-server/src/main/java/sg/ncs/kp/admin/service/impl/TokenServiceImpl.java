package sg.ncs.kp.admin.service.impl;

import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.stereotype.Service;
import sg.ncs.kp.admin.dto.ADUserDTO;
import sg.ncs.kp.admin.dto.CheckADUserResponseDTO;
import sg.ncs.kp.admin.pojo.DirectionEnum;
import sg.ncs.kp.admin.service.ADLoginService;
import sg.ncs.kp.admin.service.KpUserOnlineService;
import sg.ncs.kp.admin.service.KpUserService;
import sg.ncs.kp.admin.service.TokenService;
import sg.ncs.kp.admin.util.NotificationUtil;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.common.exception.pojo.ClientServiceException;
import sg.ncs.kp.notification.pojo.NotificationConstants;
import sg.ncs.kp.uaa.common.enums.StatusEnum;
import sg.ncs.kp.uaa.server.common.UaaServerMsgEnum;
import sg.ncs.kp.uaa.server.po.User;
import sg.ncs.kp.uaa.server.service.UserService;

import java.util.List;
import java.util.Objects;

/**
 * @ClassName: TokenServiceImpl
 * @Description: Token service implements
 * @author: P1345033
 * @date: 2024/6/20 16:20
 **/
@Service
@Slf4j
public class TokenServiceImpl implements TokenService {

    private static final String KEY_TELEPHONE_NUMBER = "telephoneNumber";
    private static final String KEY_MAIL = "mail";

    @Autowired
    private UserService userService;

    @Autowired
    private KpUserService kpUserService;

    @Autowired
    private ADLoginService adLoginService;

    @Autowired
    private NotificationUtil notificationUtil;

    @Autowired
    KpUserOnlineService kpUserOnlineService;

    @Override
    public Result<OAuth2AccessToken> adLogin(CheckADUserResponseDTO adUserData, String adName, String direction) throws Exception {
        JSONObject jsonObject = new JSONObject();

        // Get all return AD User list
        List<ADUserDTO> userList = adUserData.getUserList();
        User user = null;
        for (ADUserDTO adUser: userList) {

            // Individual AD User info
            log.info("Find out the AD user: {}", adUser.toString());

            String data = adUser.getUserName();
            String userName;
            if (data.contains(Constants.AT)) {
                // If the AD User id with "@" as same as email address
                userName = data.substring(0, data.indexOf(Constants.AT));
            } else {
                // Pure AD User
                userName = data;
            }
            log.info("The LogUtilsin AD user id is:{}",userName);

            // Add for MMI-505 by Zou Ke on 24 May 2019 - Start
            user = userService.getUser(userName);
            if (ObjectUtil.isEmpty(user)) {
                user = createAdUser(adUser,adName,direction);
            } else {
                // This is a existing AD User for UMMI
                user = updateAdUser(adUser, adName);
            }
            if (StatusEnum.ACTIVE.getStatus() != user.getStatus()) {
                throw new ClientServiceException(UaaServerMsgEnum.USER_STATUS_ERROR);
            }

        }
        notificationUtil.sendTopicMsgToWebSocketExchange(new JSONObject(), NotificationConstants.TOPIC_WORKSTATION_STATUS_UPDATE);
        Result<OAuth2AccessToken> result = adLoginService.getADLoginResult(user, DirectionEnum.getIndexByKey(direction));
        OAuth2AccessToken oAuth2AccessToken = result.getData();
        if(Objects.nonNull(oAuth2AccessToken)) {
            //Add user to online User Map
            kpUserOnlineService.userOnline(user.getId(), oAuth2AccessToken.getValue());
        }
        return result;

    }

    /**
     * Create the new AD User in UMMI
     *
     * @param
     *
     */
    private User createAdUser(ADUserDTO obj,String adName, String direction) throws Exception {

        // This is a new AD User
        log.info("It's a new AD user account");
        // Prepare the user's full name and UMMI User Id
        String name = obj.getUserName();
        String data = obj.getUserName();

        JSONArray baseInfo = obj.getUserInfo();

        // Prepare the Mobile & Email info for the user
        String mobile = "";
        String email = "";
        if (baseInfo != null) {
            for (int j = 0; j < baseInfo.size(); j++) {
                JSONObject tmpObj = baseInfo.getJSONObject(j);
                if (ObjectUtil.isNotEmpty(tmpObj.getString(KEY_TELEPHONE_NUMBER))) {
                    mobile = tmpObj.getString(KEY_TELEPHONE_NUMBER);
                }
                if (ObjectUtil.isNotEmpty(tmpObj.getString(KEY_MAIL))) {
                    email = tmpObj.getString(KEY_MAIL);
                }
            }
        }

        String userName = "";

        // Base on the AD return user account to prepare the UMMI userId
        if (data.contains(Constants.AT)) {
            userName = data.substring(0, data.indexOf(Constants.AT));
        } else {
            userName = data;
        }
        kpUserService.addLDAPUser(name, email, userName, adName, mobile, direction);
        return userService.getUser(userName);
    }

    /**
     * Update the existing AD User in UMMI
     */
    private User updateAdUser(ADUserDTO obj,String adName) throws Exception {

        // This is a existing AD User already in UMMI
        log.info("Existing AD user in our system");

        String data = obj.getUserName();

        JSONArray baseInfo = obj.getUserInfo();

        // Prepare the Mobile & Email info for the user
        String mobile = "";
        String email = "";

        if (baseInfo != null) {
            for (int j = 0; j < baseInfo.size(); j++) {
                JSONObject tmpObj = baseInfo.getJSONObject(j);
                if (ObjectUtil.isNotEmpty(tmpObj.getString(KEY_TELEPHONE_NUMBER))) {
                    mobile = tmpObj.getString(KEY_TELEPHONE_NUMBER);
                }
                if (ObjectUtil.isNotEmpty(tmpObj.getString(KEY_MAIL))) {
                    email = tmpObj.getString(KEY_MAIL);
                }
            }
        }

        String userName = "";

        if (data.contains(Constants.AT)) {
            userName = data.substring(0, data.indexOf(Constants.AT));
        } else {
            userName = data;
        }
        kpUserService.updateLDAPUser(data,email,userName,adName,mobile);
        return userService.getUser(userName);
    }
}
