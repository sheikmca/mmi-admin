package sg.ncs.kp.admin.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import sg.ncs.kp.admin.dto.AssignWorkspaceDTO;
import sg.ncs.kp.admin.dto.WorkspaceDTO;
import sg.ncs.kp.admin.service.RoleWorkspaceService;
import sg.ncs.kp.admin.service.WorkspaceService;
import sg.ncs.kp.common.core.response.PageResult;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.common.i18n.util.MessageUtils;
import sg.ncs.kp.uaa.client.annotation.LogAnnotation;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @className WorkspaceController
 * @version 1.0.0
 * @date 2023-07-25
 */
@RestController
@RequestMapping("/workspace")
public class WorkspaceController {

    @Resource
    private WorkspaceService workspaceService;

    @Resource
    private RoleWorkspaceService roleWorkspaceService;
    @Resource
    private MessageUtils messageUtils;

    @PostMapping("/save")
    @PreAuthorize("hasAuthority('addWorkspace')")
    @LogAnnotation(operateType = "Create Workspace")
    public Result save(@Valid @RequestBody WorkspaceDTO workspaceDTO){
        WorkspaceDTO result = workspaceService.saveOrUpdateWorkspace(workspaceDTO);
        return messageUtils.addSucceed(result);
    }

    @PostMapping("/copy/{id}")
    @PreAuthorize("hasAuthority('copyWorkspace')")
    @LogAnnotation(operateType = "Copy Workspace")
    public Result copy(@PathVariable Long id){
        WorkspaceDTO result = workspaceService.copyWorkspace(id);
        return messageUtils.addSucceed(result);
    }

    @PostMapping("/reset/{id}")
    @PreAuthorize("hasAuthority('updateWorkspace')")
    @LogAnnotation(operateType = "Reset Workspace")
    public Result reset(@PathVariable Long id){
        WorkspaceDTO result = workspaceService.resetWorkspace(id);
        return messageUtils.updateSucceed(result);
    }

    @PutMapping("/update")
    @PreAuthorize("hasAuthority('updateWorkspace')")
    @LogAnnotation(operateType = "Update Workspace")
    public Result update(@Valid @RequestBody WorkspaceDTO workspaceDTO){
        WorkspaceDTO result = workspaceService.updateWorkspace(workspaceDTO);
        return messageUtils.updateSucceed(result);
    }
    @PostMapping("/assign")
    @PreAuthorize("hasAuthority('assignWorkspace')")
    @LogAnnotation(operateType = "Assign Workspace To Role")
    public Result assign(@Valid @RequestBody AssignWorkspaceDTO assignWorkspaceDTO){
        workspaceService.assignWorkspace(assignWorkspaceDTO.getId(), assignWorkspaceDTO.getRoleIds());
        return messageUtils.assignSucceed();
    }

    @DeleteMapping("/delete/{id}")
    @PreAuthorize("hasAuthority('deleteWorkspace')")
    @LogAnnotation(operateType = "Delete Workspace")
    public Result delete(@PathVariable Long id){
        workspaceService.deleteWorkspace(id);
        return messageUtils.deleteSucceed();
    }

    @GetMapping("/list")
    @PreAuthorize("hasAuthority('searchWorkspace')")
    public Result<PageResult<WorkspaceDTO>> list(@RequestParam(value = "name",required = false) String name,
                                                 @RequestParam(value = "userId",required = false) String userId,
                                                 @RequestParam(value = "setType",required = false) String setType,
                                                 @RequestParam(value = "pageNo") Integer pageNo,
                                                 @RequestParam(value = "pageSize") Integer pageSize){
        return messageUtils.succeed(workspaceService.list(name, userId, setType, pageNo, pageSize));
    }

    @GetMapping("/view")
    //@PreAuthorize("hasAuthority('viewWorkspace')")
    public Result<WorkspaceDTO> view(){
        return messageUtils.succeed(workspaceService.view());
    }

    @PutMapping("/set-default-normal/{id}")
    @PreAuthorize("hasAuthority('setDefaultNormal')")
    @LogAnnotation(operateType = "Set Default Workspace")
    public Result<List<WorkspaceDTO>> setDefaultNormal(@PathVariable Long id){
        workspaceService.setDefaultNormal(id);
        return messageUtils.succeed("");
    }

    @GetMapping("/get-default-info/{normalId}")
    @PreAuthorize("hasAuthority('workspace')")
    public Result<WorkspaceDTO> getDefaultInfoByNormalId(@PathVariable Long normalId){
        return messageUtils.succeed(workspaceService.getDefaultInfoByNormalId(normalId));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('workspace')")
    public Result<WorkspaceDTO> get(@PathVariable("id") String id){
        WorkspaceDTO workspaceDTO = workspaceService.get(id);
        return messageUtils.succeed(workspaceDTO);
    }

    @GetMapping("/exist-workspace/{roleId}")
    @PreAuthorize("hasAuthority('workspace')")
    public Result<Boolean> existWorkspaceByRoleId(@PathVariable("roleId") Long roleId){
        return messageUtils.succeed(roleWorkspaceService.existWorkspaceByRoleId(roleId));
    }
}
