# mmi-admin

## Requirement 
* openjdk:11


## Introduction 
* Provide input and output object defination of mmi-admin Restful Api.