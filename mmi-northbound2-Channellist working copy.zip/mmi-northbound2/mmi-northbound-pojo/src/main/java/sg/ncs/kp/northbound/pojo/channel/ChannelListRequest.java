package sg.ncs.kp.northbound.pojo.channel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChannelListRequest {
    private String tenantId;
    private String name;

}

