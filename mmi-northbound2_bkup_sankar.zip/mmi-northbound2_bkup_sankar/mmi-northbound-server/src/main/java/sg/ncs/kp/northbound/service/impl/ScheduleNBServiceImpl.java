package sg.ncs.kp.northbound.service.impl;

import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.northbound.pojo.common.VmsUpstreamException;
import sg.ncs.kp.northbound.service.ScheduleNBService;
import sg.ncs.kp.vms.feign.ChannelFeign;
import sg.ncs.kp.vms.pojo.schedule.ScheduleDetailVO;

@Slf4j
@Service
@RequiredArgsConstructor
public class ScheduleNBServiceImpl implements ScheduleNBService {

    private final ChannelFeign feign;

    @Override
    public Result<ScheduleDetailVO> getScheduleById(String id) {

        // -------------------------
        // BASIC VALIDATION
        // -------------------------
        if (!StringUtils.hasText(id)) {   // null OR empty OR whitespace
            log.warn("NB → getScheduleById called with invalid ID: '{}'", id);
            throw new VmsUpstreamException(
                    400,
                    "invalid-schedule-id",
                    "'scheduleId' is invalid"
            );
        }

        log.info("NB → Calling VMS getScheduleById for ID={}", id);

        Result<ScheduleDetailVO> vmsResp;

        try {
            // -------------------------
            // FEIGN CALL
            // -------------------------
            vmsResp = feign.getScheduleById(id);

        } catch (FeignException.Unauthorized ex) {
            throw new VmsUpstreamException(401, "unauthorized", "Unauthorized access");

        } catch (FeignException.Forbidden ex) {
            throw new VmsUpstreamException(403, "forbidden", "Access forbidden");

        } catch (FeignException.NotFound ex) {
            throw new VmsUpstreamException(
                    404,
                    "schedule-not-found",
                    "Can not find schedule"
            );

        } catch (FeignException.BadRequest ex) {
            throw new VmsUpstreamException(
                    400,
                    "invalid-schedule-id",
                    "'scheduleId' is invalid"
            );
        }
        // -------------------------
        // DEFENSIVE NULL CHECK
        // -------------------------

        if ( vmsResp == null || !vmsResp.getStatus() || vmsResp.getData() == null ) {
            log.warn("NB → Schedule not found or invalid response for ID={}", id);
            throw new VmsUpstreamException(
                    404,
                    "schedule-not-found",
                    "Can not find schedule"
            );
        }

        // -------------------------
        // UPSTREAM BUSINESS FAILURE
        // -------------------------
        if (Boolean.FALSE.equals(vmsResp.getStatus())) {

            String code = vmsResp.getCode();
            String msg  = vmsResp.getMsg();

            log.warn("NB → VMS failure. code={}, msg={}", code, msg);

            switch (code) {

                case "invalid-schedule-id":
                    throw new VmsUpstreamException(400, code, msg);

                case "schedule-not-found":
                    throw new VmsUpstreamException(404, code, msg);

                case "unauthorized":
                    throw new VmsUpstreamException(401, code, msg);

                case "forbidden":
                    throw new VmsUpstreamException(403, code, msg);

                default:
                    // 🔒 No 502 — spec allows only 400/404 here
                    throw new VmsUpstreamException(
                            400,
                            code != null ? code : "invalid-schedule-id",
                            msg != null ? msg : "Invalid schedule request"
                    );
            }
        }

        // -------------------------
        // SUCCESS
        // -------------------------
        if (vmsResp.getData() == null) {
            throw new VmsUpstreamException(
                    404,
                    "schedule-not-found",
                    "Can not find schedule"
            );
        }
        return vmsResp;
    }
}
