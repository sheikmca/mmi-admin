package sg.ncs.kp.admin.service;

import sg.ncs.kp.admin.po.Control2FA;

import java.util.List;

/**
 * @className Control2FAService
 * @version 1.0.0
 * @date 2023-07-11
 */

public interface Control2FAService {

    Boolean getStatusByRoleId(Long roleId);

    void addOrUpdateControl2FA(Long roleId, Boolean controlStatus);

    void deleteControl2FA(Long roleId);

    List<Control2FA> getControl2fas(String userId, Integer roleStatus);

    /**
     * @description 2fa check
     * @param userId, code
     * @return void
     * @version 1.0.0
     * @date 2022-08-19
     */
   void check2FA(String userId, String code);
    /**
     * @description init failed number
     * @param userId
     * @return void
     * @version 1.0.0
     * @date 2022-08-26
     */
    void initFailedNum(String userId);
}
