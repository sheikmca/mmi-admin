package sg.ncs.kp.admin.inner.controller;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sg.ncs.kp.admin.pojo.RoleUserDTO;
import sg.ncs.kp.admin.service.KpUserService;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.common.i18n.util.MessageUtils;
import sg.ncs.kp.uaa.common.enums.StatusEnum;
import sg.ncs.kp.uaa.common.enums.UserLevelEnum;
import sg.ncs.kp.uaa.server.mapper.UserMapper;
import sg.ncs.kp.uaa.server.po.Role;
import sg.ncs.kp.uaa.server.po.User;
import sg.ncs.kp.uaa.server.po.UserRoleMapping;
import sg.ncs.kp.uaa.server.service.RoleService;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @auther 
 * @date 2022/8/19
 * @description
 */
@RestController
@RequestMapping("/inner/role")
public class InnerRoleController {

    @Autowired
    private RoleService roleService;

    @GetMapping("/all-role-id")
    public Set<Long> getAllRoleIds(){
        List<Role> roles = roleService.list(Wrappers.<Role>lambdaQuery()
                .in(Role::getStatus, StatusEnum.ACTIVE.getStatus()));
        return roles.stream().map(Role::getId).collect(Collectors.toSet());
    }

    @GetMapping("/is-exist/{queryCriteria}/{roleId}")
    public JSONObject isExistByQueryCriteria(@PathVariable("queryCriteria") String queryCriteria, @PathVariable("roleId") String roleId){
        return roleService.isExistByQueryCriteria(queryCriteria,Long.valueOf(roleId));
    }
}
