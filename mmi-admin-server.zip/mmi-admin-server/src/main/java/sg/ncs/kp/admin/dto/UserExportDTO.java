package sg.ncs.kp.admin.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;
import sg.ncs.kp.common.uti.poi.ExcelVOAttribute;

/**
 * @auther 
 * @date 2022/8/25
 * @description
 */@Data
public class UserExportDTO {

    @ExcelProperty(value = "User ID",index = 0)
    private Integer userId;

    @ExcelProperty(value = "User Name",index = 1)
    private String userName;

    @ExcelProperty(value = "Role",index = 2)
    private String roleName;

    @ExcelProperty(value = "Api Key",index = 3)
    private String apikey;

    @ExcelProperty(value = "Validity Period",index = 4)
    private String validityPeriod;

    @ExcelProperty(value = "Last Login",index = 5)
    private String lastLogin;
    @ExcelProperty(value = "Status",index = 6)
    private String status;
}
