package sg.ncs.kp.admin.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sg.ncs.kp.admin.enums.AdminMsgEnum;
import sg.ncs.kp.admin.pojo.DirectionEnum;
import sg.ncs.kp.admin.mapper.AdServerMapper;
import sg.ncs.kp.admin.service.KpUserGroupService;
import sg.ncs.kp.common.exception.pojo.ServiceException;
import sg.ncs.kp.uaa.client.util.SessionUtil;
import sg.ncs.kp.uaa.common.dto.UserDTO;
import sg.ncs.kp.uaa.common.dto.UserGroupAssignUserDTO;
import sg.ncs.kp.uaa.server.mapper.LoginLogMapper;
import sg.ncs.kp.uaa.server.mapper.UserGroupMapper;
import sg.ncs.kp.uaa.server.mapper.UserRelUserGroupMappingMapper;
import sg.ncs.kp.uaa.server.po.LoginLog;
import sg.ncs.kp.uaa.server.po.UserGroup;
import sg.ncs.kp.uaa.server.po.UserRelUserGroupMapping;
import sg.ncs.kp.uaa.server.service.UserGroupService;
import sg.ncs.kp.uaa.server.service.UserService;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @className KpUserGroupServiceImpl
 * @version 1.0.0
 * @date 2023-08-21
 */
@Slf4j
@Service
public class KpUserGroupServiceImpl implements KpUserGroupService {
    @Autowired
    private AdServerMapper adServerMapper;
    @Autowired
    private UserGroupService userGroupService;
    @Autowired
    private LoginLogMapper loginLogMapper;
    @Autowired
    private UserService userService;
    @Autowired
    private UserRelUserGroupMappingMapper userRelUserGroupMappingMapper;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    private static final String FULL_PATH_SPLIT_CHARACTER = "\\|";
    private static final String FULL_PATH_SPLIT = "|";


    @Autowired
    UserGroupMapper userGroupMapper;
    @Override
    public void judgeDirection(String direction, String userId){
        UserGroup userGroup = null;
        if(ObjectUtil.isNotEmpty(userId)) {
            userGroup = userGroupService.getByUserId(userId);
        }
        Integer index = DirectionEnum.getIndexByKey(direction);
        String value = DirectionEnum.getValueByKey(direction);
        if(ObjectUtil.isEmpty(index) || ObjectUtil.isEmpty(value)){
            throw new ServiceException(AdminMsgEnum.USER_GROUP_INVALID);
        }
        if(ObjectUtil.isNotEmpty(userGroup)) {
            String fullPath = userGroup.getFullPath();
            if (!fullPath.contains(index + "")) {
                throw new ServiceException(AdminMsgEnum.USER_GROUP_INVALID);
            }
        }
    }

    @Override
    public IPage<UserDTO> getUserListByGroupId(UserGroupAssignUserDTO userGroupAssignUserDTO){
        authJudgment(userGroupAssignUserDTO.getId(),SessionUtil.getUserId());
        if(!userGroupAssignUserDTO.isDisplayOwn()) {
            userGroupAssignUserDTO.setCurrentUserId(SessionUtil.getUserId());
        }
        IPage<UserDTO> page = userGroupService.assignedUserList(userGroupAssignUserDTO);
        List<UserDTO> records = page.getRecords();
        if (CollectionUtil.isNotEmpty(records)) {
            Set<String> userIds = new HashSet<>();
            userIds.addAll(records.stream().map(UserDTO::getCreatedId).collect(Collectors.toList()));
            userIds.addAll(records.stream().map(UserDTO::getLastUpdatedId).collect(Collectors.toList()));
            Map<String, String> userNameMap = new HashMap<>();
            userNameMap = userService.getUserNameMap(new ArrayList<>(userIds));
            for (UserDTO record : records) {
                record.setCreatedBy(userNameMap.get(record.getCreatedId()));
                record.setLastUpdateBy(userNameMap.get(record.getLastUpdatedId()));
                if(ObjectUtil.isNotEmpty(record.getLastLoginTime())) {
                    record.setLastLoginTimeLong(record.getLastLoginTime().getTime());
                }
            }
        }
        return page;
    }

    private void authJudgment(Long groupId, String userId){
        UserGroup userGroup = userGroupService.getByUserId(userId);
        if(ObjectUtil.isNotEmpty(userGroup)){
            List<String> userGroupIdStr = Arrays.asList(userGroup.getFullPath().split(FULL_PATH_SPLIT_CHARACTER));
            List<Long> userGroupIds = new ArrayList<>();
            userGroupIds = userGroupIdStr.stream()
                    .map(Long::parseLong)
                    .collect(Collectors.toList());
            if(userGroupIds.contains(groupId) && !userGroupIds.get(userGroupIds.size()-1).equals(groupId)){
                throw new ServiceException(AdminMsgEnum.USER_GROUP_AUTH_ERROR);
            }
        }
    }

    @Override
    public Set<String> getRootUserGroupAllUserId(Long userGroupId){
        UserGroup userGroup = userGroupService.getById(userGroupId);
        if(ObjectUtil.isNotEmpty(userGroup)){
            String fullPath = userGroup.getFullPath();
            String[] groupIds = fullPath.split(FULL_PATH_SPLIT);
            if(ObjectUtil.isNotEmpty(groupIds) && groupIds.length > 3){
                fullPath = groupIds[0]+FULL_PATH_SPLIT+groupIds[1]+FULL_PATH_SPLIT+groupIds[2]+FULL_PATH_SPLIT;
            }
            List<UserRelUserGroupMapping> mappings = userRelUserGroupMappingMapper.selectList(Wrappers.<UserRelUserGroupMapping>lambdaQuery().like(UserRelUserGroupMapping::getFullPath, fullPath));
            if(ObjectUtil.isNotEmpty(mappings)){
                Set<String> userIds = mappings.stream().map(UserRelUserGroupMapping::getUserId).collect(Collectors.toSet());
                return userIds;
            }
        }
        return null;
    }


    @Override
    public JSONObject isExistByQueryCriteria(String queryCriteria, String userId){
        UserGroup userCurrentGroup = userGroupMapper.getByUserId(userId);
        List<Long> userGroupIds = new ArrayList<>();
        if(ObjectUtil.isNotEmpty(userCurrentGroup)){
            String fullPath = userCurrentGroup.getFullPath();
            List<UserGroup> subUserGroupList = userGroupMapper.selectList(Wrappers.<UserGroup>lambdaQuery().like(UserGroup::getFullPath,fullPath));
            userGroupIds = subUserGroupList.stream().map(UserGroup::getId).collect(Collectors.toList());
            List<String> userGroupIdStr = Arrays.asList(fullPath.split(FULL_PATH_SPLIT_CHARACTER));
            userGroupIds.addAll(userGroupIdStr.stream()
                    .map(Long::parseLong)
                    .collect(Collectors.toList()));
        }

        List<UserGroup> userGroupList = userGroupMapper.selectList(Wrappers.<UserGroup>lambdaQuery()
                .like(StringUtils.isNotBlank(queryCriteria), UserGroup::getName, queryCriteria)
                .in(ObjectUtil.isNotEmpty(userGroupIds), UserGroup::getId, userGroupIds));
        JSONObject result = new JSONObject();
        if(ObjectUtil.isNotEmpty(userGroupList) && !userGroupList.isEmpty()){
            result.put("name",queryCriteria);
        }
        return result;
    }
}
