package sg.ncs.kp.admin.po;

import java.io.Serializable;
import java.util.Date;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * <p>
 * 
 * </p>
 *
 * @since 2022-09-08
 */
@Getter
@Setter
@ToString
@TableName("kp_operate_log")
public class OperateLog implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.ASSIGN_ID)
    private Long id;
    private String userId;

    @TableField("user_id_num")
    private Integer userIdNum;
    private String tenantId;
    private String userName;
    private String module;
    private String requestData;
    private String responseData;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date logTime;
    private String operateType;
    private String ip;
    private String phone;
    private String email;
    private String userGroupName;
}
