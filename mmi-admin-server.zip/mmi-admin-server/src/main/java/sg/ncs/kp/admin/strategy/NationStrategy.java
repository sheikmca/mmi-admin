package sg.ncs.kp.admin.strategy;

/**
 * @auther 
 * @date 2022/8/20
 * @description
 */
public interface NationStrategy {

    boolean verifyPhone(String phone);
}
