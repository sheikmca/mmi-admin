package sg.ncs.kp.admin.dto;

import lombok.Getter;
import lombok.Setter;
import sg.ncs.kp.uaa.common.dto.WorkStationDTO;

import java.util.List;

@Getter
@Setter
public class WorkStationUserDTO extends WorkStationDTO {
    private List<String> userNames;
}
