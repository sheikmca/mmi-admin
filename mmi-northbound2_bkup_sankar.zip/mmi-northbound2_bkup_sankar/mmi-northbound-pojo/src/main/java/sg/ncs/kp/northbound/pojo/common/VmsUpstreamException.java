package sg.ncs.kp.northbound.pojo.common;

public class VmsUpstreamException extends RuntimeException {

    private final int httpStatus;
    private final String errorCode;
    private final Object[] params;

    // -------------------------
    // 2-PARAM CONSTRUCTOR (REQUESTED)
    // -------------------------
    public VmsUpstreamException(int httpStatus, String errorCode) {
        super(errorCode);
        this.httpStatus = httpStatus;
        this.errorCode = errorCode;
        this.params = new Object[0];
    }

    // -------------------------
    // 3-PARAM CONSTRUCTOR
    // -------------------------
    public VmsUpstreamException(int httpStatus, String errorCode, String message) {
        super(message);
        this.httpStatus = httpStatus;
        this.errorCode = errorCode;
        this.params = new Object[0];
    }

    // -------------------------
    // VARARGS CONSTRUCTOR
    // -------------------------
    public VmsUpstreamException(int httpStatus, String errorCode, String message, Object... params) {
        super(message);
        this.httpStatus = httpStatus;
        this.errorCode = errorCode;
        this.params = params == null ? new Object[0] : params;
    }

    // -------------------------
    // FACTORY METHODS (OPTIONAL BUT RECOMMENDED)
    // -------------------------
    public static VmsUpstreamException badRequest(String errorCode, String message, Object... params) {
        return new VmsUpstreamException(400, errorCode, message, params);
    }

    public static VmsUpstreamException unauthorized(String errorCode, String message) {
        return new VmsUpstreamException(401, errorCode, message);
    }

    public static VmsUpstreamException forbidden(String errorCode, String message) {
        return new VmsUpstreamException(403, errorCode, message);
    }

    public static VmsUpstreamException notFound(String errorCode, String message) {
        return new VmsUpstreamException(404, errorCode, message);
    }

    public static VmsUpstreamException upstreamError(String errorCode, String message) {
        return new VmsUpstreamException(502, errorCode, message);
    }

    // -------------------------
    // GETTERS
    // -------------------------
    public int getHttpStatus() {
        return httpStatus;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public Object[] getParams() {
        return params;
    }

    @Override
    public String toString() {
        return "VmsUpstreamException{" +
                "httpStatus=" + httpStatus +
                ", errorCode='" + errorCode + '\'' +
                ", message='" + getMessage() + '\'' +
                '}';
    }
}
