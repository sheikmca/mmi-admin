package sg.ncs.kp.northbound.controller;

import sg.ncs.kp.northbound.pojo.common.Result;
import sg.ncs.kp.northbound.pojo.channel.ChannelListRequest;
import sg.ncs.kp.northbound.service.ChannelService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/channel")
@RequiredArgsConstructor
@Slf4j
public class ChannelController {

    private final ChannelService service;

    @PostMapping("/list")
    public Object list(@RequestBody ChannelListRequest req){
        log.info("channel/list request => {}", req);
        Object resp = service.getChannelList(req);
        log.info("channel/list response => {}", resp);
        return Result.ok(resp);
    }
}
