package sg.ncs.kp.admin.controller;

import cn.hutool.core.bean.BeanUtil;

import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import sg.ncs.kp.admin.dto.*;
import sg.ncs.kp.admin.enums.AdminMsgEnum;
import sg.ncs.kp.admin.po.UploadRecord;
import sg.ncs.kp.admin.pojo.AdminConstants;
import sg.ncs.kp.admin.pojo.WSMsgTypEnum;
import sg.ncs.kp.admin.service.AsyncService;
import sg.ncs.kp.admin.service.KpUserService;
import sg.ncs.kp.admin.util.NotificationUtil;
import sg.ncs.kp.common.core.response.PageResult;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.common.exception.pojo.ClientServiceException;
import sg.ncs.kp.common.i18n.util.MessageUtils;
import sg.ncs.kp.common.uti.poi.ExcelDropDownList;
import sg.ncs.kp.notification.pojo.NotificationConstants;
import sg.ncs.kp.uaa.client.annotation.LogAnnotation;
import sg.ncs.kp.uaa.client.util.SessionUtil;
import sg.ncs.kp.uaa.common.dto.PasswordPolicyDTO;
import sg.ncs.kp.uaa.common.dto.RoleUserBasicDTO;
import sg.ncs.kp.uaa.common.dto.UserDTO;
import sg.ncs.kp.uaa.common.dto.UserDetailDTO;
import sg.ncs.kp.uaa.common.dto.UserModifyDTO;
import sg.ncs.kp.uaa.common.dto.UserPasswordDTO;
import sg.ncs.kp.uaa.common.dto.UserQueryDTO;
import sg.ncs.kp.uaa.common.dto.UserUploadRecordQueryDTO;
import sg.ncs.kp.uaa.common.vo.UserGroupTreeVO;
import sg.ncs.kp.uaa.server.mapper.LoginLogMapper;
import sg.ncs.kp.uaa.server.mapper.RoleMapper;
import sg.ncs.kp.uaa.server.po.LoginLog;
import sg.ncs.kp.uaa.server.po.PasswordPolicy;
import sg.ncs.kp.uaa.server.po.Role;
import sg.ncs.kp.uaa.server.service.UserRelUserGroupMappingMapperService;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @auther 
 * @date 2022/8/19
 * @description
 */
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private KpUserService kpUserService;

    @Autowired
    private MessageUtils messageUtils;

    @Autowired
    private AsyncService asyncService;

    @Autowired
    private RoleMapper roleMapper;

    @Autowired
    NotificationUtil notificationUtil;

    @Autowired
    LoginLogMapper loginLogMapper;

    @Autowired
    private UserRelUserGroupMappingMapperService userRelUserGroupMappingMapperService;

    @Autowired
    private RedisTemplate<String,String> sessionRedisTemplate;

    private static final String FILE_NAME = "user_batch_add.xlsx";
    @Value("${role.maxUser}")
    private Long maxUser;

    @PostMapping("/list")
    @PreAuthorize("hasAuthority('userList')")
    public PageResult<UserDTO> list(@RequestBody UserQueryDTO userQueryDTO) {
        IPage<UserDTO> page = kpUserService.selectList(userQueryDTO);
        return messageUtils.pageResult((int) page.getCurrent(), (int) page.getSize(),
                page.getTotal(), BeanUtil.copyToList(page.getRecords(), UserDTO.class));
    }

    @PostMapping("/add")
    @PreAuthorize("hasAuthority('userManagementAddUser')")
    @LogAnnotation(operateType = "Add User")
    public Result add(@Valid @RequestBody UserModifyDTO userModifyDTO) {
        kpUserService.add(userModifyDTO);
        return messageUtils.addSucceed(null);
    }

    @PutMapping("/update")
    @PreAuthorize("hasAuthority('userManagementEditUser')")
    @LogAnnotation(operateType = "Update User")
    public Result update(@Valid @RequestBody UserModifyDTO userModifyDTO) {
        boolean roleChange = false;
        if (StringUtils.isNotBlank(userModifyDTO.getId())) {
            List<RoleUserBasicDTO> roleBasic = roleMapper.getRolesByUserIds(Collections.singletonList(userModifyDTO.getId()));
            Set<Long> oldRoleIds = new HashSet<>();
            roleBasic.forEach(role -> oldRoleIds.add(role.getId()));
            roleChange = checkRolesChange(oldRoleIds, userModifyDTO.getRoleIds());
        }
        if(roleChange && null != userModifyDTO.getRoleIds() && !userModifyDTO.getRoleIds().isEmpty()){
            Set<Long> roleIds = userModifyDTO.getRoleIds();
            ArrayList<Long> roleIdList = new ArrayList<>(roleIds);
            long count = roleMapper.getUserCount(roleIdList.get(0));
            if(count > maxUser){
                throw new ClientServiceException(AdminMsgEnum.ROLE_USER_LIMIT, String.valueOf(maxUser));
            }
        }
        kpUserService.update(userModifyDTO,roleChange);
        if (roleChange) {
            WSMessageDTO wsMessageDTO = new WSMessageDTO();
            wsMessageDTO.setType(WSMsgTypEnum.PERMISSION_UPDATE);
            wsMessageDTO.setMessage(messageUtils.getMessage(WSMsgTypEnum.PERMISSION_UPDATE.getCode()));
            notificationUtil.sendQueueMsgToWebSocketExchange(wsMessageDTO, NotificationConstants.ADMIN_QUEUE_USER_STATUS, Arrays.asList(userModifyDTO.getId()));
        }
        return messageUtils.updateSucceed();
    }

    @PostMapping("/assign-role")
    @PreAuthorize("hasAuthority('userManagementAssignRole')")
    public Result assignRole(@Valid @RequestBody AssignRoleDTO assignRole) {
        List<String> userIds = kpUserService.assignRole(assignRole);
        if(ObjectUtil.isNotEmpty(userIds)){
            WSMessageDTO wsMessageDTO = new WSMessageDTO();
            wsMessageDTO.setType(WSMsgTypEnum.PERMISSION_UPDATE);
            wsMessageDTO.setMessage(messageUtils.getMessage(WSMsgTypEnum.PERMISSION_UPDATE.getCode()));
            notificationUtil.sendQueueMsgToWebSocketExchange(wsMessageDTO, NotificationConstants.ADMIN_QUEUE_USER_STATUS,userIds);
        }
        return messageUtils.updateSucceed();
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('userManagementDeleteUser')")
    @LogAnnotation(operateType = "Delete User")
    public Result delete(@PathVariable("id") String id) {
        kpUserService.delete(id);
        return messageUtils.deleteSucceed(null);
    }

    @PostMapping("/delete")
    @PreAuthorize("hasAuthority('userManagementDeleteUser')")
    @LogAnnotation(operateType = "Batch Delete User")
    public Result delete(@RequestBody List<String> ids) {
        kpUserService.delete(ids);
        return messageUtils.deleteSucceed(null);
    }

    @PutMapping("/status/{id}/{status}")
    @PreAuthorize("hasAuthority('userManagementEditUser')")
    public Result updateStatus(@PathVariable("id") String id, @PathVariable("status") Integer status) {
        kpUserService.updateStatus(id, status);
        if (Objects.equals(0, status)) {
            asyncService.sendMessage(WSMsgTypEnum.ACCOUNT_DISABLE, id);
        }
        return messageUtils.updateSucceed();
    }

    @LogAnnotation(operateType = "Change Group")
    @PostMapping("/change-group")
    @PreAuthorize("hasAuthority('userManagementChangeGroup')")
    public Result changeGroup(@Valid @RequestBody ChangeGroupDTO changeGroupDTO) {
        kpUserService.changeGroup(changeGroupDTO);
        return messageUtils.updateSucceed();
    }

    @PutMapping("/password")
    public Result password(@Valid @RequestBody UserPasswordDTO userPasswordDTO) throws Exception {
        kpUserService.password(userPasswordDTO);
        return messageUtils.updateSucceed();
    }

    @PostMapping("/update-myself-password")
    public Result updateMyselfPassword(@Valid @RequestBody UserSelfPasswordUpdateDTO userPasswordDTO) throws Exception {
        kpUserService.updateMyselfPassword(userPasswordDTO);
        return messageUtils.updateSucceed();
    }

    @GetMapping("/password/policy")
    public Result<List<PasswordPolicy>> policy() {
        List<PasswordPolicy> passwordPolicies = kpUserService.policy();
        return messageUtils.succeed(passwordPolicies);
    }

    @PostMapping("/password/policy")
    @PreAuthorize("hasAuthority('savePasswordPolicy')")
    public Result policy(@Valid @RequestBody List<PasswordPolicyDTO> list) {
        kpUserService.policy(list);
        return messageUtils.updateSucceed();
    }

    @LogAnnotation(operateType = "Reset password")
    @PostMapping("/reset-password")
    @PreAuthorize("hasAuthority('userManagementResetPassword')")
    public Result resetPassword(@RequestBody ResetPasswordDTO resetPasswordDTO) throws Exception {
        kpUserService.resetPassword(resetPasswordDTO);
        return messageUtils.updateSucceed();
    }

    @GetMapping("/get-myself")
    public Result<UserDetailDTO> myself() {
        String userId = SessionUtil.getUserId();
        Set<Long> roleIds = SessionUtil.getRoles();
        UserDetailDTO userDetailDTO = kpUserService.get(userId,roleIds);
        userDetailDTO.setRoleId(roleIds);
        userDetailDTO.setFullPath(userRelUserGroupMappingMapperService.getFullPathByUserId(userId));
        LoginLog loginLog = loginLogMapper.getUserLastLoginByUserId(userId);
        if(ObjectUtil.isNotEmpty(loginLog)) {
            userDetailDTO.setIp(loginLog.getIp());
            userDetailDTO.setWorkstationName(loginLog.getWorkstationName());
        }
        return messageUtils.succeed(userDetailDTO);
    }

    @PostMapping("/upload-batch-add-user-file")
    @PreAuthorize("hasAuthority('userManagementBatchAddUser')")
    public Result<UserUploadPathDTO> upload(@RequestParam("file") MultipartFile file) {
        String path = kpUserService.upload(file);
        UserUploadPathDTO userUploadPathDTO = new UserUploadPathDTO();
        userUploadPathDTO.setPath(path);
        return messageUtils.succeed(userUploadPathDTO);
    }

    @PostMapping("/view-upload-batch-add-user-file")
    @PreAuthorize("hasAuthority('userManagementBatchAddUser')")
    public PageResult<UserUploadViewDTO> view(@Valid @RequestBody UserViewQueryDTO userViewQueryDTO) {
        Page<UserUploadViewDTO> page = kpUserService.view(userViewQueryDTO);
        return messageUtils.pageResult((int) page.getCurrent(), (int) page.getSize(),
                page.getTotal(), BeanUtil.copyToList(page.getRecords(), UserUploadViewDTO.class));
    }

    @PostMapping("/import-upload-batch-add-user")
    @PreAuthorize("hasAuthority('userManagementBatchAddUser')")
    public Result<UploadResultDTO> importFile(@Valid @RequestBody UserViewQueryDTO userViewQueryDTO) {
        UploadResultDTO uploadResultDTO = kpUserService.importFile(userViewQueryDTO.getPath());
        return messageUtils.succeed(uploadResultDTO);
    }

    @PostMapping("/batch-add")
    @PreAuthorize("hasAuthority('userManagementAddUser')")
    @LogAnnotation(operateType = "Batch Add User")
    public Result<BatchUserResultDTO> add(@Valid @RequestBody BatchUserDTO batchUserDTO) {
        BatchUserResultDTO result = kpUserService.batchAdd(batchUserDTO);
        if (result.getFail().equals(result.getTotal())) {
            return messageUtils.failedWith(result, false, AdminMsgEnum.BATCH_USER_FAILED.code(),
                    messageUtils.getMessage(AdminMsgEnum.BATCH_USER_FAILED.val()));
        }
        if (result.getFail() > 0 && result.getFail() < result.getTotal()) {
            return messageUtils.succeedWith(result, true, AdminMsgEnum.BATCH_USER_PARTIAL_FAILED.code(),
                    messageUtils.getMessage(AdminMsgEnum.BATCH_USER_PARTIAL_FAILED.val()), HttpStatus.SC_OK);
        }
        return messageUtils.addSucceed(result);
    }

    @GetMapping("/download-user-batch-add-template")
    @PreAuthorize("hasAuthority('userManagementBatchAddUser')")
    public void template(HttpServletResponse response) throws IOException {
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream("template/user_batch_add.xlsx");
        XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
        List<Role> roles = roleMapper.selectList(Wrappers.<Role>lambdaQuery()
                .eq(Role::getTenantId, SessionUtil.getTenantId())
                .eq(Role::getStatus, 1)
        );
        if(!CollectionUtils.isEmpty(roles)){
            List<String> roleNames = roles.stream().map(Role::getName).collect(Collectors.toList());
            ExcelDropDownList.setExcelDropDownList(workbook.getSheetAt(0), 1, 1, 8, 8, roleNames, workbook);
        }
        response.setHeader("Content-disposition", "attachment;filename=" + FILE_NAME + ";" + "filename*=utf-8''" + FILE_NAME);
        response.addHeader("Access-Control-Expose-Headers", "Content-Disposition");
        response.setContentType("application/vnd.ms-excel;charset=UTF-8");
        workbook.write(response.getOutputStream());
        workbook.close();
    }

    @PostMapping("/get-history")
    @PreAuthorize("hasAuthority('userManagementBatchAddUser')")
    public PageResult<UploadRecord> uploadRecord(@RequestBody UserUploadRecordQueryDTO userUploadRecordQueryDTO) {
        Page<UploadRecord> page = kpUserService.uploadRecord(userUploadRecordQueryDTO);
        return messageUtils.pageResult((int) page.getCurrent(), (int) page.getSize(),
                page.getTotal(), BeanUtil.copyToList(page.getRecords(), UploadRecord.class));
    }

    @PostMapping("/download-upload-user-file")
    @PreAuthorize("hasAuthority('userManagementBatchAddUser')")
    public void downloadUploadUserFile(HttpServletResponse response, @Valid @RequestBody UserViewQueryDTO userViewQueryDTO) {
        kpUserService.downloadUploadFile(response, userViewQueryDTO.getPath(), FILE_NAME);
    }

    @PostMapping("/export/{type}")
    @PreAuthorize("hasAuthority('userManagementExportUser')")
    public void export(@PathVariable String type, @RequestBody List<String> ids, HttpServletResponse response) throws IOException {
        kpUserService.export(ids, type,response);
    }

    @GetMapping("/menus")
    public Result<List<MenuDTO>> menus() {
        List<MenuDTO> permissionDTOS = kpUserService.menus();
        return messageUtils.succeed(permissionDTOS);
    }

    private boolean checkRolesChange(Set<Long> oldRoleIds, Set<Long> roleIds) {
        if (CollectionUtils.isEmpty(roleIds)) {
            return !CollectionUtils.isEmpty(oldRoleIds);
        } else {
            return !roleIds.containsAll(oldRoleIds) || !oldRoleIds.containsAll(roleIds);
        }
    }

    @GetMapping("/heartbeat/{userId}")
    public Result<Void> heartbeat(@PathVariable("userId") String userId){
        sessionRedisTemplate.opsForValue().set(AdminConstants.USER_HEARTBEAT_KEY + userId,
                String.valueOf(System.currentTimeMillis()), 1, TimeUnit.HOURS);
        return messageUtils.updateSucceed();
    }



    @Deprecated
    //@PutMapping("/notification")
    public Result notification(@RequestParam("id") String id, @RequestParam("status") Integer status) {
        kpUserService.notification(id, status);
        return messageUtils.updateSucceed();
    }

    @Deprecated
    //@PutMapping("/update-myself")
    public Result updateMyself(@Valid @RequestBody UserUpdateProfileDTO user) {
        kpUserService.updateMyself(user);
        return messageUtils.updateSucceed();
    }

    @Deprecated
    //@GetMapping("/group")
    public Result<UserGroupTreeVO> group(String groupName) {
        UserGroupTreeVO userGroupTreeVO = kpUserService.group(groupName);
        return messageUtils.succeed(userGroupTreeVO);
    }

    @Deprecated
    //@GetMapping("/all-ids-by-group/{groupId}")
    public Result<Set<String>> getAllIdsByGroupId(@PathVariable("groupId") Long groupId) {
        Set<Long> groupIds = new HashSet<>();
        groupIds.add(groupId);
        return messageUtils.succeed(kpUserService.getUserIdsByGroupId(groupIds));
    }
}
