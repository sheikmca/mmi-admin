package sg.ncs.kp.admin.service;

import org.springframework.security.oauth2.common.OAuth2AccessToken;
import sg.ncs.kp.admin.dto.CheckADUserResponseDTO;
import sg.ncs.kp.common.core.response.Result;

public interface TokenService {
    Result<OAuth2AccessToken> adLogin(CheckADUserResponseDTO adUserData, String adName, String direction) throws Exception;
}
