package sg.ncs.kp.northbound.service.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sg.ncs.kp.northbound.pojo.sensor.StreamLicenseUsage;
import sg.ncs.kp.northbound.service.SensorService;
import sg.ncs.kp.uaa.client.util.SessionUtil;
import sg.ncs.kp.vms.feign.VideoExchangeProfileFeign;

@Service
@Slf4j
public class SensorServiceImpl implements SensorService {
    @Autowired
    private VideoExchangeProfileFeign videoExchangeProfileFeign;
    @Override
    public StreamLicenseUsage getStreamLicenseUsage() {
        String userId = SessionUtil.getUserId();
        return videoExchangeProfileFeign.getStreamLicenseUsageByUserId(userId);
    }
}
