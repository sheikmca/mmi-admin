package sg.ncs.kp.northbound;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * MMI北向服务主启动类
 * 应用程序入口点
 */
@EnableScheduling
@EnableFeignClients(basePackages = {
        "sg.ncs.kp.vms.feign",
        "sg.ncs.kp.northbound.feign",
        "sg.ncs.kp.alarm.feign"
})
@SpringBootApplication
@ComponentScan({"sg.ncs.kp.northbound","sg.ncs.kp.uaa","sg.ncs.kp.common.oss",  "sg.ncs.kp.common.i18n" })
public class NorthboundApplication {

    /**4
     * 应用程序入口方法
     *
     * @param args 命令行参数
     */
    public static void main(String[] args) {
        SpringApplication.run(NorthboundApplication.class, args);
    }
}
