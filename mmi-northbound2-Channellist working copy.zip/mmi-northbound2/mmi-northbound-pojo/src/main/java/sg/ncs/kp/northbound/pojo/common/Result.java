package sg.ncs.kp.northbound.pojo.common;

import lombok.Data;

@Data
public class Result<T> {
    private boolean status;
    private String code;
    private String msg;
    private T data;

    public static <T> Result<T> ok(T data){
        Result<T> r=new Result<>();
        r.status=true; r.code="0"; r.msg="success"; r.data=data;
        return r;
    }
    public static <T> Result<T> fail(String code,String msg){
        Result<T> r=new Result<>();
        r.status=false; r.code=code; r.msg=msg;
        return r;
    }
}