package sg.ncs.kp.northbound.service;

import sg.ncs.kp.northbound.pojo.sensor.StreamLicenseUsage;

/**
 * Northbound service interface for retrieving stream license usage metrics.
 *
 * Responsibilities:
 * - Provide NB controllers with the current stream license usage.
 * - Fetch the latest license usage data from underlying systems
 *   (actual implementation in the serviceImpl).
 *
 * Implementations should:
 * - Handle exception scenarios gracefully.
 * - Ensure consistent metric aggregation and timestamp setting (if required).
 */
public interface SensorNBService {

    /**
     * Retrieves the current stream license usage information.
     *
     * @return StreamLicenseUsage containing license statistics.
     */
    StreamLicenseUsage getStreamLicenseUsage();
}
