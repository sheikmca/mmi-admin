package sg.ncs.kp.northbound.pojo.common;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.bind.MissingRequestHeaderException;
import sg.ncs.kp.common.exception.pojo.ClientServiceException;


@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Result<?> handleValidationError(MethodArgumentNotValidException ex) {
        String error = ex.getBindingResult()
                .getAllErrors()
                .get(0)
                .getDefaultMessage();
        logger.warn("Validation error => {} ", error);
        return Result.fail("400001", error, HttpStatus.BAD_REQUEST.value());
    }

    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Result<?> handleIllegalArgument(IllegalArgumentException ex) {
        logger.warn("Business error => {} ", ex.getMessage());
        return Result.fail("400200", ex.getMessage(), HttpStatus.BAD_REQUEST.value());
    }


    @ExceptionHandler(IllegalStateException.class)
    @ResponseStatus(HttpStatus.BAD_GATEWAY)
    public Result<?> handleIllegalState(IllegalStateException ex) {
        logger.error("Downstream service error", ex);
        return Result.fail(
                "NB_DOWNSTREAM_ERROR",
                ex.getMessage(),
                HttpStatus.BAD_GATEWAY.value()
        );
    }


    @ExceptionHandler(ClientServiceException.class)
    @ResponseStatus(HttpStatus.BAD_GATEWAY)
    public Result<?> handleClientService(ClientServiceException ex) {
        logger.error("Client service exception", ex);
        return Result.fail(
                "NB_CLIENT_SERVICE_ERROR",
                ex.getMessage(),
                HttpStatus.BAD_GATEWAY.value()
        );
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Result<?> handleBadJson(HttpMessageNotReadableException ex) {

        logger.warn("Malformed JSON request", ex);

        return Result.fail(
                "400002",
                "Malformed JSON request",
                HttpStatus.BAD_REQUEST.value()
        );
    }

    @ExceptionHandler(MissingRequestHeaderException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Result<?> handleMissingHeader(MissingRequestHeaderException ex) {

        logger.warn("Missing header: {}", ex.getHeaderName());

        return Result.fail(
                "400003",
                "Missing required header: " + ex.getHeaderName(),
                HttpStatus.BAD_REQUEST.value()
        );
    }

    @ExceptionHandler(HttpStatusCodeException.class)
    @ResponseStatus(HttpStatus.BAD_GATEWAY)
    public Result<?> handleDownstream(HttpStatusCodeException ex) {

        logger.error("Downstream error: {}", ex.getResponseBodyAsString());

        return Result.fail(
                "NB_DOWNSTREAM_ERROR",
                "Downstream service error",
                HttpStatus.BAD_GATEWAY.value()
        );
    }


    @ExceptionHandler(VmsUpstreamException.class)
    public ResponseEntity<Result<Void>> handleVmsUpstream(VmsUpstreamException ex) {

        Object[] params = ex.getParams();

        return ResponseEntity
                .status(ex.getHttpStatus())
                .body(
                        params == null || params.length == 0
                                ? Result.fail(ex.getErrorCode(), ex.getMessage())
                                : Result.fail(ex.getErrorCode(), ex.getMessage(), params)
                );
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public Result<?> handleGeneralError(Exception ex) {
        logger.error("Unexpected server error  ", ex);
        return Result.fail(
                "500000",
                "Internal server error",
                HttpStatus.INTERNAL_SERVER_ERROR.value()
        );
    }

}