package sg.ncs.kp.admin.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import sg.ncs.kp.admin.dto.WorkStationUserDTO;
import sg.ncs.kp.admin.service.KpWorkStationService;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.common.i18n.util.MessageUtils;
import sg.ncs.kp.uaa.common.dto.WorkStationDTO;
import sg.ncs.kp.uaa.server.service.WorkStationService;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @className WorkStationController
 * @version 1.0.0
 * @date 2023-07-25
 */
@RestController
@RequestMapping("/workstation")
public class WorkStationController {

    @Resource
    private WorkStationService workStationService;

    @Resource
    private KpWorkStationService kpWorkStationService;
    @Resource
    private MessageUtils messageUtils;

    @PostMapping("/save")
    @PreAuthorize("hasAuthority('workstations')")
    public Result save(@Valid @RequestBody WorkStationDTO workStationDTO){
        WorkStationDTO result = workStationService.saveOrUpdate(workStationDTO);
        return messageUtils.addSucceed(result);
    }

    @PutMapping("/update")
    @PreAuthorize("hasAuthority('workstations')")
    public Result update(@Valid @RequestBody WorkStationDTO workStationDTO){
        WorkStationDTO result = workStationService.saveOrUpdate(workStationDTO);
        return messageUtils.updateSucceed(result);
    }

    @DeleteMapping("/delete/{id}")
    @PreAuthorize("hasAuthority('workstations')")
    public Result delete(@PathVariable String id){
        workStationService.delete(id);
        return messageUtils.deleteSucceed();
    }

    @GetMapping("/all")
    @PreAuthorize("hasAuthority('workstations')")
    public Result<List<WorkStationUserDTO>> getAll(){
        return messageUtils.succeed(kpWorkStationService.getAll());
    }
}
