package sg.ncs.kp.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import sg.ncs.kp.admin.po.SystemConfiguration;

/**
 * @date 2022/8/23
 */
public interface SystemConfigurationMapper extends BaseMapper<SystemConfiguration> {
}
