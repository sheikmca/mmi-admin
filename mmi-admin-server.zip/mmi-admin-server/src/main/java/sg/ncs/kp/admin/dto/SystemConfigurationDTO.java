package sg.ncs.kp.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import sg.ncs.kp.admin.po.SystemConfiguration;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SystemConfigurationDTO {

    private Integer subType;
    private List<SystemConfiguration> configuration;
}
