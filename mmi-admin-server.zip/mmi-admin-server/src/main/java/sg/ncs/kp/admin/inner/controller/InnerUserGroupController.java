package sg.ncs.kp.admin.inner.controller;

import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sg.ncs.kp.admin.service.KpUserGroupService;

@RestController
@RequestMapping("/inner/user-group")
@Slf4j
public class InnerUserGroupController {
    @Autowired
    KpUserGroupService kpUserGroupService;
    @GetMapping("/is-exist/{queryCriteria}/{userId}")
    public JSONObject isExistByQueryCriteria(@PathVariable("queryCriteria") String queryCriteria, @PathVariable("userId") String userId){
        return kpUserGroupService.isExistByQueryCriteria(queryCriteria, userId);
    }
}
