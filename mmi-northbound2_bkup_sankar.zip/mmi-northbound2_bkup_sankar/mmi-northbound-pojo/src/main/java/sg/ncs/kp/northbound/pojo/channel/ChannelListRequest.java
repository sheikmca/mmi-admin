package sg.ncs.kp.northbound.pojo.channel;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Request DTO for channel list queries from NB → VMS.
 * Supports filter fields and pagination.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChannelListRequest {

    /** Optional channel name filter */
    private String name;

    /** Optional device model filter */
    private String model;

    /** Optional list of channel IDs (comma-separated) */
    private String channelIds;

    /** Optional channel status filter */
    private String status;

    /** Current page number (1-based indexing) */
 //   @NotNull(message = "pageNo cannot be null")
 //   @Min(value = 1, message = "pageNo must be ≥ 1")
    private Integer pageIndex;

    /** Number of records per page */
 //   @NotNull(message = "pageSize cannot be null")
 //   @Min(value = 1, message = "pageSize must be ≥ 1")
    private Integer pageSize;

}
