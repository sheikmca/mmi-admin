package sg.ncs.kp.northbound.service.impl;

import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import sg.ncs.kp.common.exception.pojo.ClientServiceException;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.northbound.pojo.common.VmsUpstreamException;
import sg.ncs.kp.northbound.service.PlaybackNBService;
import sg.ncs.kp.vms.feign.PlaybackFeign;
import sg.ncs.kp.vms.pojo.playback.GetPlayBackStreamsDTO;
import sg.ncs.kp.vms.pojo.playback.PlayBackUrlVO;
import sg.ncs.kp.vms.pojo.sdk.enums.RecordSourceEnum;

import java.io.IOException;
import java.io.InputStream;

@Slf4j
@Service
@RequiredArgsConstructor
public class PlaybackNBServiceImpl implements PlaybackNBService {

    private final PlaybackFeign playbackFeign;

    /**
     * Get playback URL or return null if no playback record exists.
     */
    @Override
    public PlayBackUrlVO getPlayback(GetPlayBackStreamsDTO dto) {

        if (dto == null) {
            throw VmsUpstreamException.badRequest(
                    "invalid-request",
                    "Playback request cannot be null"
            );
        }

        if(dto.getSource() != null){
            dto.setSource(RecordSourceEnum.valueOf(dto.getSource().name().toUpperCase()));
            log.info("NB → Normalized source to {}", dto.getSource());
        }

        try {
            log.info("NB → Calling VMS Playback API with DTO: {}", dto);

            Result<PlayBackUrlVO> vmsResponse = playbackFeign.getPlayBack(dto);
            log.info("NB → VMS Playback Response: {}", vmsResponse);

            if (vmsResponse == null) {
                log.error("NB → VMS returned NULL playback response");
                throw VmsUpstreamException.upstreamError(
                        "vms-null-response",
                        "VMS returned empty playback response"
                );
            }

            // -------------------------
            // CASE 1: Success
            // -------------------------
            if (Boolean.TRUE.equals(vmsResponse.getStatus())) {
                return vmsResponse.getData();
            }

            String code = vmsResponse.getCode();
            String msg  = vmsResponse.getMsg() == null ? "" : vmsResponse.getMsg();
            String lowerMsg = msg.toLowerCase();

            log.warn("VMS → Playback failed. code={}, msg={}", code, msg);

            // -------------------------
            // NO RECORDING (NOT AN ERROR)
            // -------------------------
            if ("no-recording".equals(code)
                    || "1v000046".equals(code)
                    || msg.contains("No playback record")) {
                return null;
            }

            if (lowerMsg.contains("start time") && lowerMsg.contains("end time")) {
                throw VmsUpstreamException.badRequest(
                        "start-must-be-before-end",
                        "Start time must be before end time"
                );
            }

            // -------------------------
            // FAILURE MAPPING
            // -------------------------
            switch (code) {

                // -------- 400 --------
                case "invalid-channel-id":
                case "invalid-stream-id":
                case "invalid-start-time":
                case "invalid-end-time":
                    throw VmsUpstreamException.badRequest(code, msg);
           //     case "start-must-be-before-end":

                case "exceeded-stream-limit":
                    Integer limit = extractLimit(msg);
                    throw VmsUpstreamException.badRequest(
                            code,
                            "Exceeded stream limit {}.",
                            limit
                    );

                    // -------- 404 --------
                case "channel-not-found":
                case "stream-not-found":
                    throw VmsUpstreamException.notFound(code, msg);

                    // -------- FALLBACK --------
                default:

                    if (!msg.isEmpty()) {


                        // ---- INVALID INPUT (400)
                        if (lowerMsg.contains("invalid") && lowerMsg.contains("channel")) {
                            throw VmsUpstreamException.badRequest(
                                    "invalid-channel-id",
                                    "'channelId' is required and must be a non-empty string"
                            );
                        }

                        if (lowerMsg.contains("invalid") && lowerMsg.contains("stream")) {
                            throw VmsUpstreamException.badRequest(
                                    "invalid-stream-id",
                                    "'streamId' passed but out of range"
                            );
                        }

                        // ---- NOT FOUND (404)
                        if (lowerMsg.contains("channel") && lowerMsg.contains("not found")) {
                            throw VmsUpstreamException.notFound(
                                    "channel-not-found",
                                    "Can not find the channel"
                            );
                        }

                        if (lowerMsg.contains("invalid") && lowerMsg.contains("channel")) {
                            throw VmsUpstreamException.badRequest(
                                    "invalid-channel-id",
                                    "'channelId' is required and must be a non-empty string"
                            );
                        }


                        if (lowerMsg.contains("stream") && lowerMsg.contains("not found")) {
                            throw VmsUpstreamException.notFound(
                                    "stream-not-found",
                                    "Can not find the stream"
                            );
                        }

                        if (lowerMsg.contains("invalid") && lowerMsg.contains("stream")) {
                            throw VmsUpstreamException.badRequest(
                                    "invalid-stream-id",
                                    "'streamId' passed but out of range"
                            );
                        }


                    }

                    throw VmsUpstreamException.upstreamError(
                            code != null ? code : "vms-error",
                            msg.isEmpty() ? "Unknown VMS playback error" : msg
                    );
            }

        } catch (FeignException.BadRequest ex) {
            // -------------------------
            // CASE 4: VMS returned HTTP 400 (treated as no data)
            // -------------------------
            log.warn("VMS 400 (No playback record): {}", ex.getMessage());
            return null;

        }  catch (FeignException.NotFound ex) {
            throw VmsUpstreamException.notFound(
                    "stream-not-found",
                    "Can not find the stream"
            );

        } catch (FeignException.Forbidden ex) {
            throw VmsUpstreamException.forbidden(
                    "forbidden",
                    "Access denied"
            );

        } catch (FeignException.Unauthorized ex) {
            throw VmsUpstreamException.unauthorized(
                    "unauthorized",
                    "Unauthorized request"
            );

        } catch (FeignException ex) {
            log.error("VMS unreachable", ex);
            throw VmsUpstreamException.upstreamError(
                    "vms-unreachable",
                    "VMS unreachable"
            );
        }
    }

    /**
     * Get miniclip stream or return null if no miniclip is available.
     */
    @Override
    public InputStream getNBRecent(GetPlayBackStreamsDTO dto)  {
        log.info("NB → Calling VMS Recent miniclip API with DTO: {}", dto);

        if (dto == null) {
            throw new IllegalArgumentException("Miniclip request cannot be null");
        }

        if(dto.getSource() != null){
            dto.setSource(RecordSourceEnum.valueOf(dto.getSource().name().toUpperCase()));
            log.info("NB → Normalized source to {}", dto.getSource());
        }

        try {
            ResponseEntity<Resource> response = playbackFeign.getNBRecent(dto);

            if (response == null || response.getBody() == null) {
                log.warn("NB → VMS returned NULL miniclip.");
                return null;
            }

            return response.getBody().getInputStream();

        } catch (FeignException ex) {

            String body = ex.contentUTF8();
            log.error("NB → VMS miniclip error body: {}", body);

            // -------------------------
            // CASE 1: No recorded file
            // -------------------------
            if (body != null && (
                    body.contains("No playback record")
                            || body.contains("no recorded file")
                            || body.contains("no recorded file to miniclip")
            )) {
                log.warn("NB → No miniclip exists for this request.");
                return null;
            }

            // -------------------------
            // CASE 2: VMS device/process error
            // -------------------------
            if (body != null && body.contains("Device/Video process error")) {
                log.warn("NB → VMS processing error, returning no miniclip.");
                return null;
            }

            // -------------------------
            // CASE 3: VMS business errors (not fatal)
            // -------------------------
            if (body != null && (
                    body.contains("\"status\":false")
                            || body.contains("\"code\":\"2x00020\"")
                            || body.contains("vms error")
            )) {
                log.warn("NB → VMS business error: treating as NO miniclip.");
                return null;
            }

            // -------------------------
            // CASE 4: Network / system errors
            // -------------------------
            if (ex instanceof FeignException.FeignServerException
                    || ex instanceof FeignException.FeignClientException) {

                log.error("NB → System/Network failure calling VMS miniclip: {}", ex.getMessage());
              //  throw new IOException("Failed to fetch miniclip from VMS", ex);
            }

            // Default: rethrow
            throw ex;
        }
        catch(IOException e ){
            log.error("Failed to get recent miniclip", e);
            throw new IllegalStateException("Unable to fetch miniclip", e);
        }
    }

    private Integer extractLimit(String msg) {
        try {
            return Integer.parseInt(msg.replaceAll("\\D+", ""));
        } catch (Exception e) {
            return null;
        }
    }
}
