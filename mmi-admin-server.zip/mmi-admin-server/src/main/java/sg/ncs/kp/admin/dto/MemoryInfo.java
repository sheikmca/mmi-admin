package sg.ncs.kp.admin.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MemoryInfo {
    /**
     * total
     */
    private double total;

    /**
     * used
     */
    private double used;

    /**
     * free
     */
    private double free;
}
