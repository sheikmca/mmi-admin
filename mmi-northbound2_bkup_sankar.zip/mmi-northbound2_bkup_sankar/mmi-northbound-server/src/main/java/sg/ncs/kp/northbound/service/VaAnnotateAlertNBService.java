package sg.ncs.kp.northbound.service;

import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.vap.pojo.sdk.dto.query.AlertMetadataDTO;

/**
 * Northbound service interface for annotating/updating alert metadata in VAP.
 *
 * Responsibilities:
 * - Accept alert metadata update requests from NB controllers.
 * - Forward update operations to the VAP Alarm API (implementation in serviceImpl).
 * - Return the upstream VAP Result<Void> without modification.
 *
 * No business logic should be implemented in this interface.
 */
public interface VaAnnotateAlertNBService {

    /**
     * Updates an alert's metadata in the VAP system.
     *
     * @param dto alert metadata containing ID and key-value annotation data.
     * @return Result<Void> containing VAP's update operation status and message.
     */
    Result<Void> updateAlarm(AlertMetadataDTO dto);
}
