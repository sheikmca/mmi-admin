package sg.ncs.kp.admin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.common.i18n.util.MessageUtils;
import sg.ncs.kp.uaa.client.util.SessionUtil;
import sg.ncs.kp.uaa.common.dto.PermissionDTO;
import sg.ncs.kp.uaa.common.enums.UserLevelEnum;
import sg.ncs.kp.uaa.server.po.Permission;
import sg.ncs.kp.uaa.server.service.PermissionService;

import java.util.List;
import java.util.Set;

/**
 * @auther 
 * @date 2022/8/30
 * @description
 */
@RestController
@RequestMapping("/permission")
public class PermissionController {

    @Autowired
    private PermissionService permissionService;

    @Autowired
    private MessageUtils messageUtils;

    @Value("${admin.systemRoleId}")
    private Long systemRoleId;


    @GetMapping
    @PreAuthorize("hasAnyAuthority('roleManagementEdit','roleManagementAdd')")
    public Result<List<PermissionDTO>> permission(){
        Set<Long> roleIds = SessionUtil.getRoles();
        UserLevelEnum userLevelEnum = UserLevelEnum.USER;
        if(roleIds.contains(systemRoleId)){
            userLevelEnum = UserLevelEnum.TENANT_ADMIN;
        }
        List<PermissionDTO> tree = permissionService.tree(SessionUtil.getUserId(), userLevelEnum);
        return messageUtils.succeed(tree);
    }

    @GetMapping("/list")
    @PreAuthorize("hasAnyAuthority('assignWorkspace','roleManagementEdit','roleManagementAdd')")
    public Result<List<Permission>> permissionList(@RequestParam("roleId") Long roleId){
        List<Permission> permissions = permissionService.getPermissionsByRole(roleId);
        return messageUtils.succeed(permissions);
    }

}
