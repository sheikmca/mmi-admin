package sg.ncs.kp.admin.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * @auther 
 * @date 2022/9/1
 * @description
 */
@Getter
@Setter
public class UserUploadPathDTO {

    private String path;
}
