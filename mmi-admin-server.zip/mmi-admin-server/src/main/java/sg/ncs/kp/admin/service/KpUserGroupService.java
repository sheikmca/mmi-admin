package sg.ncs.kp.admin.service;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import sg.ncs.kp.uaa.common.dto.UserDTO;
import sg.ncs.kp.uaa.common.dto.UserGroupAssignUserDTO;

import java.util.Set;

/**
 * @className KpUserGroupService
 * @version 1.0.0
 * @date 2023-08-21
 */
public interface KpUserGroupService {
    void judgeDirection(String direction, String userId);

    IPage<UserDTO> getUserListByGroupId(UserGroupAssignUserDTO userGroupAssignUserDTO);

    Set<String> getRootUserGroupAllUserId(Long userGroupId);

    JSONObject isExistByQueryCriteria(String queryCriteria, String userId);
}
