package sg.ncs.kp.northbound.service;

import sg.ncs.kp.vms.pojo.playback.GetPlayBackStreamsDTO;
import sg.ncs.kp.vms.pojo.playback.PlayBackUrlVO;

import java.io.InputStream;

/**
 * Northbound service interface for handling playback-related operations.
 *
 * Responsibilities:
 * - Act as the entry point for NB controller playback requests.
 * - Forward playback queries to the VMS playback service via Feign (implemented in serviceImpl).
 * - Return playback URLs or miniclip streams based on VMS responses.
 *
 * No business logic should be implemented here.
 */
public interface PlaybackNBService {

    /**
     * Retrieves the playback URL for a given playback request.
     *
     * @param dto the playback request containing device/channel/time range parameters.
     * @return PlayBackUrlVO containing playback URL or an empty VO if no playback exists.
     */
    PlayBackUrlVO getPlayback(GetPlayBackStreamsDTO dto);

    /**
     * Retrieves the miniclip (recent recorded event video) as an InputStream.
     *
     * @param dto the playback request specifying device/channel and time range.
     * @return InputStream of miniclip video, or null if VMS indicates no video is available.
     * @throws Exception if a Feign/network/system error occurs.
     */
    InputStream getNBRecent(GetPlayBackStreamsDTO dto);
}
