package sg.ncs.kp.northbound.pojo.sensor;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 流许可证使用情况数据模型
 * 用于表示C3系统流许可证状态信息
 */
@Getter
@Setter
@ToString
public class StreamLicenseUsage {
    
    /**
     * 总并发流许可证数
     * 数据类型：Uint16 (0 - 32767)
     */
    private Integer totalStreamLicense;
    
    /**
     * 已使用的流许可证数
     * 数据类型：Uint16 (0 - 32767)
     */
    private Integer licenseInUse;
    
    /**
     * 时间戳，用于验证视频代理状态
     * 数据类型：Int64 (毫秒级时间戳)
     */
    private Long timestamp;
    
    // 构造函数
    public StreamLicenseUsage() {
    }
    
    public StreamLicenseUsage(Integer totalStreamLicense, Integer licenseInUse, Long timestamp) {
        this.totalStreamLicense = totalStreamLicense;
        this.licenseInUse = licenseInUse;
        this.timestamp = timestamp;
    }
}