package sg.ncs.kp.northbound.service;

import sg.ncs.kp.vms.pojo.sdk.dto.ControlPtzDTO;

/**
 * Northbound service interface for controlling PTZ (Pan-Tilt-Zoom) operations.
 *
 * Responsibilities:
 * - Receive PTZ control commands from the NB controller.
 * - Forward PTZ commands to the VMS PTZ Feign client (implementation in serviceImpl).
 * - Return success/failure based on VMS response.
 *
 * No business logic should be implemented in this interface.
 */
public interface PtzNBService {

    /**
     * Executes a PTZ control command for a given device/channel.
     *
     * @param dto the PTZ command containing deviceId, channelId, PTZ action and value.
     * @return true if VMS confirms successful PTZ control; false if VMS indicates failure.
     */
    Boolean controlPtz(ControlPtzDTO dto);
}
