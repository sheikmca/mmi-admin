package sg.ncs.kp.admin.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sg.ncs.kp.admin.dto.UserMonitorDTO;
import sg.ncs.kp.admin.dto.UserMonitorQueryDTO;
import sg.ncs.kp.admin.dto.WorkStationUserDTO;
import sg.ncs.kp.admin.mapper.UserMonitorMapper;
import sg.ncs.kp.admin.service.KpWorkStationService;
import sg.ncs.kp.uaa.client.util.SessionUtil;
import sg.ncs.kp.uaa.common.dto.WorkStationDTO;
import sg.ncs.kp.uaa.common.enums.UserLevelEnum;
import sg.ncs.kp.uaa.common.enums.WorkStationStatusEnum;
import sg.ncs.kp.uaa.server.po.User;
import sg.ncs.kp.uaa.server.service.WorkStationService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class KpWorkStationServiceImpl implements KpWorkStationService {

    @Autowired
    private WorkStationService workStationService;
    @Autowired
    private UserMonitorMapper userMonitorMapper;
    @Override
    public List<WorkStationUserDTO> getAll() {
        List<WorkStationDTO> workStationDTOS = workStationService.getAll();
        UserMonitorQueryDTO queryDTO = new UserMonitorQueryDTO();
        queryDTO.setTenantId(SessionUtil.getTenantId());
        List<UserMonitorDTO> userDTO = userMonitorMapper.getUserMonitorList(queryDTO);
        List<WorkStationUserDTO> result = new ArrayList<>();
        Map<String,List<String>> map = new HashMap();
        for(UserMonitorDTO userMonitorDTO:userDTO){
            String tempId = userMonitorDTO.getIp();
            List<String> userNames = map.get(tempId);
            if(ObjectUtil.isEmpty(userNames)){
                userNames = new ArrayList<>();
            }
            userNames.add(userMonitorDTO.getUserName());
            map.put(tempId,userNames);
        }
        if(ObjectUtil.isNotEmpty(workStationDTOS)){
            result = BeanUtil.copyToList(workStationDTOS, WorkStationUserDTO.class);
            for(WorkStationUserDTO workStationUserDTO:result){
                String tempId = workStationUserDTO.getIp();
                List<String> tempUserNames = map.get(tempId);
                if(ObjectUtil.isNotEmpty(tempUserNames)){
                    workStationUserDTO.setUserNames(tempUserNames);
                    map.remove(tempId);
                }else{
                    workStationUserDTO.setUserNames(new ArrayList<>());
                    if(workStationUserDTO.getStatus().equals(WorkStationStatusEnum.ONLINE.getValue())){
                        workStationUserDTO.setStatus(WorkStationStatusEnum.OFFLINE.getValue());
                    }
                }
            }
        }
        for (Map.Entry<String, List<String>> entry : map.entrySet()) {
            WorkStationUserDTO dto = new WorkStationUserDTO();
            dto.setIp(entry.getKey());
            dto.setUserNames(entry.getValue());
            result.add(dto);
        }
        return result;
    }
}
