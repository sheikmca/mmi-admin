package sg.ncs.kp.northbound.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;


import sg.ncs.kp.northbound.pojo.common.PageResult;
import sg.ncs.kp.common.core.response.Result;

import sg.ncs.kp.northbound.pojo.channel.ChannelListRequest;
import sg.ncs.kp.northbound.pojo.sensor.StreamLicenseUsage;
import sg.ncs.kp.northbound.service.*;

import sg.ncs.kp.vms.pojo.channel.ChannelVO;
import sg.ncs.kp.vms.pojo.liveview.GetLiveStreamsDTO;
import sg.ncs.kp.vms.pojo.liveview.GetLiveStreamsVO;
import sg.ncs.kp.vms.pojo.playback.GetPlayBackStreamsDTO;
import sg.ncs.kp.vms.pojo.playback.PlayBackUrlVO;
import sg.ncs.kp.vms.pojo.schedule.ScheduleDetailVO;
import sg.ncs.kp.vms.pojo.sdk.dto.ControlPtzDTO;
import sg.ncs.kp.vms.pojo.sdk.dto.rms.RecordQueryDTO;
import sg.ncs.kp.vms.pojo.sdk.vo.rms.RecordDurationEpochVO;
import sg.ncs.kp.vms.sdk.common.VMSPageResult;


import java.io.InputStream;
import java.util.Collections;
import java.util.List;


/** * 流许可证使用情况API控制器 * 实现GET /sensor/streams/usage接口 */
@Slf4j
@RestController
@RequestMapping("/sensor")
@RequiredArgsConstructor
public class SensorNBController {

    private final SensorNBService sensorService;
    private final ChannelNBService channelNBService;
    private final ScheduleNBService scheduleNBService;
    private final RecordNBService recordNBService;
    private final LiveViewNBService liveViewNBService;
    private final PlaybackNBService playbackNBService;
    private final PtzNBService ptzNBService;


    /** * 获取流许可证使用情况 * <p> * a)
     * This message is sent when C3 requests for the latest Stream
     * License status.
     * * b) Request: * • Method: GET * • Path: sensor/streams/usage
     * * c) Response: * • Successful: * o HTTP Status Code: 200.
     * * o Body: StreamLicenseUsage对象 * • Failure:
     * * o HTTP Status Code: 400, 401, 403.
     * * o Response body: ErrorResponse对象 *
     * * @return ResponseEntity 包含流许可证使用情况或错误信息 */
    /**
     * GET: Stream License Usage
     */

    //@PreAuthorize("hasRole('DENY')")
    @GetMapping("/streams/usage")
    @PreAuthorize("hasAuthority('streamLicenseUsage')")
    public ResponseEntity<StreamLicenseUsage> getStreamLicenseUsage() {

            // 调用服务层获取流许可证使用情况
            StreamLicenseUsage usage = sensorService.getStreamLicenseUsage();

            if (usage == null || usage.getTotalStreamLicense() == null) {
                throw new IllegalArgumentException("Stream license usage not available");
            }

            usage.setTimestamp(System.currentTimeMillis());
            return ResponseEntity.ok(usage);

    }

    /**
     * POST: Channel Search
     */
    @PostMapping("/channels/search")
    public PageResult<ChannelVO> list(@Valid @RequestBody ChannelListRequest req) {
        log.info("NB → Received Channel List request: {}", req);
        return channelNBService.getChannelList(req);
    }

    /**
     * GET: Schedule by ID
     */
        @GetMapping("/recording-schedules/{id}")
    public ResponseEntity<?> getSchedule(@PathVariable String id) {
        log.info("NB → Fetch schedule with ID: {}", id);

        Result<ScheduleDetailVO> result = scheduleNBService.getScheduleById(id);

        if (result == null || !result.getStatus() || result.getData() == null) {
            throw new IllegalArgumentException("Schedule not found");
        }
        return ResponseEntity.ok(result.getData());
    }

    /**
     * POST: Search Recordings
     */
    @PostMapping("/recordings/search")
    public VMSPageResult<RecordDurationEpochVO> listRecords(@Valid  @RequestBody RecordQueryDTO dto) {
        log.info("NB → Received Record List Request: {}", dto);

        VMSPageResult<RecordDurationEpochVO> result = recordNBService.listChannelRecords(dto);

        if (result == null || result.getData() == null) {
            log.warn("NB → No records found for deviceId={}, channelId={}",
                    dto.getDeviceId(), dto.getChannelId());
            return emptyRecordResult(dto);
        }

        return result;
    }

    private VMSPageResult<RecordDurationEpochVO> emptyRecordResult(RecordQueryDTO dto) {
        VMSPageResult<RecordDurationEpochVO> empty = new VMSPageResult<>();
        empty.setData(Collections.emptyList());
        empty.setPageIndex(dto.getPageIndex());
        empty.setPageSize(dto.getPageSize());
        empty.setTotal(0L);
        return empty;
    }

    /**
     * POST: Live Stream
     */
    @PostMapping("/streams/live")
    public ResponseEntity<GetLiveStreamsVO> getLiveStream(@Valid @RequestBody GetLiveStreamsDTO dto) {
        log.info("NB → Received Live Stream request: {}", dto);

        GetLiveStreamsVO response = liveViewNBService.getLiveStream(dto);

        if (response == null) {
            log.warn("NB → No live stream found for deviceId={}, channelId={}",
                    dto.getDeviceId(), dto.getChannelId());
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * POST: Playback Stream URL
     */
    @PostMapping("/streams/playback")
    public ResponseEntity<PlayBackUrlVO> getPlayback(@Valid @RequestBody GetPlayBackStreamsDTO dto) {

        log.info("NB → Received Playback request: {}", dto);

        PlayBackUrlVO result = playbackNBService.getPlayback(dto);
        if(result == null){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(result);
    }


    /**
     * POST: PTZ Control
     */
    @PostMapping("/ptz")
    public ResponseEntity<Void> control(@RequestBody @Validated ControlPtzDTO dto) {
        log.info("NB → Received PTZ control request: {}", dto);
         ptzNBService.controlPtz(dto);
        return ResponseEntity.noContent().build();
    }
}
