package sg.ncs.kp.admin.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import sg.ncs.kp.admin.dto.*;
import sg.ncs.kp.admin.mapper.OperateLogMapper;
import sg.ncs.kp.admin.po.OperateLog;
import sg.ncs.kp.admin.service.LogService;
import sg.ncs.kp.uaa.client.common.UaaConstant;
import sg.ncs.kp.uaa.client.dto.OperateLogDTO;
import sg.ncs.kp.uaa.client.session.UserSession;
import sg.ncs.kp.uaa.client.util.SessionUtil;
import sg.ncs.kp.uaa.server.mapper.LoginLogMapper;
import sg.ncs.kp.uaa.server.po.LoginLog;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * @auther 
 * @date 2022/9/8
 * @description
 */
@Service
public class LogServiceImpl implements LogService {

    @Autowired
    private LoginLogMapper loginLogMapper;

    @Autowired
    private OperateLogMapper operateLogMapper;

    @Value("${admin.systemRoleId}")
    private Long systemRoleId;

    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    @Override
    public Page<LoginLog> loginRecords(LoginLogQueryDTO queryDTO) {
        Set<Long> roleIds = SessionUtil.getRoles();
        String userId=null;
        if(!roleIds.contains(systemRoleId)){
            userId = SessionUtil.getUserId();
        }
        Page<LoginLog> page = new Page<>(queryDTO.getPageNo(), queryDTO.getPageSize());
        page = loginLogMapper.selectPage(page, Wrappers.<LoginLog>lambdaQuery()
                .eq(LoginLog :: getTenantId,SessionUtil.getTenantId())
                .like(StringUtils.isNotBlank(queryDTO.getUserName()), LoginLog::getUserName, queryDTO.getUserName())
                .like(StringUtils.isNotBlank(queryDTO.getEmail()), LoginLog::getEmail, queryDTO.getEmail())
                .like(StringUtils.isNotBlank(queryDTO.getPhone()), LoginLog::getPhone, queryDTO.getPhone())
                .like(StringUtils.isNotBlank(queryDTO.getIp()), LoginLog::getIp, queryDTO.getIp())
                .like(StringUtils.isNotBlank(queryDTO.getUserGroupName()), LoginLog::getUserGroupName, queryDTO.getUserGroupName())
                .eq(ObjectUtil.isNotNull(queryDTO.getUserIdNum()), LoginLog::getUserIdNum, queryDTO.getUserIdNum())
                .ge(ObjectUtil.isNotNull(queryDTO.getLoginTimeBegin()), LoginLog::getLoginTime, queryDTO.getLoginTimeBegin())
                .le(ObjectUtil.isNotNull(queryDTO.getLoginTimeEnd()), LoginLog::getLoginTime, queryDTO.getLoginTimeEnd())
                .eq(ObjectUtil.isNotNull(userId),LoginLog::getUserId,userId)
                .orderByDesc(LoginLog::getLoginTime)
        );
        return page;
    }

    public Long getLoginLogCount(LoginLogQueryDTO queryDTO){
        Set<Long> roleIds = SessionUtil.getRoles();
        String userId=null;
        if(!roleIds.contains(systemRoleId)){
            userId = SessionUtil.getUserId();
        }
        Long recordCount = loginLogMapper.selectCount(Wrappers.<LoginLog>lambdaQuery()
                .eq(LoginLog :: getTenantId,SessionUtil.getTenantId())
                .like(StringUtils.isNotBlank(queryDTO.getUserName()), LoginLog::getUserName, queryDTO.getUserName())
                .like(StringUtils.isNotBlank(queryDTO.getEmail()), LoginLog::getEmail, queryDTO.getEmail())
                .like(StringUtils.isNotBlank(queryDTO.getPhone()), LoginLog::getPhone, queryDTO.getPhone())
                .like(StringUtils.isNotBlank(queryDTO.getIp()), LoginLog::getIp, queryDTO.getIp())
                .like(StringUtils.isNotBlank(queryDTO.getUserGroupName()), LoginLog::getUserGroupName, queryDTO.getUserGroupName())
                .eq(ObjectUtil.isNotNull(queryDTO.getUserIdNum()), LoginLog::getUserIdNum, queryDTO.getUserIdNum())
                .ge(ObjectUtil.isNotNull(queryDTO.getLoginTimeBegin()), LoginLog::getLoginTime, queryDTO.getLoginTimeBegin())
                .le(ObjectUtil.isNotNull(queryDTO.getLoginTimeEnd()), LoginLog::getLoginTime, queryDTO.getLoginTimeEnd())
                .eq(ObjectUtil.isNotNull(userId),LoginLog::getUserId,userId)
        );
        return recordCount;
    }

    @Override
    public List<LoginLogDTO> getExportLoginLogData(LoginLogQueryDTO queryDTO){
        List<LoginLogDTO> result = new ArrayList<>();
        Long recordCount = this.getLoginLogCount(queryDTO);
        queryDTO.setPageNo(1);
        queryDTO.setPageSize(Math.toIntExact(recordCount));
        Page<LoginLog> page = this.loginRecords(queryDTO);
        List<LoginLog> record = page.getRecords();
        if(ObjectUtil.isEmpty(record)){
            return result;
        }
        //int startNum = queryDTO.getStartNum();
        //List<LoginLog> subList = new ArrayList<>();
        //if(startNum <= 1){
        //    subList = record.subList(0, queryDTO.getEndNum());
        //}else {
        //    subList = record.subList(startNum-1, queryDTO.getEndNum());
        //}

        result = BeanUtil.copyToList(record, LoginLogDTO.class);
        return result;
    }

    @Override
    public Page<OperateLog> operateRecords(OperateLogQueryDTO queryDTO) {
        Set<Long> roleIds = SessionUtil.getRoles();
        String userId=null;
        if(!roleIds.contains(systemRoleId)){
            userId = SessionUtil.getUserId();
        }
        Page<OperateLog> page = new Page<>(queryDTO.getPageNo(), queryDTO.getPageSize());
        page = operateLogMapper.selectPage(page, Wrappers.<OperateLog>lambdaQuery()
                .eq(OperateLog :: getTenantId,SessionUtil.getTenantId())
                .eq(ObjectUtil.isNotNull(queryDTO.getUserIdNum()), OperateLog::getUserIdNum, queryDTO.getUserIdNum())
                .eq(StringUtils.isNotBlank(queryDTO.getEmail()), OperateLog::getEmail, queryDTO.getEmail())
                .eq(StringUtils.isNotBlank(queryDTO.getPhone()), OperateLog::getPhone, queryDTO.getPhone())
                .like(StringUtils.isNotBlank(queryDTO.getUserName()), OperateLog::getUserName, queryDTO.getUserName())
                .like(StringUtils.isNotBlank(queryDTO.getUserGroupName()), OperateLog::getUserGroupName, queryDTO.getUserGroupName())
                .like(StringUtils.isNotBlank(queryDTO.getIp()), OperateLog::getIp, queryDTO.getIp())
                .like(StringUtils.isNotBlank(queryDTO.getOperateType()), OperateLog::getOperateType, queryDTO.getOperateType())
                .ge(ObjectUtil.isNotNull(queryDTO.getOperateTimeBegin()), OperateLog::getLogTime, queryDTO.getOperateTimeBegin())
                .le(ObjectUtil.isNotNull(queryDTO.getOperateTimeEnd()), OperateLog::getLogTime, queryDTO.getOperateTimeEnd())
                .eq(ObjectUtil.isNotNull(userId), OperateLog::getUserId, userId)
                .orderByDesc(OperateLog::getLogTime)
        );
        return page;
    }

    public Long getOperateLogCount(OperateLogQueryDTO queryDTO){
        Set<Long> roleIds = SessionUtil.getRoles();
        String userId=null;
        if(!roleIds.contains(systemRoleId)){
            userId = SessionUtil.getUserId();
        }
        Long recordCount = operateLogMapper.selectCount(Wrappers.<OperateLog>lambdaQuery()
                .eq(OperateLog :: getTenantId,SessionUtil.getTenantId())
                .eq(ObjectUtil.isNotNull(queryDTO.getUserIdNum()), OperateLog::getUserIdNum, queryDTO.getUserIdNum())
                .eq(StringUtils.isNotBlank(queryDTO.getEmail()), OperateLog::getEmail, queryDTO.getEmail())
                .eq(StringUtils.isNotBlank(queryDTO.getPhone()), OperateLog::getPhone, queryDTO.getPhone())
                .like(StringUtils.isNotBlank(queryDTO.getUserName()), OperateLog::getUserName, queryDTO.getUserName())
                .like(StringUtils.isNotBlank(queryDTO.getUserGroupName()), OperateLog::getUserGroupName, queryDTO.getUserGroupName())
                .like(StringUtils.isNotBlank(queryDTO.getIp()), OperateLog::getIp, queryDTO.getIp())
                .like(StringUtils.isNotBlank(queryDTO.getOperateType()), OperateLog::getOperateType, queryDTO.getOperateType())
                .ge(ObjectUtil.isNotNull(queryDTO.getOperateTimeBegin()), OperateLog::getLogTime, queryDTO.getOperateTimeBegin())
                .le(ObjectUtil.isNotNull(queryDTO.getOperateTimeEnd()), OperateLog::getLogTime, queryDTO.getOperateTimeEnd())
                .eq(ObjectUtil.isNotNull(userId), OperateLog::getUserId, userId)
        );
        return recordCount;
    }


    @Override
    public List<OperateLogExportDTO> getExportOperateLogData(OperateLogQueryDTO queryDTO){
        List<OperateLogExportDTO> result = new ArrayList<>();
        Long recordCount = this.getOperateLogCount(queryDTO);
        queryDTO.setPageNo(1);
        queryDTO.setPageSize(Math.toIntExact(recordCount));
        Page<OperateLog> page = this.operateRecords(queryDTO);
        List<OperateLog> record = page.getRecords();
        if(ObjectUtil.isEmpty(record)){
            return result;
        }
        //int startNum = queryDTO.getStartNum();
        //List<OperateLog> subList;
        //if(startNum <= 1){
        //    subList = record.subList(0, queryDTO.getEndNum());
        //}else {
        //    subList = record.subList(startNum-1, queryDTO.getEndNum());
        //}
        result = BeanUtil.copyToList(record, OperateLogExportDTO.class);
        return result;
    }

    @Override
    public void addOprateLog(OperateLogDTO operateLogDTO) {
        UserSession userSession = SessionUtil.getUserSession();
        operateLogDTO.setIp(userSession.getCurrentIp());
        operateLogDTO.setUserId(userSession.getId());
        operateLogDTO.setTenantId(userSession.getTenantId());
        redisTemplate.opsForList().leftPush(UaaConstant.DEFAULT_LOG_QUEUE_KEY, JSONObject.toJSONString(operateLogDTO));
    }
}
