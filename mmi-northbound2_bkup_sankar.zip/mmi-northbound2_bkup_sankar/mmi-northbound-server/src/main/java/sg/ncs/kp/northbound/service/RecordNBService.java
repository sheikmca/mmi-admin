package sg.ncs.kp.northbound.service;

import sg.ncs.kp.vms.pojo.sdk.dto.rms.RecordQueryDTO;
import sg.ncs.kp.vms.pojo.sdk.vo.rms.RecordDurationEpochVO;
import sg.ncs.kp.vms.sdk.common.VMSPageResult;

/**
 * Northbound service interface for retrieving recording history
 * (record list / playback segments) from the VMS Recording subsystem.
 *
 * Responsibilities:
 * - Receive NB (northbound) record list requests from controller.
 * - Forward the request to VMS via Feign client (implemented in serviceImpl).
 * - Return ONLY the VMSPageResult data extracted from the upstream response.
 *
 * No business logic should be implemented here. Implementations should
 * handle Feign exceptions and upstream validation.
 */
public interface RecordNBService {

    /**
     * Fetches paginated recording segments (duration epochs) from VMS
     * based on deviceId, channelId, and time-range filters.
     *
     * @param dto RecordQueryDTO containing filter criteria and pagination info.
     * @return VMSPageResult containing list of recording segments, total count, and pagination metadata.
     */
    VMSPageResult<RecordDurationEpochVO> listChannelRecords(RecordQueryDTO dto);
}
