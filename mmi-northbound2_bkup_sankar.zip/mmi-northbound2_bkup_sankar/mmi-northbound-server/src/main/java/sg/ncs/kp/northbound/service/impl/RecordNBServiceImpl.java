package sg.ncs.kp.northbound.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.northbound.pojo.common.VmsUpstreamException;
import sg.ncs.kp.northbound.service.RecordNBService;
import sg.ncs.kp.vms.feign.RecordingFeign;
import sg.ncs.kp.vms.pojo.sdk.dto.rms.RecordQueryDTO;
import sg.ncs.kp.vms.pojo.sdk.vo.rms.RecordDurationEpochVO;
import sg.ncs.kp.vms.sdk.common.VMSPageResult;

import java.util.Collections;

@Slf4j
@Service
@RequiredArgsConstructor
public class RecordNBServiceImpl implements RecordNBService {

    private final RecordingFeign recordFeign;

    @Override
    public VMSPageResult<RecordDurationEpochVO> listChannelRecords(RecordQueryDTO dto) {

        // -------------------------
        // BASIC VALIDATION
        // -------------------------
        if (dto == null) {
            throw new VmsUpstreamException(
                    400,
                    "invalid-request",
                    "Record query request cannot be null"
            );
        }
        if (dto.getStart() == null || dto.getStart() < 0 ) {
            throw new VmsUpstreamException(
                    400,
                    "invalid-start-time",
                    "'startTime' is required and must be uint32"
            );
        }

        if ( dto.getEnd() == null || dto.getEnd() < 0) {
            throw new VmsUpstreamException(
                    400,
                    "invalid-end-time",
                    "'endTime' is required and must be uint32"
            );
        }



        // PAGING VALIDATION (FIX)
        if (dto.getPageIndex() == null || dto.getPageIndex() < 0) {
            throw new VmsUpstreamException(
                    400,
                    "invalid-page-index",
                    "'page.index' is invalid"
            );
        }

        if (dto.getPageSize() == null || dto.getPageSize() <= 0) {
            throw new VmsUpstreamException(
                    400,
                    "invalid-page-size",
                    "'page.size' is invalid"
            );
        }

        log.info("NB → Calling VMS listChannelRecords with DTO: {}", dto);

        // -------------------------
        // FEIGN CALL (exceptions handled globally)
        // -------------------------
        Result<VMSPageResult<RecordDurationEpochVO>> vmsResp =
                recordFeign.listChannelRecords(dto);

        // -------------------------
        // NULL CHECK
        // -------------------------
        if (vmsResp == null) {
            throw new VmsUpstreamException(
                    400,
                    "vms-null-response",
                    "VMS returned null response"
            );
        }

        // -------------------------
        // UPSTREAM FAILURE
        // -------------------------
        if (Boolean.FALSE.equals(vmsResp.getStatus())) {
            String code = vmsResp.getCode();
            String msg  = vmsResp.getMsg();

            log.warn("NB → VMS failure. code={}, msg={}", code, msg);

            switch (code) {

                // -------- 400 --------
                case "invalid-channel-id":
                case "invalid-stream-id":
                case "invalid-start-time":
                case "invalid-end-time":
                case "invalid-page-index":
                case "invalid-page-size":
                case "start-must-be-before-end":
                    throw new VmsUpstreamException(400, code, msg);

                    // -------- 404 --------
                case "channel-not-found":
                case "stream-not-found":
                case "no-recording":
                    throw new VmsUpstreamException(404, code, msg);

                    // -------- AUTH --------
                case "unauthorized":
                    throw new VmsUpstreamException(401, code, msg);

                case "forbidden":
                    throw new VmsUpstreamException(403, code, msg);

                    // -------- FALLBACK --------
                default:
                    throw new VmsUpstreamException(
                            400,
                            code != null ? code : "vms-error",
                            msg != null ? msg : "VMS validation error"
                    );
            }
        }

        // -------------------------
        // RETURN ONLY THE DATA PART
        // -------------------------
        VMSPageResult<RecordDurationEpochVO> data = vmsResp.getData();

        if (data == null) {
            log.warn("NB → VMS returned success but DATA is NULL for DTO={}", dto);
            return emptyPage(dto);
        }

        return data;
    }

    /**
     * Safe empty page with Long total = 0L
     */
    private VMSPageResult<RecordDurationEpochVO> emptyPage(RecordQueryDTO  dto) {
        VMSPageResult<RecordDurationEpochVO> page = new VMSPageResult<>();
        page.setPageIndex(dto.getPageIndex());
        page.setPageSize(dto.getPageSize());
        page.setTotal(0L);    // <-- Long type
        page.setData(Collections.emptyList());
        return page;
    }
}
