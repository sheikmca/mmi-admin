# ChangeLog

## latest

## 0.1.3
### Enhancement
- Add tenant vo used by tenant detail feign interface

------
## 0.1.2
### Features
- Provide agency config output
- Provide recipient group cache key

## 0.1.1
**Features**
- Provide input and output object defination of mmi-admin Restful interface.

