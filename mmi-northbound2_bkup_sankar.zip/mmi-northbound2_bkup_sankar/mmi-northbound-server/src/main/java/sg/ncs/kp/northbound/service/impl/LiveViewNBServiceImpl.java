package sg.ncs.kp.northbound.service.impl;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.northbound.pojo.common.VmsUpstreamException;
import sg.ncs.kp.northbound.service.LiveViewNBService;
import sg.ncs.kp.vms.feign.LiveViewFeign;
import sg.ncs.kp.vms.pojo.liveview.GetLiveStreamsDTO;
import sg.ncs.kp.vms.pojo.liveview.GetLiveStreamsVO;

import java.util.regex.Pattern;

@Slf4j
@Service
@RequiredArgsConstructor
public class LiveViewNBServiceImpl implements LiveViewNBService {

    private final LiveViewFeign feign;

    private static final Pattern CHANNEL_ID_PATTERN =
            Pattern.compile("^[a-fA-F0-9]{32}$");

    @Override
    public GetLiveStreamsVO getLiveStream(GetLiveStreamsDTO dto) {

        // -------------------------
        // BASIC VALIDATION
        // -------------------------
        if (dto == null) {
            throw new VmsUpstreamException(
                    400,
                    "invalid-request",
                    "Live stream request cannot be null"
            );
        }

        log.info("NB → Calling VMS Live Stream API with DTO: {}", dto);

        // FIX #1: CHANNEL ID FORMAT VALIDATION (NB responsibility)
        if (!StringUtils.hasText(dto.getChannelId())
                || !CHANNEL_ID_PATTERN.matcher(dto.getChannelId()).matches()) {

            throw new VmsUpstreamException(
                    400,
                    "invalid-channel-id",
                    "'channelId' is required and must be a non-empty valid ID"
            );
        }



            // -------------------------
            // FEIGN CALL
            // -------------------------
            Result<GetLiveStreamsVO> vmsResp = feign.getLive(dto);

            if (vmsResp == null) {
                log.error("NB → VMS returned NULL Result for Live Stream API");
                throw new VmsUpstreamException(
                        502,
                        "vms-null-response",
                        "VMS returned empty response"
                );
            }

            // -------------------------
            // UPSTREAM BUSINESS FAILURE
            // -------------------------
            if (Boolean.FALSE.equals(vmsResp.getStatus())) {
                String code = vmsResp.getCode();
                String msg  = vmsResp.getMsg();

                log.warn("VMS → Live stream request failed. code={}, msg={}", code, msg);

                switch (code) {

                    // -------- 400 --------
                    case "invalid-channel-id":
                    case "invalid-stream-id":
                        throw new VmsUpstreamException(400, code, msg);

                    case "exceeded-stream-limit":
                        // If VMS returns limit as param or embedded in msg
                        Integer limit = extractLimit(msg); // helper (see below)
                        throw new VmsUpstreamException(
                                400,
                                code,
                                "Exceeded stream limit {}.",
                                limit
                        );

                        // -------- 404 --------
                    case "channel-not-found":
                    case "stream-not-found":
                        throw new VmsUpstreamException(404, code, msg);

                        // -------- AUTH --------
                    case "unauthorized":
                        throw new VmsUpstreamException(401, code, msg);

                    case "forbidden":
                        throw new VmsUpstreamException(403, code, msg);

                        // -------- FALLBACK --------
                    default:
                        // MESSAGE-BASED FALLBACK (IMPORTANT)
                        if (msg != null) {
                            String lowerMsg = msg.toLowerCase();

                            if (lowerMsg.contains("channel") && lowerMsg.contains("not found")) {
                                throw new VmsUpstreamException(
                                        404,
                                        "channel-not-found",
                                        msg
                                );
                            }

                            if (lowerMsg.contains("stream") && lowerMsg.contains("not found")) {
                                throw new VmsUpstreamException(
                                        404,
                                        "stream-not-found",
                                        msg
                                );
                            }

                            if (lowerMsg.contains("invalid") && lowerMsg.contains("channel")) {
                                throw new VmsUpstreamException(
                                        400,
                                        "invalid-channel-id",
                                        msg
                                );
                            }
                        }

                        // fallback (should rarely happen now)
                        throw new VmsUpstreamException(
                                502,
                                code != null ? code : "vms-error",
                                msg != null ? msg : "Unknown VMS error"
                        );
                }
            }

            // -------------------------
            // SUCCESS BUT NO DATA
            // -------------------------
            if (ObjectUtils.isEmpty(vmsResp.getData())) {
                log.warn("VMS → Live stream success but data is empty for DTO={}", dto);
                throw new VmsUpstreamException(
                        404,
                        "stream-not-found",
                        "Live stream data not available"
                );
            }

            // -------------------------
            // SUCCESS
            // -------------------------
            log.info("NB → Live stream data received successfully.");
            return vmsResp.getData();

    }
    private Integer extractLimit(String msg) {
        try {
            return Integer.parseInt(msg.replaceAll("\\D+", ""));
        } catch (Exception e) {
            return null;
        }
    }

}
