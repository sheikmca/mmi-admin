package sg.ncs.kp.northbound.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.metrics.MetricsProperties;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import sg.ncs.kp.northbound.pojo.sensor.StreamLicenseUsage;
import sg.ncs.kp.northbound.pojo.ErrorResponse;
import sg.ncs.kp.northbound.service.SensorService;

import java.util.Arrays;

/**
 * 流许可证使用情况API控制器
 * 实现GET /sensor/streams/usage接口
 */
@RestController
@RequestMapping("/sensor")
public class SensorController {

    @Autowired
    private SensorService sensorService;

    /**
     * 获取流许可证使用情况
     * <p>
     * a) This message is sent when C3 requests for the latest Stream License status.
     * b) Request:
     * • Method: GET
     * • Path: sensor/streams/usage
     * c) Response:
     * • Successful:
     * o HTTP Status Code: 200.
     * o Body: StreamLicenseUsage对象
     * • Failure:
     * o HTTP Status Code: 400, 401, 403.
     * o Response body: ErrorResponse对象
     *
     * @return ResponseEntity 包含流许可证使用情况或错误信息
     */
    @GetMapping("/streams/usage")
    @PreAuthorize("hasAuthority('streamLicenseUsage')")
    public ResponseEntity<?> getStreamLicenseUsage() {
        try {
            // 调用服务层获取流许可证使用情况
            StreamLicenseUsage usage = sensorService.getStreamLicenseUsage();

            if (usage != null && null != usage.getTotalStreamLicense()) {
                usage.setTimestamp(System.currentTimeMillis());
                return ResponseEntity.ok(usage);
            } else {
                // 如果无法获取数据，返回错误
                ErrorResponse error = new ErrorResponse("device-not-found", Arrays.asList("500"));
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
            }
        } catch (Exception e) {
            // 异常处理
            ErrorResponse error = new ErrorResponse("bad-request", Arrays.asList());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        }
    }
}
