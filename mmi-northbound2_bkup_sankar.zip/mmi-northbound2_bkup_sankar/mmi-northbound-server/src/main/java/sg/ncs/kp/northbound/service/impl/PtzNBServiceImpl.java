package sg.ncs.kp.northbound.service.impl;

import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import sg.ncs.kp.northbound.pojo.common.Result;
import sg.ncs.kp.northbound.pojo.common.VmsUpstreamException;
import sg.ncs.kp.northbound.service.PtzNBService;
import sg.ncs.kp.vms.feign.ChannelFeign;
import sg.ncs.kp.vms.feign.PtzFeign;

import sg.ncs.kp.vms.pojo.channel.ChannelAssignSearchDTO;
import sg.ncs.kp.vms.pojo.channel.ChannelVO;
import sg.ncs.kp.vms.pojo.sdk.dto.ControlPtzDTO;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class PtzNBServiceImpl implements PtzNBService {

    private final PtzFeign ptzFeign;

    private final ChannelFeign channelFeign;

    @Override
    public Boolean controlPtz(ControlPtzDTO dto) {

        // -------------------------
        // BASIC VALIDATION (no logic change)
        // -------------------------
        if (dto == null) {
            throw VmsUpstreamException.badRequest(
                    "invalid-request",
                    "PTZ control request cannot be null" );
        }


        if (!StringUtils.hasText(dto.getChannelId())) {
            throw VmsUpstreamException.badRequest(
                    "invalid-channelId",
                    "'channelId' is required" );
        }

        if (!StringUtils.hasText(dto.getAction())) {
            throw VmsUpstreamException.badRequest(
                    "invalid-action",
                    "'action' is required and must be in command list" );
        }

        if (dto.getValue() != null && (dto.getValue() < 1 || dto.getValue() > 10)) {
            throw VmsUpstreamException.badRequest(
                    "invalid-value",
                    "'value' must be in the range 1 to 10" );
        }

        // -------------------------
        // RESOLVE deviceId INTERNALLY (KEY FIX)
        // -------------------------
        resolveDeviceIdByChannelId(dto);

        log.info(
                "NB → Calling VMS PTZ API | DeviceId={}, ChannelId={}, Action={}, Value={}",
                dto.getDeviceId(),
                dto.getChannelId(),
                dto.getAction(),
                dto.getValue() );

        try {
            // -------------------------
            // FEIGN CALL
            // -------------------------
            Result<Void> response = ptzFeign.controlPtz(dto);

            // -------------------------
            // SUCCESS CASE
            // -------------------------
            if (response != null && Boolean.TRUE.equals(response.isStatus())) {
                log.info("NB → PTZ control succeeded.");
                return true;
            }

            // -------------------------
            // BUSINESS FAILURE (status=false)
            // -------------------------
            if (response != null && Boolean.FALSE.equals(response.isStatus())) {

                String code = response.getCode();
                String msg  = response.getMsg() == null ? "" : response.getMsg();
                String lowerMsg = msg.toLowerCase();

                log.warn("NB → PTZ business failure. code={}, msg={}", code, msg);

                // -------- MESSAGE-BASED MAPPING (CRITICAL FIX) --------
                if (lowerMsg.contains("device") && lowerMsg.contains("channel")) {
                    throw VmsUpstreamException.badRequest(
                            "invalid-channelId",
                            "‘channelId’ is invalid" );
                }

                if (lowerMsg.contains("invalid") && lowerMsg.contains("action")) {
                    throw VmsUpstreamException.badRequest(
                            "invalid-action",
                            "‘action’ is required and must be in command list" );
                }

                if (lowerMsg.contains("invalid") && lowerMsg.contains("value")) {
                    throw VmsUpstreamException.badRequest(
                            "invalid-value",
                            "‘value’ must be in the range 1 to 10" );
                }

                if (lowerMsg.contains("not found")) {
                    throw VmsUpstreamException.notFound(
                            "channel-not-found",
                            "Can not find the channel" );
                }

                // -------- FALLBACK --------
                throw VmsUpstreamException.upstreamError(
                        code != null ? code : "ptz-error",
                        msg.isEmpty() ? "PTZ control failed" : msg  );
            }

            // Should never reach here
            return false;

        } catch (FeignException.BadRequest ex) {
            throw VmsUpstreamException.badRequest(
                    "invalid-request",
                    ex.contentUTF8() );

        } catch (FeignException.NotFound ex) {
            throw VmsUpstreamException.notFound(
                    "channel-not-found",
                    "Can not find the channel" );

        } catch (FeignException.Forbidden ex) {
            throw VmsUpstreamException.forbidden(
                    "forbidden",
                    "Access denied" );

        } catch (FeignException.Unauthorized ex) {
            throw VmsUpstreamException.unauthorized(
                    "unauthorized",
                    "Unauthorized request" );

        } catch (FeignException ex) {
            log.error("NB → PTZ VMS unreachable", ex);
            throw VmsUpstreamException.upstreamError(
                    "vms-unreachable",
                    "VMS unreachable"  );
        }

    }

    // ============================================================
    //  Resolve deviceId using findChannels (SAFE WAY)
    // ============================================================
    private void resolveDeviceIdByChannelId(ControlPtzDTO dto) {

        if (StringUtils.hasText(dto.getDeviceId())) {
            return; // already resolved
        }

        ChannelAssignSearchDTO searchDTO = new ChannelAssignSearchDTO();
        searchDTO.setChannelId(dto.getChannelId());
        searchDTO.setPageIndex(1);
        searchDTO.setPageSize(1);

        log.info("NB → Resolving deviceId using findChannels for channelId={}", dto.getChannelId());

        List<ChannelVO> channels = channelFeign.findChannels(searchDTO);

        if (channels == null || channels.isEmpty()) {
            throw VmsUpstreamException.badRequest(
                    "invalid-channelId",
                    "'channelId' is invalid" );
        }

        ChannelVO channel = channels.get(0);

        if (!StringUtils.hasText(channel.getDeviceId())) {
            throw VmsUpstreamException.badRequest(
                    "invalid-channelId",
                    "DeviceId not found for channel" );
        }

        dto.setDeviceId(channel.getDeviceId());

        log.info( "NB → Resolved deviceId={} for channelId={}",
                channel.getDeviceId(),
                dto.getChannelId()  );
    }

}
