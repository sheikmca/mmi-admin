package sg.ncs.kp.admin.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @className ControlAndViewCountSortDTO
 * @version 1.0.0
 * @date 2023-10-18
 */
@Getter
@Setter
@ToString
public class ControlAndViewCountSortDTO {
    private String key;
    private String order;
}
