package sg.ncs.kp.admin.dto;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @auther 
 * @date 2022/9/8
 * @description
 */
@Getter
@Setter
public class LoginLogDTO {

    @ExcelIgnore
    private Integer id;

    @ExcelIgnore
    private String userId;

    @ExcelProperty(value = "User ID",index = 0)
    private Integer userIdNum;

    @ExcelIgnore
    private Integer loginRegion;

    @ExcelIgnore
    private String tenantId;

    @ExcelProperty(value = "User Name",index = 1)
    private String userName;

    @ExcelProperty(value = "IP",index = 3)
    private String ip;

    @ExcelIgnore
    private String phone;

    @ExcelIgnore
    private String email;

    @ExcelProperty(value = "User Group Name",index = 2)
    private String userGroupName;

    @ExcelProperty(value = "Login Date",index = 4)
    @DateTimeFormat("dd/MM/yyyy HH:mm:ss")
    private Date loginTime;

    @ExcelIgnore
    private Date logoutTime;
}
