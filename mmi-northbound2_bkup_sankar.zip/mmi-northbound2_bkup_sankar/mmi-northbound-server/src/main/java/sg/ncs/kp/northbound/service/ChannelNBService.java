package sg.ncs.kp.northbound.service;

import sg.ncs.kp.northbound.pojo.common.PageResult;
import sg.ncs.kp.northbound.pojo.channel.ChannelListRequest;
import sg.ncs.kp.vms.pojo.channel.ChannelVO;

import java.util.List;

/**
 * Northbound service interface for querying VMS channel information.
 *
 * Responsibilities:
 * - Receive channel query request from NB controller
 * - Forward request to VMS via Feign client (implemented in serviceImpl)
 * - Return list of channels as provided by VMS
 *
 * No business logic should be implemented here.
 */
public interface ChannelNBService {

    /**
     * Fetch a list of channels based on the provided filter request.
     *
     * @param req ChannelListRequest containing filter criteria and paging details.
     * @return List of ChannelVO objects returned from VMS.
     */
    PageResult<ChannelVO> getChannelList(ChannelListRequest req);
}
