package sg.ncs.kp.northbound.service.impl;

import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import sg.ncs.kp.alarm.feign.QueryFeign;
import sg.ncs.kp.common.exception.pojo.ClientServiceException;
import sg.ncs.kp.northbound.pojo.common.VmsUpstreamException;
import sg.ncs.kp.northbound.service.VaQueryNBService;

import java.util.Base64;

@Slf4j
@Service
@RequiredArgsConstructor
public class VaQueryNBServiceImpl implements VaQueryNBService {

    private final QueryFeign queryFeign;

    @Override
    public String getImageBase64ById(String id) {

        // -------------------------
        // BASIC VALIDATION
        // -------------------------
        if (id == null || id.trim().isEmpty()) {
            log.warn("NB → getImageBase64ById called with empty ID");
            throw VmsUpstreamException.badRequest(
                    "invalid-image-id",
                    "'id' is invalid"
            );
        }

        log.info("NB → Calling VAP Feign API to get image for id={}", id);

        try {
            // -------------------------
            // FEIGN CALL
            // -------------------------
            ResponseEntity<byte[]> response = queryFeign.getImageBinaryFileById(id);

            if (response == null || response.getBody() == null) {
                log.warn("NB → No image returned from VAP for id={}", id);
                throw VmsUpstreamException.notFound(
                        "image-not-found",
                        "Can not find the Image"
                );
            }

            byte[] imgBytes = response.getBody();
            log.info("NB → Received {} bytes from VAP for id={}", imgBytes.length, id);

            // -------------------------
            // BASE64 CONVERSION
            // -------------------------
            String base64 = Base64.getEncoder().encodeToString(imgBytes);

            log.debug("NB → Base64 length for id={} = {}", id, base64.length());
            return base64;

        }
        // -------------------------
        // HTTP-LEVEL FAILURES
        // -------------------------
        catch (FeignException.BadRequest ex) {
            throw VmsUpstreamException.badRequest(
                    "invalid-image-id",
                    "'id' is invalid"
            );

        } catch (FeignException.NotFound ex) {
            throw VmsUpstreamException.notFound(
                    "image-not-found",
                    "Can not find the Image"
            );

        } catch (FeignException.Forbidden ex) {
            throw VmsUpstreamException.forbidden(
                    "forbidden",
                    "Access denied"
            );

        } catch (FeignException.Unauthorized ex) {
            throw VmsUpstreamException.unauthorized(
                    "unauthorized",
                    "Unauthorized request"
            );

        } catch (FeignException ex) {
            log.error("VAP unreachable while fetching image id={}", id, ex);
            throw VmsUpstreamException.upstreamError(
                    "vap-unreachable",
                    "VAP service unreachable"
            );

        } catch (Exception ex) {
            log.error("NB → Unexpected error fetching image id={}", id, ex);
            throw VmsUpstreamException.upstreamError(
                    "internal-error",
                    "Failed to fetch image from VAP"
            );
        }
    }
}
