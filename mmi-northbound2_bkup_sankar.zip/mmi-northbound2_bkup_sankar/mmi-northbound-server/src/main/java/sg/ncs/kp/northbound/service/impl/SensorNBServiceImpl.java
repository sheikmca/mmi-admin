package sg.ncs.kp.northbound.service.impl;

import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import sg.ncs.kp.northbound.pojo.common.VmsUpstreamException;
import sg.ncs.kp.northbound.pojo.sensor.StreamLicenseUsage;
import sg.ncs.kp.northbound.service.SensorNBService;
import sg.ncs.kp.uaa.client.util.SessionUtil;
import sg.ncs.kp.vms.feign.VideoExchangeProfileFeign;

@Slf4j
@Service
@RequiredArgsConstructor
public class SensorNBServiceImpl implements SensorNBService {

    private final VideoExchangeProfileFeign videoExchangeProfileFeign;

    @Override
    public StreamLicenseUsage getStreamLicenseUsage() {

        String userId = SessionUtil.getUserId();

        // -------------------------
        // BASIC VALIDATION → 400
        // -------------------------
        if (!StringUtils.hasText(userId)) {
            log.warn("NB → Stream License Usage failed: userId is null or empty");
            throw VmsUpstreamException.badRequest(
                    "invalid-user-id",
                    "'userId' is required" );
        }

        log.info("NB → Fetching stream license usage for userId={}", userId);

        try {
            StreamLicenseUsage usage =
                    videoExchangeProfileFeign.getStreamLicenseUsageByUserId(userId);

            if (usage == null) {
                log.warn("NB → VMS returned null StreamLicenseUsage for userId={}", userId);
                return null; // keep existing behavior if spec allows empty success
            }
            return usage;
        } // -------------------------
        // AUTH FAILURES
        // -------------------------
        catch (FeignException.Unauthorized ex) {
            throw VmsUpstreamException.unauthorized(
                    "unauthorized",
                    "Unauthorized request" );

        } catch (FeignException.Forbidden ex) {
            throw VmsUpstreamException.forbidden(
                    "forbidden",
                    "Access denied" );
        }
        // -------------------------
        // CLIENT ERROR → 400
        // -------------------------
        catch (FeignException.BadRequest ex) {
            throw VmsUpstreamException.badRequest(
                    "invalid-request",
                    ex.contentUTF8() );
        }
        // -------------------------
        // OTHER FEIGN ERRORS
        // -------------------------
        catch (FeignException ex) {
            log.error("NB → VMS unreachable while fetching stream license usage", ex);
            throw VmsUpstreamException.upstreamError(
                    "vms-unreachable",
                    "VMS unreachable" );
        }
    }
}
