package sg.ncs.kp.northbound.service;

/**
 * Northbound service interface for retrieving VA (Video Analytics Platform)
 * alert/recording images in Base64 format.
 *
 * Responsibilities:
 * - Accept image lookup requests from NB controllers.
 * - Forward image retrieval to VAP (via Feign client) in the implementation class.
 * - Convert returned binary data to Base64 string (performed in serviceImpl).
 *
 * This interface should not contain business logic.
 */
public interface VaQueryNBService {

    /**
     * Retrieves an image from VAP by its ID and returns it as a Base64-encoded string.
     *
     * @param id image identifier used by VAP.
     * @return Base64 string if the image exists, or null if VAP returns no image.
     */
    String getImageBase64ById(String id);
}
