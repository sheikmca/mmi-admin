package sg.ncs.kp.admin.service.impl;
/**
 * @className UserMonitorServiceImpl
 * @version 1.0.0
 * @date 2023-07-25
 */

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.yaml.snakeyaml.Yaml;
import sg.ncs.kp.admin.dto.*;
import sg.ncs.kp.admin.mapper.UserMonitorMapper;
import sg.ncs.kp.admin.po.RoleWorkspaceMapping;
import sg.ncs.kp.admin.pojo.AdminConstants;
import sg.ncs.kp.admin.pojo.WSMsgTypEnum;
import sg.ncs.kp.admin.service.KpUserOnlineService;
import sg.ncs.kp.admin.service.UserMonitorService;
import sg.ncs.kp.uaa.client.util.SessionUtil;
import sg.ncs.kp.uaa.common.dto.*;
import sg.ncs.kp.uaa.common.enums.UserLevelEnum;
import sg.ncs.kp.uaa.server.mapper.LoginLogMapper;
import sg.ncs.kp.uaa.server.mapper.RoleMapper;
import sg.ncs.kp.uaa.server.po.LoginLog;
import sg.ncs.kp.uaa.server.po.Role;
import sg.ncs.kp.uaa.server.po.User;
import sg.ncs.kp.uaa.server.service.UserService;
import sg.ncs.kp.vms.feign.TakeoverControlFeign;
import sg.ncs.kp.vms.pojo.channel.ControlAndViewCountDTO;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
@Slf4j
public class UserMonitorServiceImpl implements UserMonitorService {

    @Autowired
    private UserMonitorMapper userMonitorMapper;
    @Autowired
    private RoleMapper roleMapper;
    @Autowired
    private LoginLogMapper loginLogMapper;
    @Autowired
    private UserService userService;
    @Autowired
    private KpUserOnlineService kpUserOnlineService;
    @Autowired
    private TakeoverControlFeign takeoverControlFeign;
    @Value("${admin.systemRoleId}")
    private Long systemRoleId;

    @Override
    public IPage<UserMonitorDTO> selectUserMonitorList(UserMonitorQueryDTO userMonitorQueryDTO) {
        Set<Long> roleIds = SessionUtil.getRoles();
        if(ObjectUtil.isEmpty(roleIds)){
            return null;
        }
        if (roleIds.contains(systemRoleId)) {
            userMonitorQueryDTO.setTenantId(SessionUtil.getTenantId());
        } else {
            userMonitorQueryDTO.setTenantId(SessionUtil.getTenantId());
            userMonitorQueryDTO.setNotEqualRoleId(systemRoleId);
        }
        userMonitorQueryDTO.setUserId(SessionUtil.getUserId());
        userMonitorQueryDTO.setStatus(1);
        Page<User> page = new Page<>(userMonitorQueryDTO.getPageNo(),userMonitorQueryDTO.getPageSize());
        IPage<UserMonitorDTO> userDTOIPage = userMonitorMapper.userMonitorList(page, userMonitorQueryDTO);
        List<UserMonitorDTO> records = userDTOIPage.getRecords();
        if(CollectionUtil.isNotEmpty(records)){
            for (UserMonitorDTO record : records) {
                List<IdNameDTO> roleList = new ArrayList<>();
                IdNameDTO dto = new IdNameDTO();
                dto.setId(record.getRoleId());
                dto.setName(record.getRoleName());
                roleList.add(dto);
                record.setRole(roleList);
                if(ObjectUtil.isEmpty(record.getLastLogoutTime()) && ObjectUtil.isNotEmpty(record.getLastLoginTime())){
                    record.setOnlineStatus(true);
                }else{
                    record.setOnlineStatus(false);
                }
                if(ObjectUtil.isNotEmpty(record.getLastLoginTime())){
                    record.setLastLogin(record.getLastLoginTime().getTime());
                }
                if(ObjectUtil.isNotEmpty(record.getLastLogoutTime())){
                    record.setLastLogout(record.getLastLogoutTime().getTime());
                }
            }
        }
        return userDTOIPage;
    }

    @Override
    public UserMonitorCountDTO getUserCount(){
        UserMonitorCountDTO count = new UserMonitorCountDTO();
        String tenantId = SessionUtil.getTenantId();
        count.setTotalUser(userService.countUsers(tenantId));
        Integer onlineCount = this.getOnlineUserCount();
        if(ObjectUtil.isEmpty(onlineCount)){
            onlineCount = 0;
        }
        count.setOnlineUser(Long.valueOf(onlineCount));
        count.setOfflineUser(count.getTotalUser()-count.getOnlineUser());
        return count;
    }

    private Integer getOnlineUserCount(){
        UserMonitorQueryDTO userMonitorQueryDTO = new UserMonitorQueryDTO();
        Set<Long> roleIds = SessionUtil.getRoles();
        if(ObjectUtil.isEmpty(roleIds)){
            return null;
        }
        userMonitorQueryDTO.setTenantId(SessionUtil.getTenantId());
        if(!roleIds.contains(systemRoleId)){
            userMonitorQueryDTO.setNotEqualRoleId(systemRoleId);
        }
        userMonitorQueryDTO.setOnlineStatus(true);
        return userMonitorMapper.userMonitorCount(userMonitorQueryDTO);
    }

    @Override
    public List<HourOnlineCountDTO> countByTime(Date time){
        Date startTime = DateUtil.beginOfSecond(time);
        Long dayMis=1000*60*60*24-1+time.getTime();
        Date endTime = DateUtil.date(dayMis);
        return loginLogMapper.getHourOnlineUserCount(startTime, endTime);
    }

    @Override
    public List<ControlAndViewCountDTO> listControlAndViewCount(ControlAndViewCountSortDTO sortDTO){
        List<ControlAndViewCountDTO> list = new ArrayList<>();
        List<String> userIds = new ArrayList<>();
        List<User> users = userService.list(Wrappers.<User>lambdaQuery()
                .eq(User::getStatus,1));
        if(ObjectUtil.isNotEmpty(users)){
            userIds = users.stream().map(User::getId).collect(Collectors.toList());
            list = takeoverControlFeign.controlAndViewCount(userIds);
            UserMonitorQueryDTO queryDTO = new UserMonitorQueryDTO();
            queryDTO.setTenantId(SessionUtil.getTenantId());
            queryDTO.setOnlineStatus(true);
            List<UserMonitorDTO> userMonitors = userMonitorMapper.getUserMonitorList(queryDTO);
            List<String> onlineUserNames = new ArrayList<>();
            if(ObjectUtil.isNotEmpty(userMonitors)){
                onlineUserNames = userMonitors.stream().map(UserMonitorDTO::getUserName).collect(Collectors.toList());
            }
            List<String> includeUserIds = new ArrayList<>();
            if(list.stream().count() > 0){
                includeUserIds = list.stream().map(ControlAndViewCountDTO::getUserId).collect(Collectors.toList());
                List<ControlAndViewCountDTO> finalList = list;
                Map<String, ControlAndViewCountDTO> filteredMap = new HashMap<>();
                filteredMap = IntStream.range(0, list.size())
                        .filter(i -> ObjectUtil.isEmpty(finalList.get(i).getUserName()))
                        .boxed()
                        .collect(Collectors.toMap(i -> finalList.get(i).getUserId(), i -> finalList.get(i)));
                List<ControlAndViewCountDTO> needDels = new ArrayList<>();
                if(filteredMap.size() > 0){
                    needDels = new ArrayList<>(filteredMap.values());
                }
                list.removeAll(needDels);
                userIds.removeAll(includeUserIds);
                for(User user:users){
                    if(userIds.contains(user.getId())){
                        ControlAndViewCountDTO dto = new ControlAndViewCountDTO();
                        dto.setUserId(user.getId());
                        dto.setUserName(user.getUserName());
                        list.add(dto);
                    }
                    if(ObjectUtil.isNotEmpty(filteredMap.get(user.getId()))){
                        ControlAndViewCountDTO dto = filteredMap.get(user.getId());
                        dto.setUserName(user.getUserName());
                        list.add(dto);
                    }
                }
            }else{
                for(User user:users){
                    ControlAndViewCountDTO dto = new ControlAndViewCountDTO();
                    dto.setUserId(user.getId());
                    dto.setUserName(user.getUserName());
                    list.add(dto);
                }
            }
            for(ControlAndViewCountDTO dto:list){
                if(dto.getViewCount() < dto.getControlCount()){
                    dto.setControlCount(dto.getViewCount());
                    dto.setControlChannelName(dto.getViewChannelName());
                }
                List<String> viewChannelNames = new ArrayList<>();
                List<String> controlChannelNames = new ArrayList<>();
                if(ObjectUtil.isNotEmpty(dto.getViewChannelName())){
                    viewChannelNames = dto.getViewChannelName();
                }
                if(ObjectUtil.isNotEmpty(dto.getControlChannelName())){
                    controlChannelNames = dto.getControlChannelName();
                }
                viewChannelNames.removeAll(controlChannelNames);
                dto.setViewChannelName(viewChannelNames);
                if(onlineUserNames.contains(dto.getUserName())){
                    dto.setIsOnline(true);
                }
            }
            return getSortedList(list, sortDTO);
        }
        return list;
    }

    private List<ControlAndViewCountDTO> getSortedList(List<ControlAndViewCountDTO> targetList, ControlAndViewCountSortDTO sort){
        List<ControlAndViewCountDTO> sortedList = new ArrayList<>();
        if(sort.getKey().equals("userName")) {
            if(sort.getOrder().equals("asc")) {
                sortedList = targetList.stream()
                        .sorted(Comparator.comparing(ControlAndViewCountDTO::getUserName))
                        .collect(Collectors.toList());
            }else{
                sortedList = targetList.stream()
                        .sorted(Comparator.comparing(ControlAndViewCountDTO::getUserName).reversed())
                        .collect(Collectors.toList());
            }
        }
        if(sort.getKey().equals("controlCount")) {
            if(sort.getOrder().equals("asc")) {
                sortedList = targetList.stream()
                        .sorted(Comparator.comparing(ControlAndViewCountDTO::getControlCount))
                        .collect(Collectors.toList());
            }else{
                sortedList = targetList.stream()
                        .sorted(Comparator.comparing(ControlAndViewCountDTO::getControlCount).reversed())
                        .collect(Collectors.toList());
            }
        }
        if(sort.getKey().equals("viewCount")) {
            if(sort.getOrder().equals("asc")) {
                sortedList = targetList.stream()
                        .sorted(Comparator.comparing(ControlAndViewCountDTO::getViewCount))
                        .collect(Collectors.toList());
            }else{
                sortedList = targetList.stream()
                        .sorted(Comparator.comparing(ControlAndViewCountDTO::getViewCount).reversed())
                        .collect(Collectors.toList());
            }
        }
        return sortedList;
    }
}
