package sg.ncs.kp.admin.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CpuInfo {
    /**
     * core number
     */
    private int cpuNum;

    /**
     * CPU usage
     */
    private double total;

    /**
     * CPU system usage
     */
    private double sys;

    /**
     * CPU user usage
     */
    private double used;

    /**
     * CPU current wait rate
     */
    private double wait;

    /**
     * CPU current free rate
     */
    private double free;
}
