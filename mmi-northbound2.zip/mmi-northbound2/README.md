# MMI Northbound Service

基于Spring Boot 3.5.5 + Java 21的MMI北向服务项目，实现了指定的RESTful API接口。

## 项目结构

```
mmi-northbound/
├── pom.xml                 # 项目根pom.xml
├── mmi-northbound-server/  # 服务模块（合并了core和api模块）
│   ├── src/main/java/sg/ncs/kp/NorthboundApplication.java
│   ├── src/main/java/sg/ncs/kp/northbound/api/
│   │   └── StreamLicenseController.java
│   └── src/main/resources/application.yml
├── mmi-northbound-pojo/    # POJO模块
│   └── src/main/java/sg/ncs/kp/northbound/pojo/
│       ├── StreamLicenseUsage.java
│       └── ErrorResponse.java
├── mmi-northbound-mqtt/    # MQTT模块
│   └── src/main/java/sg/ncs/kp/northbound/mqtt/MqttService.java
```

## 功能特性

1. **RESTful API接口**：
   - 实现GET `/sensor/streams/usage` 接口
   - 成功响应返回200及StreamLicenseUsage对象
   - 失败响应返回400/401/403及ErrorResponse对象

2. **数据模型**：
   - StreamLicenseUsage：流许可证使用情况数据模型
   - ErrorResponse：统一错误响应模型

3. **MQTT集成**：
   - MQTT服务类用于处理MQTT通信

4. **数据库支持**：
   - 使用MyBatis-Plus操作MS SQL Server数据库

5. **缓存支持**：
   - 集成Redis缓存

## API规范

### Get Stream License Usage
- **请求**：
  - 方法：GET
  - 路径：`/sensor/streams/usage`

- **成功响应**：
  - 状态码：200
  - 响应体：
    ```json
    {
      "totalStreamLicense": 100,
      "licenseInUse": 75,
      "timestamp": 1749626843000
    }
    ```

- **失败响应**：
  - 状态码：400, 401, 403
  - 响应体：
    ```json
    {
      "code": "device-not-found",
      "params": ["500"]
    }
    ```

## 配置说明

在`application.yml`中配置以下内容：
- 数据库连接信息
- Redis连接信息
- MQTT连接信息

## 编译和运行

```bash
# 编译项目
mvn clean compile

# 运行项目
mvn spring-boot:run
```

## 依赖技术栈

- Spring Boot 3.5.5
- Java 21
- MyBatis-Plus
- MS SQL Server
- Redis
