package sg.ncs.kp.northbound.service;

import sg.ncs.kp.vms.pojo.liveview.GetLiveStreamsDTO;
import sg.ncs.kp.vms.pojo.liveview.GetLiveStreamsVO;

/**
 * Northbound service interface for retrieving live stream URLs from VMS.
 *
 * Responsibilities:
 * - Receive Live Stream query request from NB Controller
 * - Forward request to VMS LiveView API via Feign client (implemented in serviceImpl)
 * - Return the Live Stream VO provided by VMS (or null if VMS indicates no live stream)
 *
 * No business logic should be implemented in the interface.
 */
public interface LiveViewNBService {

    /**
     * Fetches the live stream URL or stream configuration for the given request.
     *
     * @param dto the DTO containing deviceId, channelId, and stream parameters.
     * @return GetLiveStreamsVO containing stream URLs/info or null if no stream available.
     */
    GetLiveStreamsVO getLiveStream(GetLiveStreamsDTO dto);
}
