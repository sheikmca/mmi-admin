package sg.ncs.kp.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.annotations.Param;
import sg.ncs.kp.admin.po.Workspace;
import sg.ncs.kp.uaa.common.dto.UserDTO;
import sg.ncs.kp.uaa.server.po.User;

import java.util.List;
import java.util.Set;

/**
 * @version 1.0.0
 * @className WorkspaceMapper
 * @date 2023-07-10
 */
public interface WorkspaceMapper extends BaseMapper<Workspace> {
    Integer selectCountByRoleId(@Param("name") String name, @Param("tenantId") String tenantId,
                                @Param("bindingId") Long bindingId, @Param("workspaceId") Long workspaceId);

    IPage<Workspace> list(Page<Workspace> page, @Param("name") String name, @Param("roleId") Long roleId,
                        @Param("setType") Integer setType, @Param("tenantId") String tenantId);

    Workspace selectCurrentWsByUserId(@Param("userId") String userId);
    IPage<Workspace> listAll(Page<Workspace> page, @Param("name") String name,
                             @Param("setType") Integer setType, @Param("tenantId") String tenantId);

    void resetDefaultNormal(@Param("defaultNormal") String defaultNormal);

    List<Long> selectRoleIdsByWorkspaceId(@Param("id") Long id);

     Workspace selectDefaultWsByRoleId(@Param("roleId") Long roleId);

    void delCurrentWsByUserIds(@Param("userIds") Set<String> userIds);
}
