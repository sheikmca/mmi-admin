package sg.ncs.kp.admin.util;

import sg.ncs.kp.admin.dto.*;

import oshi.SystemInfo;
import oshi.hardware.CentralProcessor;
import oshi.hardware.GlobalMemory;
import oshi.software.os.FileSystem;
import oshi.software.os.OSFileStore;
import oshi.software.os.OperatingSystem;
import oshi.util.Util;
import oshi.hardware.CentralProcessor.TickType;
import sg.ncs.kp.admin.enums.SizeEnum;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Properties;


public class HardWareUtil {

    private HardWareUtil() {}

    /**
     * waiting sleep time, unit ms
     */
    private static final int WAIT_TIME_MS = 1000;

    /**
     * get cpu info
     * @return  cpu info
     */
    public static CpuInfo getCpuInfo() {
        oshi.SystemInfo si = new oshi.SystemInfo();
        CentralProcessor processor = si.getHardware().getProcessor();
        // CPU info
        long[] prevTicks = processor.getSystemCpuLoadTicks();
        Util.sleep(WAIT_TIME_MS);
        long[] ticks = processor.getSystemCpuLoadTicks();
        long nice = ticks[TickType.NICE.getIndex()] - prevTicks[TickType.NICE.getIndex()];
        long irq = ticks[TickType.IRQ.getIndex()] - prevTicks[TickType.IRQ.getIndex()];
        long softIrq = ticks[TickType.SOFTIRQ.getIndex()] - prevTicks[TickType.SOFTIRQ.getIndex()];
        long steal = ticks[TickType.STEAL.getIndex()] - prevTicks[TickType.STEAL.getIndex()];
        long cSys = ticks[TickType.SYSTEM.getIndex()] - prevTicks[TickType.SYSTEM.getIndex()];
        long user = ticks[TickType.USER.getIndex()] - prevTicks[TickType.USER.getIndex()];
        long ioWait = ticks[TickType.IOWAIT.getIndex()] - prevTicks[TickType.IOWAIT.getIndex()];
        long idle = ticks[TickType.IDLE.getIndex()] - prevTicks[TickType.IDLE.getIndex()];
        long totalCpu = user + nice + cSys + idle + ioWait + irq + softIrq + steal;
        CpuInfo cpuInfo = new CpuInfo();
        cpuInfo.setCpuNum(processor.getLogicalProcessorCount());
        cpuInfo.setTotal(totalCpu);
        cpuInfo.setSys(cSys);
        cpuInfo.setUsed(user);
        cpuInfo.setWait(ioWait);
        cpuInfo.setFree(idle);
        return cpuInfo;
    }

    /**
     * get memory info
     *
     * @param size  size unit, default is B
     * @return      memory info
     */
    public static MemoryInfo getMemoryInfo(SizeEnum size) {
        SystemInfo si = new SystemInfo();
        GlobalMemory memory = si.getHardware().getMemory();
        // memory info
        MemoryInfo mem = new MemoryInfo();
        mem.setTotal(Objects.isNull(size) ? memory.getTotal() : (float) memory.getTotal() / size.getSize());
        mem.setUsed(Objects.isNull(size) ? (memory.getTotal() - memory.getAvailable()) : (float) (memory.getTotal() - memory.getAvailable()) / size.getSize());
        mem.setFree(Objects.isNull(size) ? memory.getAvailable() : (float) memory.getAvailable() / size.getSize());
        return mem;
    }

    /**
     * get server info
     *
     * @return  server info
     */
    public static SystemDetails getSystemInfo(String ip, String name) {
        // server info
        SystemDetails details = new SystemDetails();
        Properties props = System.getProperties();
        details.setComputerName(name);
        details.setComputerIp(ip);
        details.setOsName(props.getProperty("os.name"));
        details.setOsArch(props.getProperty("os.arch"));
        details.setUserDir(props.getProperty("user.dir"));
        return details;
    }

    /**
     * get jvm info
     */
    public static JvmInfo getJvmInfo() {
        JvmInfo jvmInfo = new JvmInfo();
        Properties props = System.getProperties();
        jvmInfo.setTotal(Runtime.getRuntime().totalMemory());
        jvmInfo.setMax(Runtime.getRuntime().maxMemory());
        jvmInfo.setFree(Runtime.getRuntime().freeMemory());
        jvmInfo.setVersion(props.getProperty("java.version"));
        jvmInfo.setHome(props.getProperty("java.home"));
        return jvmInfo;
    }

    /**
     * get disk info
     */
    public static List<SysFile> getSysFiles() {
        SystemInfo si = new SystemInfo();
        OperatingSystem operatingSystem = si.getOperatingSystem();
        FileSystem fileSystem = operatingSystem.getFileSystem();
        List<OSFileStore> fsArray = fileSystem.getFileStores();
        List<SysFile> sysFiles = new ArrayList<>();
        for (OSFileStore fs : fsArray) {
            long free = fs.getUsableSpace();
            long total = fs.getTotalSpace();
            long used = total - free;
            SysFile sysFile = new SysFile();
            sysFile.setDirName(fs.getMount());
            sysFile.setSysTypeName(fs.getType());
            sysFile.setTypeName(fs.getName());
            sysFile.setTotal(convertFileSize(total));
            sysFile.setFree(convertFileSize(free));
            sysFile.setUsed(convertFileSize(used));
            sysFile.setUsage(mul(div(used, total, 4), 100));
            sysFiles.add(sysFile);
        }
        return sysFiles;
    }

    /**
     * convert byte
     *
     * @param size byte size
     */
    public static String convertFileSize(long size) {
        if (size >= SizeEnum.GB.getSize()) {
            return String.format("%.1f GB", (float) size / SizeEnum.GB.getSize());
        } else if (size >= SizeEnum.MB.getSize()) {
            float f = (float) size / SizeEnum.MB.getSize();
            return String.format(f > 100 ? "%.0f MB" : "%.1f MB", f);
        } else if (size >= SizeEnum.KB.getSize()) {
            float f = (float) size / SizeEnum.KB.getSize();
            return String.format(f > 100 ? "%.0f KB" : "%.1f KB", f);
        } else {
            return String.format("%d B", size);
        }
    }

    /**
     * Provides precise multiplication operation.
     * @param v1 Multiplicand
     * @param v2 Multiplier
     * @return The product of the two parameters
     */
    public static double mul(double v1, double v2) {
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.multiply(b2).doubleValue();
    }

    /**
     * Provides (relatively) precise division operation. When there is a situation of division without remainder,
     * the precision is specified by the scale parameter, and the subsequent numbers are rounded off.
     * @param v1 Dividend
     * @param v2 Divisor
     * @param scale Indicates the precision needed after the decimal point.
     * @return The quotient of the two parameters
     */
    public static double div(double v1, double v2, int scale) {
        if (scale < 0) {
            throw new IllegalArgumentException("The scale must be a positive integer or zero");
        }
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        if (b1.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO.doubleValue();
        }
        return b1.divide(b2, scale, RoundingMode.HALF_UP).doubleValue();
    }

}
