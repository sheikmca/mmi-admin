package sg.ncs.kp.northbound.service;

import sg.ncs.kp.common.core.response.PageResult;
import sg.ncs.kp.vap.pojo.sdk.dto.analytics.EventOrAlertDTO;
import sg.ncs.kp.vap.pojo.sdk.dto.query.AggregateResultQuery;

/**
 * Northbound service interface for searching historical VA (Video Analytics)
 * events or alerts from the VAP system.
 *
 * Responsibilities:
 * - Receive event search requests from NB controllers.
 * - Forward the query to the VAP analytics Feign API (implemented in serviceImpl).
 * - Return paginated results exactly as received from VAP.
 *
 * No business logic should be added here.
 */
public interface VaSearchEventNBService {

    /**
     * Searches historical events or alerts based on query conditions.
     *
     * @param dto query parameters including time range, event type, filters, pagination, etc.
     * @return PageResult containing the list of matching events/alerts and pagination metadata.
     */
    PageResult<EventOrAlertDTO> searchEventHistory(AggregateResultQuery dto);
}
