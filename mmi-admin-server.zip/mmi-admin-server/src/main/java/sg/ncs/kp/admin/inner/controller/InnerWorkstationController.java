package sg.ncs.kp.admin.inner.controller;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sg.ncs.kp.admin.pojo.RoleUserDTO;
import sg.ncs.kp.admin.pojo.WorkstationStatusDTO;
import sg.ncs.kp.admin.service.KpUserService;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.common.i18n.util.MessageUtils;
import sg.ncs.kp.uaa.common.dto.WorkStationDTO;
import sg.ncs.kp.uaa.common.enums.UserLevelEnum;
import sg.ncs.kp.uaa.server.mapper.UserMapper;
import sg.ncs.kp.uaa.server.po.User;
import sg.ncs.kp.uaa.server.po.WorkStation;
import sg.ncs.kp.uaa.server.service.UserRelUserGroupMappingMapperService;
import sg.ncs.kp.uaa.server.service.WorkStationService;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @auther 
 * @date 2022/8/19
 * @description
 */
@RestController
@RequestMapping("/inner/workstation")
@Slf4j
public class InnerWorkstationController {

    @Autowired
    private WorkStationService workStationService;

    @GetMapping("/get-all")
   public List<WorkstationStatusDTO> getAllWorkstation() {
        List<WorkStationDTO> workStations = workStationService.getAll();
        if(ObjectUtil.isNotEmpty(workStations)){
            return BeanUtil.copyToList(workStations,WorkstationStatusDTO.class);
        }
        return null;
    }

    @PutMapping("/batch-update-status")
    public void batchUpdateWorkstationStatus(@RequestBody List<WorkstationStatusDTO> workstationStatusDTOS){
        List<WorkStationDTO> workStations = BeanUtil.copyToList(workstationStatusDTOS,WorkStationDTO.class);
        workStationService.batchUpdateWorkstationStatus(workStations);
    }

    @GetMapping("/machineId/user/{userId}")
    public String getUserWorkstation(@PathVariable Integer userId){
        return workStationService.getWorkstationMachineIdByUserId(userId);
    }

}
