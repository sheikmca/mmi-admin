package sg.ncs.kp.northbound.service.impl;

import jakarta.ws.rs.BadRequestException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import sg.ncs.kp.northbound.pojo.common.PageResult;
import sg.ncs.kp.northbound.pojo.channel.ChannelListRequest;
import sg.ncs.kp.northbound.pojo.common.VmsUpstreamException;
import sg.ncs.kp.northbound.service.ChannelNBService;
import sg.ncs.kp.uaa.client.util.SessionUtil;
import sg.ncs.kp.vms.feign.ChannelFeign;
import sg.ncs.kp.vms.pojo.channel.ChannelAssignSearchDTO;
import sg.ncs.kp.vms.pojo.channel.ChannelVO;

import java.util.Collections;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ChannelNBServiceImpl implements ChannelNBService {

    private final ChannelFeign feign;

    @Override
    public PageResult<ChannelVO> getChannelList(ChannelListRequest req) {

        // ------------------------
        // 1. Basic request validation
        // ------------------------
        if (req == null) {
            throw new IllegalArgumentException("Channel list request cannot be null");
        }

        if (req.getPageIndex() == null || req.getPageIndex() < 1) {
            throw new IllegalArgumentException("Invalid-page-Index");
        }
        if (req.getPageSize() == null || req.getPageSize() < 1) {
            throw new IllegalArgumentException("Invalid-page-size");
        }

        // ------------------------
        // 2. Get tenant from session
        // ------------------------
        String tenantId = SessionUtil.getUserSession().getTenantId();
        if (!StringUtils.hasText(tenantId)) {
            throw new VmsUpstreamException(
                    401,
                    "unauthorized",
                    "Invalid tenantId in session"
            );
        }

        if (req.getPageSize() == null || req.getPageSize() < 1) {
            throw new IllegalStateException("invalid-page-size");
        }
        int pageIndex = req.getPageIndex();
        int pageSize = req.getPageSize();


        // ------------------------
        // 3. Build DTO for VMS
        // ------------------------
        ChannelAssignSearchDTO dto = new ChannelAssignSearchDTO();
        dto.setTenantId(tenantId);
        dto.setPageIndex(pageIndex);
        dto.setPageSize(pageSize);

        if (StringUtils.hasText(req.getName())) {
            dto.setName(req.getName().trim());
        }

        log.info("NB → Calling VMS findChannels with DTO: {}", dto);

        // ------------------------
        // 4. Call VMS through Feign
        //     (Errors are handled by GlobalExceptionHandler)
        // ------------------------

        List<ChannelVO> result = feign.findChannels(dto);

        if (result == null) {
            result = Collections.emptyList();
        }

        log.info("VMS → Returned {} channels", result.size());

        // Wrap result properly
        PageResult<ChannelVO> pageResult = new PageResult<>();
        pageResult.setStatus(true);
        pageResult.setHttpStatus(HttpStatus.OK.value());
        pageResult.setData(result);
        pageResult.setTotalNum((long) result.size());
        pageResult.setPageIndex(pageIndex);
        pageResult.setPageSize(pageSize);

        return pageResult;

    }
}
