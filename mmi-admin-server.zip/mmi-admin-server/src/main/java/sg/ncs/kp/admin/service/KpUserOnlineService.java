package sg.ncs.kp.admin.service;

import sg.ncs.kp.admin.pojo.WSMsgTypEnum;

public interface KpUserOnlineService {
    Boolean isUserOnline(String userId);
    void userOnline(String userId,String accessToken);
    void userOffline(String userId,WSMsgTypEnum type);
    void forceLogout(String userId);
}
