package sg.ncs.kp.northbound.service;

import sg.ncs.kp.northbound.pojo.sensor.StreamLicenseUsage;

public interface SensorService {
    StreamLicenseUsage getStreamLicenseUsage();
}
