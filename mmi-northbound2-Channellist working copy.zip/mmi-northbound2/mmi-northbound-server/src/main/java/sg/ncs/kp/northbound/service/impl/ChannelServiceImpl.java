package sg.ncs.kp.northbound.service.impl;

import sg.ncs.kp.vms.pojo.channel.ChannelAssignDTO;
import sg.ncs.kp.northbound.pojo.channel.ChannelListRequest;
import sg.ncs.kp.vms.feign.ChannelFeign;
import sg.ncs.kp.northbound.service.ChannelService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import sg.ncs.kp.vms.pojo.channel.ChannelAssignSearchDTO;


@Service
@RequiredArgsConstructor
public class ChannelServiceImpl implements ChannelService {

    private final ChannelFeign feign;

    @Override
    public Object getChannelList(ChannelListRequest req){

        ChannelAssignSearchDTO dto = new ChannelAssignSearchDTO();
        dto.setName(req.getName());
        dto.setTenantId(req.getTenantId());

        return feign.findChannels(dto);

    }
}
