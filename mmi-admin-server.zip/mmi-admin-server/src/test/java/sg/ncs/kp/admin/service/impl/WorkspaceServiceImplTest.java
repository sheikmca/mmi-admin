package sg.ncs.kp.admin.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.context.TestPropertySource;
import sg.ncs.kp.admin.dto.WorkspaceDTO;
import sg.ncs.kp.admin.mapper.WorkspaceMapper;
import sg.ncs.kp.admin.po.RoleWorkspaceMapping;
import sg.ncs.kp.admin.po.Workspace;
import sg.ncs.kp.admin.service.RoleWorkspaceService;
import sg.ncs.kp.admin.enums.FrontSizeTypeEnum;
import sg.ncs.kp.admin.enums.SetTypeEnum;
import sg.ncs.kp.common.core.response.PageResult;
import sg.ncs.kp.common.i18n.util.MessageUtils;
import sg.ncs.kp.uaa.client.session.UserSession;
import sg.ncs.kp.uaa.client.util.SessionUtil;
import sg.ncs.kp.uaa.common.enums.StatusEnum;
import sg.ncs.kp.uaa.server.po.Role;
import sg.ncs.kp.uaa.server.service.RoleService;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class WorkspaceServiceImplTest {

    @InjectMocks
    private WorkspaceServiceImpl workspaceService;

    @Mock
    private RoleWorkspaceService roleWorkspaceService;

    @Mock
    private RoleService roleService;

    @Mock
    private WorkspaceMapper workspaceMapper;

    @Mock
    MessageUtils messageUtils;


    @Mock
    private Environment env;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        workspaceService.setSystemRoleId(1L);
    }


    @Test
    void testSaveOrUpdateWorkspace() {
        // Prepare data
        WorkspaceDTO workspaceDTO = new WorkspaceDTO();
        workspaceDTO.setName("test workspace");
        workspaceDTO.setBindingId(1L);
        workspaceDTO.setSetType(SetTypeEnum.NORMAL.getValue());
        workspaceDTO.setFrontSize(FrontSizeTypeEnum.SMALL.getValue());
        workspaceDTO.setFrontStyle("style1");
        workspaceDTO.setBindingId(1L);
        Workspace workspace = new Workspace();
        workspace.setName("test workspace");
        workspace.setSetType(SetTypeEnum.NORMAL.getKey());
        workspace.setFrontSize(FrontSizeTypeEnum.SMALL.getKey());
        workspace.setFrontStyle("style1");
        workspace.setBindingId(1L);
        workspace.setTenantId("tenant1");
        workspace.setCreatedId("createdId");
        workspace.setLastUpdatedId("lastUpdatedId");
        workspace.setCreatedDate(new Date());
        workspace.setLastUpdatedDate(new Date());
        try (MockedStatic<SessionUtil> sessionUtilMockedStatic = mockStatic(SessionUtil.class)) {
            UserSession userSession = new UserSession();
            userSession.setTenantId("tenant id");
            userSession.setId("test");
            Set<Long> roleIds = new HashSet<>();
            roleIds.add(4L);
            userSession.setRoleId(roleIds);
            List<Workspace> workspaces = new ArrayList<>();
            workspaces.add(workspace);
            sessionUtilMockedStatic.when(SessionUtil::getUserSession).thenReturn(userSession);
            sessionUtilMockedStatic.when(SessionUtil::getRoles).thenReturn(roleIds);
            // Call method and verify result
            WorkspaceDTO result = workspaceService.saveOrUpdateWorkspace(workspaceDTO);
            assertEquals(workspaceDTO.getName(), result.getName());
            assertEquals(1, result.getBindingId());
            assertEquals(workspaceDTO.getSetType(), result.getSetType());
            assertEquals(workspaceDTO.getFrontSize(), result.getFrontSize());
            assertEquals(workspaceDTO.getFrontStyle(), result.getFrontStyle());
            assertEquals(new ArrayList<>(), result.getRoleIds());
        }
    }

    @Test
    void testCopyWorkspace() {
        // Prepare data
        WorkspaceDTO workspaceDTO = new WorkspaceDTO();
        workspaceDTO.setName("test workspace");
        workspaceDTO.setBindingId(1L);
        workspaceDTO.setSetType(SetTypeEnum.NORMAL.getValue());
        workspaceDTO.setFrontSize(FrontSizeTypeEnum.SMALL.getValue());
        workspaceDTO.setFrontStyle("style1");
        workspaceDTO.setBindingId(1L);
        workspaceDTO.setRoleIds(Arrays.asList(1L,2L,3L));

        Workspace workspace = new Workspace();
        workspace.setName("test workspace");
        workspace.setSetType(SetTypeEnum.NORMAL.getKey());
        workspace.setFrontSize(FrontSizeTypeEnum.SMALL.getKey());
        workspace.setFrontStyle("style1");
        workspace.setBindingId(1L);
        workspace.setTenantId("tenant1");
        workspace.setCreatedId("createdId");
        workspace.setLastUpdatedId("lastUpdatedId");
        workspace.setCreatedDate(new Date());
        workspace.setLastUpdatedDate(new Date());
        try (MockedStatic<SessionUtil> sessionUtilMockedStatic = mockStatic(SessionUtil.class)) {
            UserSession userSession = new UserSession();
            userSession.setTenantId("tenant id");
            userSession.setId("test");
            Set<Long> roleIds = new HashSet<>();
            roleIds.add(1L);
            userSession.setRoleId(roleIds);
            List<Workspace> workspaces = new ArrayList<>();
            workspaces.add(workspace);
            sessionUtilMockedStatic.when(SessionUtil::getUserSession).thenReturn(userSession);
            List<Long> bindingRoleIds = new ArrayList<>();
            bindingRoleIds.add(1L);
            when(workspaceMapper.selectRoleIdsByWorkspaceId(any())).thenReturn(bindingRoleIds);
            when(workspaceMapper.selectById(any())).thenReturn(workspace);

            // Call method and verify result
            WorkspaceDTO result = workspaceService.copyWorkspace(workspaceDTO.getBindingId());
            assertEquals("test workspace copy1", result.getName());
            assertEquals(1, result.getBindingId());
            assertEquals("Default", result.getSetType());
            assertEquals(workspaceDTO.getFrontSize(), result.getFrontSize());
            assertEquals(workspaceDTO.getFrontStyle(), result.getFrontStyle());
            assertEquals(null, result.getRoleIds());
        }
    }

    @Test
    void testResetWorkspace() {
        // Prepare data
        WorkspaceDTO workspaceDTO = new WorkspaceDTO();
        workspaceDTO.setName("test workspace");
        workspaceDTO.setBindingId(1L);
        workspaceDTO.setSetType(SetTypeEnum.NORMAL.getValue());
        workspaceDTO.setFrontSize(FrontSizeTypeEnum.SMALL.getValue());
        workspaceDTO.setFrontStyle("style1");
        workspaceDTO.setBindingId(1L);
        workspaceDTO.setRoleIds(Arrays.asList(1L,2L,3L));

        Workspace workspace = new Workspace();
        workspace.setName("test workspace");
        workspace.setSetType(SetTypeEnum.NORMAL.getKey());
        workspace.setFrontSize(FrontSizeTypeEnum.SMALL.getKey());
        workspace.setFrontStyle("style1");
        workspace.setBindingId(1L);
        workspace.setTenantId("tenant1");
        workspace.setCreatedId("createdId");
        workspace.setLastUpdatedId("lastUpdatedId");
        workspace.setCreatedDate(new Date());
        workspace.setLastUpdatedDate(new Date());
        try (MockedStatic<SessionUtil> sessionUtilMockedStatic = mockStatic(SessionUtil.class)) {
            UserSession userSession = new UserSession();
            userSession.setTenantId("tenant id");
            userSession.setId("test");
            Set<Long> roleIds = new HashSet<>();
            roleIds.add(2L);
            userSession.setRoleId(roleIds);
            List<Workspace> workspaces = new ArrayList<>();
            workspaces.add(workspace);
            sessionUtilMockedStatic.when(SessionUtil::getUserSession).thenReturn(userSession);
            when(workspaceMapper.selectById(any())).thenReturn(workspace);
            // Call method and verify result
            WorkspaceDTO result = workspaceService.resetWorkspace(workspaceDTO.getBindingId());
            assertEquals(workspaceDTO.getName(), result.getName());
            assertEquals(1, result.getBindingId());
            assertEquals(workspaceDTO.getSetType(), result.getSetType());
            assertEquals(workspaceDTO.getFrontSize(), result.getFrontSize());
            assertEquals(workspaceDTO.getFrontStyle(), result.getFrontStyle());
            assertEquals(null, result.getRoleIds());
        }
    }

    //@Test
    void testList() {
        // Prepare data
        WorkspaceDTO workspaceDTO = new WorkspaceDTO();
        workspaceDTO.setName("test workspace");
        workspaceDTO.setBindingId(1L);
        workspaceDTO.setSetType(SetTypeEnum.NORMAL.getValue());
        workspaceDTO.setFrontSize(FrontSizeTypeEnum.SMALL.getValue());
        workspaceDTO.setFrontStyle("style1");
        workspaceDTO.setBindingId(1L);
        workspaceDTO.setRoleIds(Arrays.asList(1L,2L,3L));

        Workspace workspace = new Workspace();
        workspace.setName("test workspace");
        workspace.setSetType(SetTypeEnum.NORMAL.getKey());
        workspace.setFrontSize(FrontSizeTypeEnum.SMALL.getKey());
        workspace.setFrontStyle("style1");
        workspace.setBindingId(1L);
        workspace.setTenantId("tenant1");
        workspace.setCreatedId("createdId");
        workspace.setLastUpdatedId("lastUpdatedId");
        workspace.setCreatedDate(new Date());
        workspace.setLastUpdatedDate(new Date());
        List<Role> roles = new ArrayList<>();
        Role role = new Role();
        role.setName("System");
        role.setId(2L);
        roles.add(role);
        when(roleService.getRoles(any(), any())).thenReturn(roles);
        IPage<Workspace> page = mock(IPage.class);
        List<Workspace> workspaces = new ArrayList<>();
        workspaces.add(workspace);
        try (MockedStatic<SessionUtil> sessionUtilMockedStatic = mockStatic(SessionUtil.class)) {
            sessionUtilMockedStatic.when(SessionUtil::getTenantId).thenReturn("tenantId");
            when(page.getRecords()).thenReturn(workspaces);
            when(page.getTotal()).thenReturn(1L);
            when(workspaceMapper.list(any(),any(), any(), any(), any())).thenReturn(page);
            when(messageUtils.getMessage(any())).thenReturn("");
            PageResult<Object> result1 = mock(PageResult.class);
            when(messageUtils.pageResult(any(), any(), any(), any())).thenReturn(result1);
            // Call method and verify result
            PageResult<WorkspaceDTO> result = workspaceService.list("test", "testUser", SetTypeEnum.NORMAL.getValue(),1,10);
        }
    }

    @Test
    void testView() {
        // Prepare data
        WorkspaceDTO workspaceDTO = new WorkspaceDTO();
        workspaceDTO.setName("test workspace");
        workspaceDTO.setBindingId(1L);
        workspaceDTO.setSetType(SetTypeEnum.NORMAL.getValue());
        workspaceDTO.setFrontSize(FrontSizeTypeEnum.SMALL.getValue());
        workspaceDTO.setFrontStyle("style1");
        workspaceDTO.setBindingId(1L);
        workspaceDTO.setRoleIds(Arrays.asList(1L,2L,3L));

        Workspace workspace = new Workspace();
        workspace.setName("test workspace");
        workspace.setSetType(SetTypeEnum.NORMAL.getKey());
        workspace.setFrontSize(FrontSizeTypeEnum.SMALL.getKey());
        workspace.setFrontStyle("style1");
        workspace.setBindingId(1L);
        workspace.setTenantId("tenant1");
        workspace.setCreatedId("createdId");
        workspace.setLastUpdatedId("lastUpdatedId");
        workspace.setCreatedDate(new Date());
        workspace.setLastUpdatedDate(new Date());
        try (MockedStatic<SessionUtil> sessionUtilMockedStatic = mockStatic(SessionUtil.class)) {
            UserSession userSession = new UserSession();
            userSession.setTenantId("tenant id");
            userSession.setId("test");
            Set<Long> roleIds = new HashSet<>();
            roleIds.add(1L);
            userSession.setRoleId(roleIds);
            sessionUtilMockedStatic.when(SessionUtil::getUserSession).thenReturn(userSession);
            when(workspaceMapper.selectCurrentWsByUserId(any())).thenReturn(workspace);
            // Call method and verify result
            WorkspaceDTO result = workspaceService.view();
            assertEquals(workspaceDTO.getName(), result.getName());
            assertEquals(1, result.getBindingId());
            assertEquals(workspaceDTO.getSetType(), result.getSetType());
            assertEquals(workspaceDTO.getFrontSize(), result.getFrontSize());
            assertEquals(workspaceDTO.getFrontStyle(), result.getFrontStyle());
            assertEquals(null, result.getRoleIds());
        }
    }

    @Test
    void testAssignWorkspace() {
        // Prepare data
        WorkspaceDTO workspaceDTO = new WorkspaceDTO();
        workspaceDTO.setName("test workspace");
        workspaceDTO.setBindingId(1L);
        workspaceDTO.setSetType(SetTypeEnum.NORMAL.getValue());
        workspaceDTO.setFrontSize(FrontSizeTypeEnum.SMALL.getValue());
        workspaceDTO.setFrontStyle("style1");
        workspaceDTO.setBindingId(1L);
        workspaceDTO.setRoleIds(Arrays.asList(1L,2L,3L));

        Workspace workspace = new Workspace();
        workspace.setName("test workspace");
        workspace.setSetType(SetTypeEnum.NORMAL.getKey());
        workspace.setFrontSize(FrontSizeTypeEnum.SMALL.getKey());
        workspace.setFrontStyle("style1");
        workspace.setBindingId(1L);
        workspace.setTenantId("tenant1");
        workspace.setCreatedId("createdId");
        workspace.setLastUpdatedId("lastUpdatedId");
        workspace.setCreatedDate(new Date());
        workspace.setLastUpdatedDate(new Date());

        // Call method and verify result
        workspaceService.assignWorkspace(workspaceDTO.getBindingId(), Arrays.asList(1L,2L,3L));
    }

    @Test
    void testDeleteWorkspace() {
        // Prepare data
        WorkspaceDTO workspaceDTO = new WorkspaceDTO();
        workspaceDTO.setName("test workspace");
        workspaceDTO.setBindingId(1L);
        workspaceDTO.setSetType(SetTypeEnum.NORMAL.getValue());
        workspaceDTO.setFrontSize(FrontSizeTypeEnum.SMALL.getValue());
        workspaceDTO.setFrontStyle("style1");
        workspaceDTO.setBindingId(1L);
        workspaceDTO.setRoleIds(Arrays.asList(1L,2L,3L));

        Workspace workspace = new Workspace();
        workspace.setName("test workspace");
        workspace.setSetType(SetTypeEnum.NORMAL.getKey());
        workspace.setFrontSize(FrontSizeTypeEnum.SMALL.getKey());
        workspace.setFrontStyle("style1");
        workspace.setBindingId(1L);
        workspace.setTenantId("tenant1");
        workspace.setCreatedId("createdId");
        workspace.setLastUpdatedId("lastUpdatedId");
        workspace.setCreatedDate(new Date());
        workspace.setLastUpdatedDate(new Date());

        // Call method and verify result
        workspaceService.deleteWorkspace(workspaceDTO.getBindingId());
    }

    @Test
    void testSetDefaultNormal() {
        // Prepare data
        WorkspaceDTO workspaceDTO = new WorkspaceDTO();
        workspaceDTO.setName("test workspace");
        workspaceDTO.setBindingId(1L);
        workspaceDTO.setSetType(SetTypeEnum.NORMAL.getValue());
        workspaceDTO.setFrontSize(FrontSizeTypeEnum.SMALL.getValue());
        workspaceDTO.setFrontStyle("style1");
        workspaceDTO.setBindingId(1L);
        workspaceDTO.setRoleIds(Arrays.asList(1L,2L,3L));

        Workspace workspace = new Workspace();
        workspace.setName("test workspace");
        workspace.setSetType(SetTypeEnum.NORMAL.getKey());
        workspace.setFrontSize(FrontSizeTypeEnum.SMALL.getKey());
        workspace.setFrontStyle("style1");
        workspace.setBindingId(1L);
        workspace.setTenantId("tenant1");
        workspace.setCreatedId("createdId");
        workspace.setLastUpdatedId("lastUpdatedId");
        workspace.setCreatedDate(new Date());
        workspace.setLastUpdatedDate(new Date());
        // Call method and verify result
        workspaceService.setDefaultNormal(workspaceDTO.getBindingId());
        try (MockedStatic<SessionUtil> sessionUtilMockedStatic = mockStatic(SessionUtil.class)) {
            UserSession userSession = new UserSession();
            userSession.setTenantId("tenant id");
            userSession.setId("test");
            Set<Long> roleIds = new HashSet<>();
            roleIds.add(1L);
            userSession.setRoleId(roleIds);
            sessionUtilMockedStatic.when(SessionUtil::getUserSession).thenReturn(userSession);
            when(workspaceMapper.selectCurrentWsByUserId(any())).thenReturn(workspace);
            // Verify
            WorkspaceDTO workspaceResult = workspaceService.view();
            assertEquals(workspaceDTO.getName(), workspaceResult.getName());
            assertEquals(1, workspaceResult.getBindingId());
            assertEquals(workspaceDTO.getSetType(), workspaceResult.getSetType());
            assertEquals(workspaceDTO.getFrontSize(), workspaceResult.getFrontSize());
            assertEquals(workspaceDTO.getFrontStyle(), workspaceResult.getFrontStyle());
            assertEquals(null, workspaceResult.getRoleIds());
        }
    }
}