package sg.ncs.kp.admin.controller;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import sg.ncs.kp.admin.dto.*;
import sg.ncs.kp.admin.enums.AdminMsgEnum;
import sg.ncs.kp.admin.pojo.AdminConstants;
import sg.ncs.kp.admin.pojo.DirectionEnum;
import sg.ncs.kp.admin.pojo.WSMsgTypEnum;
import sg.ncs.kp.admin.service.*;
import sg.ncs.kp.admin.util.NotificationUtil;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.common.exception.pojo.ClientServiceException;
import sg.ncs.kp.common.exception.pojo.ServiceException;
import sg.ncs.kp.common.i18n.pojo.MessageEnum;
import sg.ncs.kp.common.i18n.util.MessageUtils;
import sg.ncs.kp.notification.pojo.NotificationConstants;
import sg.ncs.kp.uaa.client.annotation.LogAnnotation;
import sg.ncs.kp.uaa.client.session.UserSession;
import sg.ncs.kp.uaa.client.util.SessionUtil;
import sg.ncs.kp.uaa.common.dto.RefreshTokenDTO;
import sg.ncs.kp.uaa.server.po.User;
import sg.ncs.kp.uaa.server.service.LoginService;
import sg.ncs.kp.uaa.server.service.UserService;
import sg.ncs.kp.uaa.server.utils.RSA2048Util;
import sg.ncs.kp.vms.feign.StreamFeign;
import sg.ncs.kp.vms.feign.TakeoverControlFeign;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * description: TODO
 *
 * @date 2022/8/22 11:06
 */
@RestController
@RequestMapping("/token")
@Slf4j
public class TokenController {

    @Autowired
    private TokenService tokenService;

    @Autowired
    private LoginService loginService;

    @Autowired
    private MessageUtils messageUtils;
    
    @Autowired
    KpUserOnlineService kpUserOnlineService;
    
    @Autowired
    private UserService userService;

    @Autowired
    private KpUserService kpUserService;

    @Autowired
    private ADLoginService adLoginService;

    @Autowired
    private Control2FAService control2FAService;

    @Autowired
    KpUserGroupService kpUserGroupService;

    @Autowired
    private RedisTemplate<String,String> redisTemplate;

    @Autowired
    private RedisTemplate<Object,Object> sessionRedisTemplate;

    @Autowired
    private StreamFeign streamFeign;

    @Autowired
    private TakeoverControlFeign takeoverControlFeign;

    @Autowired
    private NotificationUtil notificationUtil;

    @Value("${system.id}")
    private Long systemId;

    @Value("${admin.check2FAEnabled}")
    private boolean loginNeed2FACheck;

    public static final String LOGIN_2FA_CHECK="check2FA";

    @PostMapping("/login")
    public Result<OAuth2AccessToken> login(@RequestBody Login2FADTO dto) {
        //check is need RSA check;
        User user = userService.getUser(dto.getUserName());
        if(ObjectUtil.isNotEmpty(user)) {
            String checkUserId = user.getId();
            if(kpUserOnlineService.isUserOnline(checkUserId)){
                throw new ClientServiceException(AdminMsgEnum.USER_ON_LINE);
            }
            /*if(ObjectUtil.isNotEmpty(dto.getDirection())){
                kpUserGroupService.judgeDirection(dto.getDirection(),checkUserId);
            }*/
            boolean currentUserRoleNeedRsaCheck = kpUserService.checkUserIsNeed2fa(checkUserId);
            check2FA(checkUserId, currentUserRoleNeedRsaCheck, dto);
        }
        dto.setLoginRegion(DirectionEnum.getIndexByKey(dto.getDirection()));
        Result<OAuth2AccessToken> result = loginService.login(dto);
        OAuth2AccessToken oAuth2AccessToken = result.getData();
        if(Objects.nonNull(oAuth2AccessToken)) {
            //Add user to online User Map
            kpUserOnlineService.userOnline(user.getId(), oAuth2AccessToken.getValue());                
        }
        sendCrossForceLogOutInfo(user.getId());
        return result;
    }

    private void sendCrossForceLogOutInfo(String id) {
        try {
            WSMessageDTO wsMessageDTO = new WSMessageDTO();
            wsMessageDTO.setType(WSMsgTypEnum.CROSS_SITE_FORCED_LOGOUT);
            wsMessageDTO.setMessage(String.valueOf(systemId));
            notificationUtil.sendQueueMsgToWebSocketExchange(wsMessageDTO, NotificationConstants.ADMIN_QUEUE_USER_STATUS, Collections.singletonList(id));
            notificationUtil.sendTopicMsgToWebSocketExchange(new JSONObject(), NotificationConstants.TOPIC_WORKSTATION_STATUS_UPDATE);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    @GetMapping("/get-all-ad-name")
    public Result<List<String>>  getAllAdNames() throws Exception {
        return new Result(adLoginService.getAllADNames(), true, MessageEnum.SUCCESS.code(), this.messageUtils.getMessage(MessageEnum.SUCCESS.val()), HttpStatus.OK.value());
    }

    @PostMapping("/ad-login")
    public Result<OAuth2AccessToken>  adLogin(@RequestBody ADLogin2FADTO params, HttpServletRequest request) throws Exception {
        log.info("param----->{}",params);
        String userName = params.getParam();
        String password = params.getPassword();
        String adName = params.getAdName();
        if(ObjectUtil.isNotEmpty(params.getDirection())){
            kpUserGroupService.judgeDirection(params.getDirection(),null);
        }
        User user = userService.getUser(userName);
        if(ObjectUtil.isNotEmpty(user)) {
            String checkUserId = user.getId();
            if(kpUserOnlineService.isUserOnline(checkUserId)){
                throw new ClientServiceException(AdminMsgEnum.USER_ON_LINE);
            }
            /*if(ObjectUtil.isNotEmpty(params.getDirection())){
                kpUserGroupService.judgeDirection(params.getDirection(),checkUserId);
            }*/
            boolean currentUserRoleNeedRsaCheck = kpUserService.checkUserIsNeed2fa(checkUserId);
            Login2FADTO dto = BeanUtil.copyProperties(params, Login2FADTO.class);
            dto.setUserName(userName);
            check2FA(checkUserId, currentUserRoleNeedRsaCheck, dto);
        }
        CheckADUserResponseDTO returnData = adLoginService.checkADUser(userName, password, adName);
        Integer num = returnData.getNum();

        // LDAP process failed
        if (num != 200) {
            return new Result(null, true, MessageEnum.SUCCESS.code(), this.messageUtils.getMessage(AdminMsgEnum.USER_INCORRECT_CREDENTIALS.val()), HttpStatus.BAD_REQUEST.value());
        } else {
            // New Implement for the AD User login
            return tokenService.adLogin(returnData, adName,params.getDirection());
        }
    }

    @GetMapping("/logout")
    public Result<Void> logout() {
        String userId = SessionUtil.getUserId();
        takeoverControlFeign.deleteByUserId(userId);
        streamFeign.endLiveByUserId(userId);
        loginService.logout();
        //Remove user from online User Map
        kpUserOnlineService.userOffline(SessionUtil.getUserId(), WSMsgTypEnum.FORCED_OFFLINE);
        return messageUtils.updateSucceed();
    }

    @PostMapping("/refresh")
    public Result<OAuth2AccessToken> refresh(@RequestBody RefreshTokenDTO dto) {
        Result<OAuth2AccessToken> result = messageUtils.succeed(loginService.refresh(dto));
        //Add user to online User Map
        OAuth2AccessToken oAuth2AccessToken = result.getData();
        if(Objects.nonNull(oAuth2AccessToken)) {
            kpUserOnlineService.userOnline(SessionUtil.getUserId(), oAuth2AccessToken.getValue());
        }
        return result;
    }

    private void check2FA(String userId, Boolean currentUserRoleNeedRsaCheck, Login2FADTO dto) {
        if(loginNeed2FACheck){
            log.info(">>>>> Start Login check 2FA Code : {}",System.currentTimeMillis());
            // check now could login
            check2FANowLogin(userId, currentUserRoleNeedRsaCheck);

            String acitonStr = dto.getLoginAction();
            if(currentUserRoleNeedRsaCheck && ObjectUtil.isEmpty(acitonStr)){
                control2FAService.initFailedNum(userId);
                throw  new ClientServiceException(AdminMsgEnum.NEED_2FA_CHECK, 402);
            }else if(currentUserRoleNeedRsaCheck && !StringUtils.isEmpty(acitonStr)) {
                String code = dto.getCode2FA();
                if(acitonStr.equals(LOGIN_2FA_CHECK)){
                    control2FAService.check2FA(userId, code);
                }
            }
            log.info(">>>>> End Login check 2FA Code :{}",System.currentTimeMillis());
        }
    }

    private void check2FANowLogin(String userId, Boolean currentUserRoleNeedRsaCheck) {
        // check now could login
        String disabledLoginKey = AdminConstants.CHECK_2FA_DISABLED_LOGIN+userId;
        if(redisTemplate.hasKey(disabledLoginKey) && currentUserRoleNeedRsaCheck){
            Long waitMin = redisTemplate.getExpire(disabledLoginKey, TimeUnit.MINUTES);
            if(waitMin >= 0) {
                if(waitMin == 0){
                    waitMin += 1;
                }
                throw new ClientServiceException(AdminMsgEnum.VERITY_2FA_EXCEEDS_MAXNUM,waitMin+"");
            }else{
                redisTemplate.delete(disabledLoginKey);
            }
        }
    }

    @GetMapping("/rsa-public-key")
    public Result<RSAPublicKeyDTO> getRSAPublicKey() throws ServiceException {
        RSAPublicKeyDTO key = new RSAPublicKeyDTO();
        try {
            RSA2048Util rsa2048Util = RSA2048Util.getInstance(sessionRedisTemplate);
            key.setPublicKey(rsa2048Util.getBase64PublicKey());
        } catch (Exception e) {
            log.error("Get RSA public key is failed",e.getCause());
            throw new ClientServiceException(e.getMessage());
        }
        return messageUtils.succeed(key);
    }

    @LogAnnotation(operateType = "Forced logout")
    @PostMapping("/kick/out")
    @PreAuthorize("hasAuthority('userMonitor')")
    public Result<Void> kickOut(@Valid @RequestBody KickOutDTO dto) {
        String userId = dto.getUserId();
        try {
            takeoverControlFeign.deleteByUserId(userId);
            log.info("delete user takeover control success");
        }catch (Exception e){
            log.error(e.getMessage(),e);
        }
        try {
            streamFeign.endLiveByUserId(userId);
            log.info("end user live success");
        } catch (Exception e){
            log.error(e.getMessage(),e);
        }
        try {
            kpUserOnlineService.forceLogout(userId);
            log.info("force logout success");
        }catch (Exception e){
            log.error(e.getMessage(),e);
        }
        return messageUtils.succeed(null,messageUtils.getMessage(AdminMsgEnum.DISCONNECT_SUCCESS.val()));
    }


    @Deprecated
    //@GetMapping("/get-myself")
    public Result<UserSession> getMyself() {
        return messageUtils.succeed(SessionUtil.getUserSession());
    }

}
