package sg.ncs.kp.admin.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sg.ncs.kp.admin.mapper.RoleWorkspaceMappingMapper;
import sg.ncs.kp.admin.po.RoleWorkspaceMapping;
import sg.ncs.kp.admin.service.RoleWorkspaceService;

import java.util.List;

/**
 * @className RoleWorkspaceServiceImpl
 * @version 1.0.0
 * @date 2023-08-29
 */
@Service
public class RoleWorkspaceServiceImpl extends ServiceImpl<RoleWorkspaceMappingMapper, RoleWorkspaceMapping> implements RoleWorkspaceService {
    @Autowired
    private RoleWorkspaceMappingMapper roleWorkspaceMappingMapper;
    @Override
    public List<RoleWorkspaceMapping> getAllByWorkspaceId(Long workspaceId) {
        return roleWorkspaceMappingMapper.selectList(Wrappers.<RoleWorkspaceMapping>lambdaQuery()
                .eq(RoleWorkspaceMapping::getWorkspaceId,workspaceId));
    }

    @Override
    public List<RoleWorkspaceMapping> getAllByRoleIds(List<Integer> roleIds) {
        return roleWorkspaceMappingMapper.selectList(Wrappers.<RoleWorkspaceMapping>lambdaQuery()
                .in(RoleWorkspaceMapping::getRoleId,roleIds));
    }

    @Override
    public Boolean existWorkspaceByRoleId(Long roleId){
        Long count = 0L;
        count = roleWorkspaceMappingMapper.selectCount(Wrappers.<RoleWorkspaceMapping>lambdaQuery()
                .eq(RoleWorkspaceMapping::getRoleId,roleId));
        if(count > 0){
            return true;
        }
        return false;
    }

    @Override
    public void deleteBatch(Long workspaceId,List<Long> roleIds){
        roleWorkspaceMappingMapper.delete(Wrappers.<RoleWorkspaceMapping>lambdaQuery()
                .eq(RoleWorkspaceMapping::getWorkspaceId,workspaceId)
                .in(RoleWorkspaceMapping::getRoleId,roleIds));
    }

    @Override
    public void deleteBatchByRoleIds(List<Long> roleIds){
        roleWorkspaceMappingMapper.delete(Wrappers.<RoleWorkspaceMapping>lambdaQuery()
                .in(RoleWorkspaceMapping::getRoleId,roleIds));
    }

    @Override
    public void deleteBatchByWsIds(List<Long> wsIds){
        roleWorkspaceMappingMapper.delete(Wrappers.<RoleWorkspaceMapping>lambdaQuery()
                .in(RoleWorkspaceMapping::getWorkspaceId,wsIds));
    }

    @Override
    public void deleteBatchNotWorkspaceId(List<Integer> roleIds, Integer workspaceId){
        roleWorkspaceMappingMapper.delete(Wrappers.<RoleWorkspaceMapping>lambdaQuery()
                .in(RoleWorkspaceMapping::getRoleId,roleIds)
                .ne(RoleWorkspaceMapping::getWorkspaceId, workspaceId));
    }

    @Override
    public void deleteBatch(Long workspaceId){
        roleWorkspaceMappingMapper.delete(Wrappers.<RoleWorkspaceMapping>lambdaQuery()
                .eq(RoleWorkspaceMapping::getWorkspaceId,workspaceId));
    }

    @Override
    public void deleteOne(String userId){
        roleWorkspaceMappingMapper.delete(Wrappers.<RoleWorkspaceMapping>lambdaQuery()
                .eq(RoleWorkspaceMapping::getUserId,userId));
    }

    @Override
    public RoleWorkspaceMapping getByUserId(String userId){
        return roleWorkspaceMappingMapper.selectOne(Wrappers.<RoleWorkspaceMapping>lambdaQuery()
                .eq(RoleWorkspaceMapping::getUserId,userId));
    }

    @Override
    public RoleWorkspaceMapping getDefaultWsByRoleId(Long roleId) {
        return roleWorkspaceMappingMapper.selectOne((Wrappers.<RoleWorkspaceMapping>lambdaQuery()
                .eq(RoleWorkspaceMapping::getRoleId,roleId)
                .isNull(RoleWorkspaceMapping::getUserId)));
    }
}
