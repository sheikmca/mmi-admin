package sg.ncs.kp.admin.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import sg.ncs.kp.admin.dto.ControlAndViewCountSortDTO;
import sg.ncs.kp.admin.dto.UserMonitorCountDTO;
import sg.ncs.kp.admin.dto.UserMonitorDTO;
import sg.ncs.kp.admin.dto.UserMonitorQueryDTO;
import sg.ncs.kp.uaa.common.dto.HourOnlineCountDTO;
import sg.ncs.kp.vms.pojo.channel.ControlAndViewCountDTO;

import java.util.Date;
import java.util.List;

/**
 * @className UserMonitorService
 * @version 1.0.0
 * @date 2023-07-25
 */

public interface UserMonitorService {

    IPage<UserMonitorDTO> selectUserMonitorList(UserMonitorQueryDTO userMonitorQueryDTO);

    UserMonitorCountDTO getUserCount();

    List<HourOnlineCountDTO> countByTime(Date time);

    List<ControlAndViewCountDTO> listControlAndViewCount(ControlAndViewCountSortDTO sortDTO);
}
