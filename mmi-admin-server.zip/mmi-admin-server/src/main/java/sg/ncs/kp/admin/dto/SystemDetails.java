package sg.ncs.kp.admin.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SystemDetails {
    /**
     * server name
     */
    private String computerName;

    /**
     * server ip
     */
    private String computerIp;

    /**
     * project dir
     */
    private String userDir;

    /**
     * os name
     */
    private String osName;

    /**
     * os arch
     */
    private String osArch;
}
