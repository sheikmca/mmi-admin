package sg.ncs.kp.admin.notify;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import sg.ncs.kp.admin.pojo.AdminConstants;
import sg.ncs.kp.admin.pojo.WSMsgTypEnum;
import sg.ncs.kp.admin.service.AsyncService;
import sg.ncs.kp.admin.util.NotificationUtil;
import sg.ncs.kp.notification.pojo.NotificationConstants;
import sg.ncs.kp.uaa.client.enums.OfflineEnum;
import sg.ncs.kp.uaa.client.notify.TokenUpdateNotify;
import sg.ncs.kp.uaa.client.session.UserSession;
import sg.ncs.kp.uaa.server.mapper.LoginLogMapper;
import sg.ncs.kp.uaa.server.po.LoginLog;
import sg.ncs.kp.vms.feign.StreamFeign;
import sg.ncs.kp.vms.feign.TakeoverControlFeign;

/**
 * @date 2022/9/16 18:21
 */
@Slf4j
@Service
public class KpTokenUpdateNotify implements TokenUpdateNotify {

    @Autowired
    private RedisTemplate<String, String> sessionRedisTemplate;

    @Autowired
    private TakeoverControlFeign takeoverControlFeign;

    @Autowired
    private StreamFeign streamFeign;

    @Autowired
    private LoginLogMapper loginLogMapper;

    @Autowired
    private AsyncService asyncService;

    @Autowired
    private NotificationUtil notificationUtil;

    @Override
    public void offLineNotification(OAuth2Authentication authentication, OfflineEnum type) {
        if (OfflineEnum.FORCED.equals(type) && authentication.getPrincipal() instanceof UserSession) {
            
            String userId = ((UserSession) authentication.getPrincipal()).getId();
            takeoverControlFeign.deleteByUserId(userId);
            streamFeign.endLiveByUserId(userId);
            sessionRedisTemplate.opsForHash().delete(AdminConstants.USER_ONLINE_REDIS_KEY, userId);
            LoginLog loginLog = loginLogMapper.getUserLastLoginByUserId(userId);
            if(ObjectUtil.isNotEmpty(loginLog)) {
                loginLog.setLogoutTime(DateUtil.date());
                loginLogMapper.updateById(loginLog);
            }
            asyncService.sendMessage(WSMsgTypEnum.FORCED_LOGOUT, userId);
            notificationUtil.sendTopicMsgToWebSocketExchange(new JSONObject(),
                    NotificationConstants.TOPIC_WORKSTATION_STATUS_UPDATE);
            log.info("User:{} forced offline", userId);
        }
    }
}
