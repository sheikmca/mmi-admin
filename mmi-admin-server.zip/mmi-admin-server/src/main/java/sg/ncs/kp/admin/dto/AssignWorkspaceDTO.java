package sg.ncs.kp.admin.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @className AssignWorkspaceDTO
 * @version 1.0.0
 * @date 2023-08-30
 */
@Getter
@Setter
@ToString
public class AssignWorkspaceDTO {
    @NotNull
    private Long id;
    private List<Long> roleIds;
}
