package sg.ncs.kp.admin.inner.controller;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import sg.ncs.kp.admin.pojo.RoleUserDTO;
import sg.ncs.kp.admin.service.KpUserService;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.common.i18n.pojo.CodeEnum;
import sg.ncs.kp.common.i18n.pojo.MessageEnum;
import sg.ncs.kp.common.i18n.util.MessageUtils;
import sg.ncs.kp.uaa.common.enums.UserLevelEnum;
import sg.ncs.kp.uaa.server.mapper.UserMapper;
import sg.ncs.kp.uaa.server.po.User;
import sg.ncs.kp.uaa.server.service.UserRelUserGroupMappingMapperService;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @auther 
 * @date 2022/8/19
 * @description
 */
@RestController
@RequestMapping("/inner/user")
@Slf4j
public class InnerUserController {

    @Autowired
    private KpUserService kpUserService;

    @Autowired
    private UserRelUserGroupMappingMapperService userRelUserGroupMappingMapperService;


    @Autowired
    private MessageUtils messageUtils;

    @Autowired
    private UserMapper userMapper;

    @PostMapping("/getUserIds")
    Result<Set<String>> getUserIdsByTenantId(@RequestParam("tenantId") String tenantId, @RequestParam("ids")String ids) {
        if (StringUtils.isBlank(ids)) {
            return messageUtils.succeed(new HashSet<>());
        }
        Set<String> idSet = new HashSet<>();
        String[] split = ids.split(",");
        for (String str : split) {
            idSet.add(str);
        }
        return messageUtils.succeed(kpUserService.getUserIdsByTenantId(tenantId, idSet));
    }
    @PostMapping("/ids")
    public Result<Set<String>> getUserIdsByRoleId(@RequestBody Set<Long> roleIds){
        Set<String> ids = kpUserService.getUserIdsByRoleId(roleIds);
        return messageUtils.succeed(ids);
    }

    @PostMapping({"/idsByGroupId"})
    Result<Set<String>> getUserIdsByGroupId(@RequestBody Set<Long> userGroupIds){
        Set<String> ids = kpUserService.getUserIdsByGroupId(userGroupIds);
        return messageUtils.succeed(ids);
    }

    @GetMapping("/getUserNameMap")
    Result<Map<String, String>> getUserNameMap(@RequestParam String idArray) {
        if (StrUtil.isBlank(idArray)){
            return messageUtils.succeed(Collections.emptyMap());
        }
        List<String> idList= Arrays.asList(idArray.split(","));
        Map<String, String> map= kpUserService.getUserNameMap(idList);
        return messageUtils.succeed(map);
    }
    
    @GetMapping("/agencyAdminId")
    public Result<Set<String>> getAgencyAdminId(@RequestParam("tenantId") String tenantId){
        Set<String> ids= new HashSet<>();
        List<User> users = userMapper.selectList(Wrappers.<User>lambdaQuery()
                .select(User::getId)
                .eq(User::getTenantId, tenantId)
                .eq(User::getLevel, UserLevelEnum.TENANT_ADMIN.getValue()));
       for(User user:users) {
           ids.add(user.getId());
       }
        return messageUtils.succeed(ids);
    }

    @GetMapping("/{userId}/role")
    public Result<String> getRoleIdByUserId(@PathVariable("userId") String userId){
        return messageUtils.succeed(kpUserService.getRoleIdByUserId(userId));
    }

    @GetMapping("/{permissionId}/role-user")
    public List<RoleUserDTO> getRoleUsersByPermissionId(@PathVariable("permissionId") Integer permissionId){
        return kpUserService.getRoleUsersByPermissionId(permissionId);
    }

    @GetMapping("/all-user-id")
    public Set<String> getAllUserIds(){
        return kpUserService.getAllUserIds();
    }

    @GetMapping("/is-same-hub/{targetUserId}/{currentUserId}")
    public Boolean isSameHub(@PathVariable("targetUserId") String targetUserId, @PathVariable("currentUserId") String currentUserId){
        return userRelUserGroupMappingMapperService.isSameHub(targetUserId,currentUserId);
    }

    @GetMapping("/get-full-path/{userId}")
    public Result<String> getFullPathByUserId(@PathVariable("userId") String userId){
        String fullPath = userRelUserGroupMappingMapperService.getFullPathByUserId(userId);
        log.info("fullPath = {}",fullPath);
        return messageUtils.succeedWith(fullPath,true,null);
    }

    @GetMapping("/{id}/user/id")
    public Result<Integer> getUserId(@PathVariable("id") String id){
        User user = userMapper.selectById(id);
        return messageUtils.succeed(user.getUserId());
    }

    @GetMapping("/id/{userId}")
    public Result<String> getId(@PathVariable("userId") Integer userId){
        User user = userMapper.selectOne(Wrappers.<User>lambdaQuery().eq(User::getUserId, userId));
        return messageUtils.succeedWith(user != null ? user.getId() : null,
                CodeEnum.SUCCESS.getCode(), MessageEnum.SUCCESS.code());
    }
    @GetMapping("/is-exist/{queryCriteria}/{roleId}")
    public JSONObject isExistByQueryCriteria(@PathVariable("queryCriteria") String queryCriteria, @PathVariable("roleId") String roleId){
        return kpUserService.isExistByQueryCriteria(queryCriteria,Long.valueOf(roleId));
    }
}
