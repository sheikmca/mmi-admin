package sg.ncs.kp.admin.inner.controller;

import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.toolkit.StringPool;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.web.bind.annotation.*;
import sg.ncs.kp.admin.dto.ADUserDTO;
import sg.ncs.kp.admin.dto.CheckADUserResponseDTO;
import sg.ncs.kp.admin.enums.AdminMsgEnum;
import sg.ncs.kp.admin.service.KpUserOnlineService;
import sg.ncs.kp.admin.service.TokenService;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.common.exception.pojo.ClientServiceException;
import sg.ncs.kp.common.i18n.util.MessageUtils;
import sg.ncs.kp.uaa.server.po.User;
import sg.ncs.kp.uaa.server.service.LoginService;
import sg.ncs.kp.uaa.server.service.UserService;

import java.util.ArrayList;

/**
 * @auther 
 * @date 2023/1/4
 * @description
 */
@Slf4j
@RestController
@RequestMapping("/inner/token")
public class InnerTokenController {

    private static final String KEY_TELEPHONE_NUMBER = "telephoneNumber";
    private static final String KEY_MAIL = "mail";

    @Autowired
    private MessageUtils messageUtils;


    @Autowired
    private UserService userService;

    @Autowired
    private LoginService loginService;

    @Autowired
    private TokenService tokenService;

    @Autowired
    KpUserOnlineService kpUserOnlineService;

    @GetMapping("/checkPassword")
    public Result<Boolean> checkPassWord(@RequestParam("username") String username, @RequestParam("password") String password) {
        return messageUtils.succeed(userService.checkPassWordIsTenantAdmin(username, password));
    }

    @GetMapping("/{userId1}/{userId2}/login-region")
    public Boolean isUseSameRegion(@PathVariable("userId1") String userId1,@PathVariable("userId2") String userId2){
        return loginService.isUseSameRegion(userId1, userId2);
    }

    @GetMapping("/ad-sso-login")
    public Result<OAuth2AccessToken> adSsoLogin(@RequestParam("userName") String userName, @RequestParam("adName") String adName, @RequestParam("direction") String direction) throws Exception {
        String queryUserName;
        if (userName.contains(StringPool.AT)) {
            // If the AD User id with "@" as same as email address
            queryUserName = userName.substring(0, userName.indexOf(StringPool.AT));
        } else {
            // Pure AD User
            queryUserName = userName;
        }
        User user = userService.getUser(queryUserName);
        if(ObjectUtil.isNotEmpty(user)) {
            String checkUserId = user.getId();
            if (kpUserOnlineService.isUserOnline(checkUserId)) {
                throw new ClientServiceException(AdminMsgEnum.USER_ON_LINE);
            }
        }
        CheckADUserResponseDTO adUserData = new CheckADUserResponseDTO();
        ArrayList<ADUserDTO> adUserList = new ArrayList<>();
        ADUserDTO adUser = new ADUserDTO();
        adUser.setUserName(userName);
        adUserList.add(adUser);
        adUserData.setUserList(adUserList);
        adUserData.setNum(HttpStatus.OK.value());
        return tokenService.adLogin(adUserData, adName, direction);
    }

}

