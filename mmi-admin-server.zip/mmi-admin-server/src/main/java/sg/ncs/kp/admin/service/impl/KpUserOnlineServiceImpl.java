package sg.ncs.kp.admin.service.impl;

import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import sg.ncs.kp.admin.pojo.AdminConstants;
import sg.ncs.kp.admin.pojo.WSMsgTypEnum;
import sg.ncs.kp.admin.service.AsyncService;
import sg.ncs.kp.admin.service.KpUserOnlineService;
import sg.ncs.kp.admin.util.NotificationUtil;
import sg.ncs.kp.notification.pojo.NotificationConstants;
import sg.ncs.kp.uaa.client.config.UaaTokenServices;
import sg.ncs.kp.uaa.client.util.ServletUtil;
import sg.ncs.kp.uaa.server.mapper.LoginLogMapper;
import sg.ncs.kp.uaa.server.po.LoginLog;
import sg.ncs.kp.uaa.server.service.LoginService;

@Service
@Slf4j
public class KpUserOnlineServiceImpl implements KpUserOnlineService{

    @Autowired
    private AsyncService asycService;
    
    @Autowired
    private RedisTemplate<String, String> sessionRedisTemplate;

    @Autowired
    private LoginService loginService;

    @Autowired
    private UaaTokenServices uaaTokenServices;

    @Autowired
    private LoginLogMapper loginLogMapper;

    @Autowired
    private NotificationUtil notificationUtil;


    @Override
    public void userOnline(String userId, String accessToken) {
        sessionRedisTemplate.opsForHash().put(AdminConstants.USER_ONLINE_REDIS_KEY, userId, accessToken);
    }

    @Override
    public Boolean isUserOnline(String userId){
        //HashOperations<String, String, Object> hashOps = sessionRedisTemplate.opsForHash();
        //return hashOps.hasKey(AdminConstants.USER_ONLINE_REDIS_KEY,userId);
        LoginLog loginLog = loginLogMapper.isOnlineUser(userId);
        if(ObjectUtil.isNotEmpty(loginLog) && ObjectUtil.isEmpty(loginLog.getLogoutTime())){
            String currentIp = ServletUtil.getCurrentIp();
            return !StringUtils.equals(currentIp, loginLog.getIp());
        }else{
            return false;
        }
    }

    @Override
    public void userOffline(String userId,WSMsgTypEnum type) {
        sessionRedisTemplate.opsForHash().delete(AdminConstants.USER_ONLINE_REDIS_KEY, userId);
        loginService.updateLogoutTime(userId);
        asycService.sendMessage(type, userId);
        notificationUtil.sendTopicMsgToWebSocketExchange(new JSONObject(), NotificationConstants.TOPIC_WORKSTATION_STATUS_UPDATE);
    }

    @Override
    public void forceLogout(String userId){
        Object token = sessionRedisTemplate.opsForHash().get(AdminConstants.USER_ONLINE_REDIS_KEY, userId);
        if(token != null) {
            uaaTokenServices.revokeToken(token.toString());
            sessionRedisTemplate.opsForHash().delete(AdminConstants.USER_ONLINE_REDIS_KEY, userId);
        }
        log.info("force logout user[{}], token: {}", userId, token);
        loginService.updateLogoutTime(userId);
        asycService.sendMessage(WSMsgTypEnum.FORCED_OFFLINE, userId);
        notificationUtil.sendTopicMsgToWebSocketExchange(new JSONObject(), NotificationConstants.TOPIC_WORKSTATION_STATUS_UPDATE);
    }

    
}
