package sg.ncs.kp.northbound.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import sg.ncs.kp.common.core.response.PageResult;
import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.northbound.service.PlaybackNBService;
import sg.ncs.kp.northbound.service.VaAnnotateAlertNBService;
import sg.ncs.kp.northbound.service.VaQueryNBService;
import sg.ncs.kp.northbound.service.VaSearchEventNBService;
import sg.ncs.kp.vap.pojo.sdk.dto.analytics.EventOrAlertDTO;
import sg.ncs.kp.vap.pojo.sdk.dto.query.AggregateResultQuery;
import sg.ncs.kp.vap.pojo.sdk.dto.query.AlertMetadataDTO;
import sg.ncs.kp.vms.pojo.playback.GetPlayBackStreamsDTO;

import java.io.InputStream;

/**
 * Northbound Controller for Video Analytics (VA) APIs.
 *
 * This controller exposes VA-related endpoints to external consumers.
 * It acts as a thin orchestration layer responsible for:
 * - Request handling
 * - Input validation
 * - Logging
 * - Delegating execution to NB service implementations
 *
 * All business logic, downstream service calls, and exception handling
 * are managed in the service layer.
 */
@Slf4j
@RestController
@RequestMapping("/va")
@RequiredArgsConstructor
public class VaNBController {

    /**
     * Service responsible for VA query operations such as
     * retrieving event-related assets (e.g., images).
     */

    private final VaQueryNBService vaNBService;

    /**
     * Service responsible for searching and aggregating
     * VA events and alerts.
     */

    private final VaSearchEventNBService vaSearchEventNBService;

    /**
     * Service responsible for updating and annotating
     * alert metadata in downstream VA systems.
     */

    private final VaAnnotateAlertNBService vaAnnotateAlertNBService;

    private final PlaybackNBService playbackNBService;

    /**
     * Retrieves the Base64-encoded image associated with a VA event.
     *
     * Flow:
     * 1. Accepts event ID as a path variable
     * 2. Delegates image retrieval to VA query service
     * 3. Wraps and returns the Base64 string in a standard Result object
     *
     * @param id unique identifier of the event
     * @return Base64 encoded image data
     */
    @GetMapping("/event-images/{id}/blob")
    public sg.ncs.kp.northbound.pojo.common.Result<String> getImageBase64ById(@PathVariable String id) {
        log.info("NB → Received request to get event image for ID: {}", id);
        String base64 = vaNBService.getImageBase64ById(id);
        return sg.ncs.kp.northbound.pojo.common.Result.ok(base64);
    }

    /**
     * Searches VA event and alert history using aggregation criteria.
     *
     * Supports:
     * - Filtering
     * - Aggregation
     * - Pagination
     * - Sorting
     *
     * Typically used by analytics dashboards and reporting modules.
     *
     * @param dto aggregation and pagination parameters
     * @return paginated list of events or alerts
     */
    @PostMapping("/events/search")
    public ResponseEntity<PageResult<EventOrAlertDTO>> searchEventHistory(
            @Valid @RequestBody  AggregateResultQuery dto) {

        PageResult<EventOrAlertDTO> result = vaSearchEventNBService.searchEventHistory(dto);
        return ResponseEntity.ok(result);
    }

    /**
     * Updates or annotates alert metadata.
     *
     * Use cases:
     * - Operator annotation
     * - Alert status update
     * - Enrichment of alert information
     *
     * The request is forwarded to downstream VA services
     * and the execution result is returned to the caller.
     *
     * @param dto alert metadata update request
     * @return operation result
     */
    @PostMapping("/alerts/annotate")
    public ResponseEntity<Void> updateAlarm(@Valid  @RequestBody AlertMetadataDTO dto) {
         vaAnnotateAlertNBService.updateAlarm(dto);
        return ResponseEntity.noContent().build();
    }


    /**
     * POST: Miniclip Download
     */
    @PostMapping("/event-videos")
    public ResponseEntity<Resource> getRecent(@Valid @RequestBody GetPlayBackStreamsDTO dto)  {
        log.info("NB → Recent miniclip Request: {}", dto);

        InputStream stream = playbackNBService.getNBRecent(dto);

        if (stream == null) {
            log.warn("NB → No miniclip available for DTO: {}", dto);
            return ResponseEntity.noContent().build();
        }

        InputStreamResource resource = new InputStreamResource(stream);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDisposition(ContentDisposition.attachment().filename("miniclip.mp4").build());

        return ResponseEntity.status(HttpStatus.CREATED)
                .headers(headers)
                .body(resource);
    }

}
