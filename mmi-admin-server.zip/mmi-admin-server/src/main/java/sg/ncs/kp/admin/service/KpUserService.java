package sg.ncs.kp.admin.service;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.web.multipart.MultipartFile;
import sg.ncs.kp.admin.dto.*;
import sg.ncs.kp.admin.po.UploadRecord;
import sg.ncs.kp.admin.pojo.RoleUserDTO;
import sg.ncs.kp.uaa.common.dto.PasswordPolicyDTO;
import sg.ncs.kp.uaa.common.dto.UserDTO;
import sg.ncs.kp.uaa.common.dto.UserDetailDTO;
import sg.ncs.kp.uaa.common.dto.UserModifyDTO;
import sg.ncs.kp.uaa.common.dto.UserPasswordDTO;
import sg.ncs.kp.uaa.common.dto.UserQueryDTO;
import sg.ncs.kp.uaa.common.dto.UserUploadRecordQueryDTO;
import sg.ncs.kp.uaa.common.vo.UserGroupTreeVO;
import sg.ncs.kp.uaa.server.po.PasswordPolicy;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @auther 
 * @date 2022/8/20
 * @description
 */
public interface KpUserService {

    /**
     * page list
     * @param userQueryDTO
     * @return
     */
    IPage<UserDTO> selectList(UserQueryDTO userQueryDTO);

    /**
     * add user
     * @param userModifyDTO
     */
    void add(UserModifyDTO userModifyDTO);

   void addLDAPUser(String name, String mail, String userName, String adName, String mobile, String direction);

   void updateLDAPUser(String name, String mail, String userName, String adName, String mobile);

    /**
     * update user
     * @param userModifyDTO
     */
    void update(UserModifyDTO userModifyDTO,boolean roleChange);

    List<String> assignRole(AssignRoleDTO assignRole);

    /**
     * delete user
     * @param id
     */
    void delete(String id);

    /**
     * batch delete user
     * @param ids
     */
    void delete(List<String> ids);

    /**
     *
     * @param id
     * @param status 1.enable 0.disable
     */
    void updateStatus(String id, Integer status);

    /**
     *
     * @param changeGroupDTO
     */
    void changeGroup(ChangeGroupDTO changeGroupDTO);

    /**
     *
     * @param groupName user group name
     * @return
     */
    UserGroupTreeVO group(String groupName);

    /**
     * change myself password
     * @param userPasswordDTO
     */
    void password(UserPasswordDTO userPasswordDTO) throws Exception;

    /**
     * get password policy
     * @return
     */
    List<PasswordPolicy> policy();

    /**
     * set password policy
     * @return
     */
    void policy(List<PasswordPolicyDTO> list);

    /**
     * reset password
     */
    void resetPassword(ResetPasswordDTO resetPassword) throws Exception;

    /**
     *
     * @param userId
     * @return
     */
    UserDetailDTO get(String userId, Set<Long> roleIds);

    /**
     * upload
     * @param file
     * @return
     */
    String upload(MultipartFile file);

    /**
     * get upload history
     * @param userUploadRecordQueryDTO
     * @return
     */
    Page<UploadRecord> uploadRecord(UserUploadRecordQueryDTO userUploadRecordQueryDTO);

    /**
     *
     * @param userViewQueryDTO
     * @return
     */
    Page<UserUploadViewDTO> view(UserViewQueryDTO userViewQueryDTO);

    /**
     * import user file data
     * @param path
     */
    UploadResultDTO importFile(String path);

    /**
     * batch add user
     * @param batchUserDTO
    */
    BatchUserResultDTO batchAdd(BatchUserDTO batchUserDTO);

    /**
     * download file
     * @param response
     * @param path
     * @param fileName
     */
    void downloadUploadFile(HttpServletResponse response, String path, String fileName);

    /**
     *
     * @param ids
     * @param response
     */
    void export(List<String> ids, String type, HttpServletResponse response) throws IOException;

    /**
     *
     * @param user
     */
    void updateMyself(UserUpdateProfileDTO user);

    /**
     *
     * @param roleIds
     * @return
     */
    Set<String> getUserIdsByRoleId(Set<Long> roleIds);

 /**
  *
  * @return
  */
 Set<String> getAllUserIds();

    /**
     *
     * @param groupIds
     * @return
    */
    Set<String> getUserIdsByGroupId(Set<Long> groupIds);


    /**
     * KpUserService
     *
     * @description get this tenant's userIds
     * @param tenantId tenantId
     * @param userIds userIds
     * @return Set<String>
     * @date 2022/9/2 9:55
     */
    Set<String> getUserIdsByTenantId(String tenantId, Set<String> userIds);



    /**
     * KpUserService
     *
     * @description get userName by userId
     * @param idList idList
     * @return Map<String, String>
     * @date 2022/9/6 16:45
     */
    Map<String, String> getUserNameMap(List<String> idList);

    /**
     *
     * @param userPasswordDTO
     */
    void updateMyselfPassword(UserSelfPasswordUpdateDTO userPasswordDTO) throws Exception;

    /**
     * update receive message status
     * @param id user id
     * @param status 1.enable 0.disable
     */
    void notification(String id, Integer status);

    /**
     * menus
     * @return
     */
    List<MenuDTO> menus();

    boolean checkUserIsNeed2fa(String userId);

    String getRoleIdByUserId(String userId);

    List<RoleUserDTO> getRoleUsersByPermissionId(Integer permissionId);

    JSONObject isExistByQueryCriteria(String queryCriteria, Long roleId);
}
