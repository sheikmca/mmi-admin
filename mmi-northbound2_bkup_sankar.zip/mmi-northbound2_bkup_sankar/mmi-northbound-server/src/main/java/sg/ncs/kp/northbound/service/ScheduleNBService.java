package sg.ncs.kp.northbound.service;

import sg.ncs.kp.common.core.response.Result;
import sg.ncs.kp.vms.pojo.schedule.ScheduleDetailVO;

/**
 * Northbound service interface for retrieving recording schedule details
 * from the VMS scheduling subsystem.
 *
 * Responsibilities:
 * - Receive NB request for schedule details.
 * - Forward the request to VMS through Feign (implemented in the serviceImpl).
 * - Return the upstream Result object containing ScheduleDetailVO.
 *
 * No business logic should be implemented here.
 */
public interface ScheduleNBService {

    /**
     * Retrieves the recording schedule details for the given schedule ID.
     *
     * @param id the schedule identifier to query.
     * @return Result containing ScheduleDetailVO if found, or a failure Result from VMS.
     */
    Result<ScheduleDetailVO> getScheduleById(String id);
}
