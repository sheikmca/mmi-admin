package sg.ncs.kp.northbound.pojo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * API错误响应模型
 * 用于统一API错误响应格式
 */
@Getter
@Setter
@ToString
public class ErrorResponse {
    
    /**
     * 错误代码
     * 字符集：a-z, A-Z, 0-9, -
     */
    private String code;
    
    /**
     * 参数列表
     * 多个字符串值允许显示传递给前端的数据
     */
    private List<String> params;
    
    // 构造函数
    public ErrorResponse() {
    }
    
    public ErrorResponse(String code, List<String> params) {
        this.code = code;
        this.params = params;
    }

}