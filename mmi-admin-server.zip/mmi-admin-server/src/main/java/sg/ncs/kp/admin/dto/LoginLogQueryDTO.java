package sg.ncs.kp.admin.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;
import sg.ncs.kp.common.core.response.PageQuery;

import java.util.Date;

/**
 * @auther 
 * @date 2022/9/8
 * @description
 */
@Getter
@Setter
public class LoginLogQueryDTO extends PageQuery {

    private String userName;
    private Integer userIdNum;

    private String userGroupName;

    private String ip;

    private String phone;

    private String email;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date loginTimeBegin;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date loginTimeEnd;

    private Integer startNum;

    private Integer endNum;
}
